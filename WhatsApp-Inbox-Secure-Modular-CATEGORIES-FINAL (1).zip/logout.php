<?php

declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';
requireAuth(false);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Location: index.php', true, 302);
    exit;
}

$token = (string)($_POST['csrf'] ?? '');
$sessionToken = (string)($_SESSION['wa_inbox_csrf'] ?? '');
if ($token === '' || $sessionToken === '' || !hash_equals($sessionToken, $token)) {
    http_response_code(403);
    exit('Invalid security token.');
}

logoutUser();
header('Location: login.php', true, 302);
exit;

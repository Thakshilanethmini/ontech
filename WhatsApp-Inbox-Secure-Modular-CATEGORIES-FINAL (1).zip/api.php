<?php

declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';
requireAuth(true);

$action = trim((string)($_GET['action'] ?? ''));
$allowedActions = ['stats', 'filter_options', 'conversations', 'messages', 'referral', 'leads', 'reference_analysis', 'call_tracking', 'call_status_read', 'call_status', 'call_attempt', 'move_chats', 'delete_chat', 'delete_chats', 'send_text', 'bulk_send_text', 'quick_replies', 'categories', 'create_category', 'delete_category', 'add_to_category', 'remove_from_category'];

if ($action === '') {
    jsonOut(['error' => 'Missing action'], 400);
}

if (!in_array($action, $allowedActions, true)) {
    jsonOut(['error' => 'Unknown action'], 404);
}

$rateRules = ['stats' => [120, 60], 'filter_options' => [60, 60], 'conversations' => [120, 60], 'messages' => [120, 60], 'referral' => [120, 60], 'leads' => [120, 60], 'reference_analysis' => [60, 60], 'call_tracking' => [120, 60], 'call_status_read' => [120, 60], 'quick_replies' => [120, 60], 'call_status' => [30, 60], 'call_attempt' => [30, 60], 'move_chats' => [20, 60], 'delete_chat' => [10, 60], 'delete_chats' => [10, 60], 'send_text' => [30, 60], 'bulk_send_text' => [10, 60]];
if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 600000) {
    jsonOut(['error' => 'Request body is too large.'], 413);
}

try {
    if (isset($rateRules[$action])) {
        rateLimit('api:' . $action, $rateRules[$action][0], $rateRules[$action][1]);
    }
} catch (RateLimitExceeded $e) {
    http_response_code(429);
    header('Retry-After: ' . $e->retryAfter);
    jsonOut(['error' => 'Too many requests. Please try again shortly.'], 429);
} catch (Throwable $e) {
    error_log('[WhatsApp Inbox] rate-limit failure [' . $action . ']: ' . $e->getMessage());
    jsonOut(['error' => 'Security service is temporarily unavailable.'], 503);
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    jsonOut(['error' => 'Database connection is unavailable.'], 503);
}

try {
    if (in_array($action, ['call_status','call_attempt','move_chats','delete_chat','delete_chats','send_text','bulk_send_text','create_category','delete_category','add_to_category','remove_from_category'], true)) {
        // All state-changing routes must be POST + CSRF protected.
        requirePostCsrf();
    }

    if (in_array($action, ['stats','filter_options','conversations','messages','referral','leads','reference_analysis','call_tracking','call_status_read','call_status','call_attempt','move_chats'], true)) {
        ensureCallTrackingTable($pdo);
    }

    if (in_array($action, ['categories','create_category','delete_category','add_to_category','remove_from_category','conversations','delete_chats'], true)) {
        ensureCategoryTables($pdo);
    }

    $filters = [
        'q'            => cleanVal($_GET['q']            ?? null),
        'source'       => cleanVal($_GET['source']       ?? null),
        'platform'     => cleanVal($_GET['platform']     ?? null),
        'source_type'  => cleanVal($_GET['source_type']  ?? null),
        'product'      => cleanVal($_GET['product']      ?? null),
        'reference'    => cleanVal($_GET['reference']    ?? null),
        'referral'     => cleanVal($_GET['referral']     ?? null),
        'ctwa'         => cleanVal($_GET['ctwa']         ?? null),
        'call_status'  => cleanVal($_GET['call_status']  ?? null),
        'message_type' => cleanVal($_GET['message_type'] ?? null),
        'date_from'    => cleanVal($_GET['date_from']    ?? null),
        'date_to'      => cleanVal($_GET['date_to']      ?? null),
        'sort'         => cleanVal($_GET['sort']         ?? null),
        'category_id'  => cleanVal($_GET['category_id']  ?? null),
    ];

    if ($action === 'quick_replies') {
        $quickReplies = require __DIR__ . '/app/quick_replies.php';
        jsonOut(['data' => $quickReplies]);
    }

    $actionFile = __DIR__ . '/app/api/actions/' . $action . '.php';
    if (!is_file($actionFile)) {
        jsonOut(['error' => 'Action handler is not available.'], 500);
    }

    require $actionFile;
} catch (Throwable $e) {
    error_log('[WhatsApp Inbox] API error [' . $action . ']: ' . $e->getMessage());
    jsonOut([
        'error' => 'The request could not be completed. Please try again.',
    ], 500);
}

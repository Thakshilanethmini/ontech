<?php

declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';
requireAuth(false);
header('Cache-Control: private, no-store, max-age=0');

require __DIR__ . '/resources/dashboard.php';

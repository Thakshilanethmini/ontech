<?php

declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';
header('Cache-Control: private, no-store, max-age=0');

if (!authRequired()) {
    header('Location: index.php', true, 302);
    exit;
}

if (isAuthenticated()) {
    header('Location: index.php', true, 302);
    exit;
}

$error = null;
$next = (string)($_GET['next'] ?? $_POST['next'] ?? 'index.php');
if ($next === '' || preg_match('~^(?:[a-z][a-z0-9+.-]*:)?//~i', $next) || str_contains($next, '\\')) {
    $next = 'index.php';
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $token = (string)($_POST['csrf'] ?? '');
    if ($token === '' || !hash_equals((string)($_SESSION['wa_inbox_csrf'] ?? ''), $token)) {
        $error = 'Your security token is invalid. Please refresh and try again.';
    } else {
        $username = (string)($_POST['username'] ?? '');
        $password = (string)($_POST['password'] ?? '');

        try {
            if (attemptLogin($username, $password)) {
                header('Location: ' . $next, true, 302);
                exit;
            }
        } catch (RateLimitExceeded $e) {
            $error = 'Too many login attempts. Please wait a few minutes and try again.';
        }

        $error = $error ?? (authConfigured()
            ? 'Invalid username or password.'
            : 'Login is not configured. Add the authentication values to config.php first.');
    }
}

$csrf = ensureCsrfToken();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WhatsApp Inbox — Sign in</title>
<meta name="theme-color" content="#25d366">
<link rel="stylesheet" href="assets/css/app.css?v=2">
</head>
<body>
<div class="login-shell">
    <div class="login-card">
        <div class="login-brand">
            <div class="login-dot">💬</div>
            <div>
                <h1 class="login-title">WhatsApp Inbox</h1>
                <p class="login-sub">Secure lead & conversation dashboard</p>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="login-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <form method="post" action="login.php" autocomplete="on">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="next" value="<?= htmlspecialchars($next, ENT_QUOTES, 'UTF-8') ?>">

            <div class="login-field">
                <label for="username">Username</label>
                <input id="username" name="username" type="text" maxlength="120" autocomplete="username" required autofocus>
            </div>

            <div class="login-field">
                <label for="password">Password</label>
                <input id="password" name="password" type="password" maxlength="200" autocomplete="current-password" required>
            </div>

            <button class="login-submit" type="submit">🔐 Sign in securely</button>
        </form>

        <div class="login-note">
            Access is protected with a session cookie, CSRF protection, login rate limiting and browser security headers. WhatsApp access tokens stay on the server and are never embedded in the page.
        </div>
    </div>
</div>
</body>
</html>

<?php

declare(strict_types=1);

/**
 * Security primitives for the WhatsApp Inbox.
 * Keep this file outside the public asset directories.
 */

function isHttpsRequest(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') {
        return true;
    }

    return (int)($_SERVER['SERVER_PORT'] ?? 0) === 443;
}

function startSecureSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $secure = isHttpsRequest();

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Strict',
    ]);

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Strict');

    session_start();
}

function applySecurityHeaders(): void
{
    if (headers_sent()) {
        return;
    }

    $csp = implode('; ', [
        "default-src 'self'",
        "base-uri 'self'",
        "object-src 'none'",
        "frame-ancestors 'none'",
        "form-action 'self'",
        "script-src 'self'",
        "style-src 'self' 'unsafe-inline'",
        "img-src 'self' data: https:",
        "font-src 'self' data:",
        "connect-src 'self'",
        "manifest-src 'self'",
        "worker-src 'self'",
        "media-src 'self' https:",
        "upgrade-insecure-requests",
    ]);

    header('Content-Security-Policy: ' . $csp);
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Cross-Origin-Resource-Policy: same-origin');

    if (isHttpsRequest()) {
        header('Strict-Transport-Security: max-age=31536000');
    }
}

function ensureCsrfToken(): string
{
    if (empty($_SESSION['wa_inbox_csrf'])) {
        $_SESSION['wa_inbox_csrf'] = bin2hex(random_bytes(32));
    }

    return (string)$_SESSION['wa_inbox_csrf'];
}

function requirePostCsrf(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        jsonOut(['error' => 'POST required'], 405);
    }

    $origin = trim((string)($_SERVER['HTTP_ORIGIN'] ?? ''));
    if ($origin !== '') {
        $originHost = parse_url($origin, PHP_URL_HOST);
        $requestHost = parse_url('https://' . ((string)($_SERVER['HTTP_HOST'] ?? '')), PHP_URL_HOST);
        if ($originHost && $requestHost && !hash_equals(strtolower((string)$requestHost), strtolower((string)$originHost))) {
            jsonOut(['error' => 'Cross-origin request blocked'], 403);
        }
    }

    $token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $sessionToken = (string)($_SESSION['wa_inbox_csrf'] ?? '');

    if ($token === '' || $sessionToken === '' || !hash_equals($sessionToken, $token)) {
        jsonOut(['error' => 'Invalid CSRF token'], 403);
    }
}

function clientIp(): string
{
    // Do not trust X-Forwarded-For blindly. Configure a trusted proxy before using it.
    return trim((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'));
}

final class RateLimitExceeded extends RuntimeException
{
    public function __construct(public readonly int $retryAfter)
    {
        parent::__construct('Rate limit exceeded');
    }
}

function rateLimit(string $bucket, int $maxAttempts, int $windowSeconds): void
{
    $dir = dirname(__DIR__) . '/storage/ratelimits';
    if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) {
        throw new RuntimeException('Security storage is not writable.');
    }

    $key = hash('sha256', $bucket . '|' . clientIp() . '|' . substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 200));
    $file = $dir . '/' . $key . '.json';
    $now = time();

    $fp = fopen($file, 'c+');
    if ($fp === false) {
        throw new RuntimeException('Security storage is not writable.');
    }

    try {
        if (!flock($fp, LOCK_EX)) {
            throw new RuntimeException('Security storage is busy.');
        }

        $contents = stream_get_contents($fp);
        $data = json_decode($contents ?: '', true);
        if (!is_array($data) || ($now - (int)($data['window_start'] ?? 0)) >= $windowSeconds) {
            $data = ['window_start' => $now, 'attempts' => 0];
        }

        $data['attempts'] = (int)$data['attempts'] + 1;

        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($data, JSON_UNESCAPED_SLASHES));
        fflush($fp);

        if ($data['attempts'] > $maxAttempts) {
            $retryAfter = max(1, $windowSeconds - ($now - (int)$data['window_start']));
            throw new RateLimitExceeded($retryAfter);
        }

        flock($fp, LOCK_UN);
    } finally {
        fclose($fp);
    }
}

<?php

declare(strict_types=1);

return [
    [
        'id' => 'thanks',
        'label' => 'Thank you for contacting us',
        'message' => 'Thank you for contacting Ontech IT Solutions. We have received your message and will get back to you shortly.',
    ],
    [
        'id' => 'contact-soon',
        'label' => 'We will contact you soon',
        'message' => 'Thank you for your interest. Our team will contact you soon to discuss your requirement.',
    ],
    [
        'id' => 'customer-details',
        'label' => 'Ask name, company, industry & 1–2 phones',
        'message' => 'ආයුබෝවන් {name}! ඔබගේ අවශ්‍යතාවය ගැන වැඩි විස්තර ලබාගැනීම සඳහා කරුණාකර ඔබගේ Company / Business Name එක, ඔබගේ Industry / Business Type එක, සහ ඔබව සම්බන්ධ කරගත හැකි Phone Number එකක් හෝ Phone Numbers දෙකක් එවන්න. ස්තුතියි.',
    ],
    [
        'id' => 'call-no-answer',
        'label' => 'Call attempted — no answer',
        'message' => 'ආයුබෝවන් {name}! අපි ඔබව අද {call_time} ට call කරලා සම්බන්ධ කරගැනීමට උත්සාහ කළා. එම අවස්ථාවේ සම්බන්ධ වීමට නොහැකි වූ නිසා, ඔබට පහසු දවසක් සහ වේලාවක් දන්වන්න. අපි එම වේලාවට නැවත call කරන්නම්. ස්තුතියි.',
        'current_chat_only' => true,
        'auto_mark_call_attempt' => true,
    ],
    [
        'id' => 'more-details',
        'label' => 'Please share more details',
        'message' => 'Could you please share a few more details about your requirement so we can assist you better?',
    ],
    [
        'id' => 'call-time',
        'label' => 'Ask for a convenient call time',
        'message' => 'We can arrange a quick call to discuss this. Please let us know a convenient time for our team to contact you.',
    ],
    [
        'id' => 'demo',
        'label' => 'Arrange a system demo',
        'message' => 'We would be happy to arrange a demo. Please share your preferred day and a contact number, and our team will coordinate with you.',
    ],
    [
        'id' => 'pricing',
        'label' => 'Pricing / quotation',
        'message' => 'Thank you for your interest. Please share the modules or features you require, and our team will discuss the suitable solution and pricing with you.',
    ],
    [
        'id' => 'follow-up',
        'label' => 'Follow up on an inquiry',
        'message' => 'Just following up on your inquiry. Please let us know if you would like us to contact you and discuss the requirement further.',
    ],
    [
        'id' => 'noted',
        'label' => 'Requirement received',
        'message' => 'Thank you. We have noted your requirement. Our team will review it and get back to you shortly.',
    ],
    [
        'id' => 'si-contact',
        'label' => 'Sinhala — contact soon',
        'message' => 'ඔබගේ පණිවිඩයට ස්තූතියි. ඔබගේ අවශ්‍යතාවය අපට ලැබී ඇත. අපගේ කණ්ඩායම ඉක්මනින් ඔබව සම්බන්ධ කරගෙන වැඩි විස්තර සාකච්ඡා කරනු ඇත.',
    ],
    [
        'id' => 'si-details',
        'label' => 'Sinhala — send your details',
        'message' => 'කරුණාකර ඔබගේ නම, ආයතනයේ නම, දුරකථන අංකය සහ ඔබට අවශ්‍ය software / system එක පිළිබඳ කෙටි විස්තරයක් එවන්න. අපගේ කණ්ඩායම එය පරීක්ෂා කර ඉක්මනින් ඔබව සම්බන්ධ කරගනු ඇත.',
    ],
    [
        'id' => 'si-call',
        'label' => 'Sinhala — ask for call time',
        'message' => 'ඔබට පහසු call වේලාවක් දැනුම් දෙන්න. අපගේ කණ්ඩායම එම වේලාවට ඔබව සම්බන්ධ කරගනු ඇත.',
    ],
];

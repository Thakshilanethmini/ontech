<?php

declare(strict_types=1);

function buildConversationFilters(array $p, array &$params): array
{
    $where = [];

    if (!empty($p['category_id'])) {
        $categoryId = (int)$p['category_id'];
        if ($categoryId > 0) {
            $where[] = "EXISTS (
                SELECT 1
                FROM whatsapp_chat_category_members cmcat
                WHERE cmcat.category_id = :category_id
                  AND cmcat.customer_phone = m.customer_phone
            )";
            $params[':category_id'] = $categoryId;
        }
    }

    /* Search all messages + referral fields belonging to the conversation. */
    if (!empty($p['q'])) {
        $where[] = "(
            EXISTS (
                SELECT 1
                FROM whatsapp_conversation_messages s
                WHERE s.customer_phone = m.customer_phone
                  AND (
                      s.message_text LIKE :q1
                      OR s.customer_name LIKE :q2
                      OR s.customer_phone LIKE :q3
                      OR s.reference_code LIKE :q4
                      OR s.product_code LIKE :q5
                      OR s.content_title LIKE :q6
                      OR s.headline LIKE :q7
                      OR s.body LIKE :q8
                      OR s.ctwa_clid LIKE :q9
                  )
            )
        )";

        $like = '%' . $p['q'] . '%';

        for ($i = 1; $i <= 9; $i++) {
            $params[":q$i"] = $like;
        }
    }

    /* Message source anywhere in the conversation. */
    if (!empty($p['source'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.message_source = :source
        )";
        $params[':source'] = $p['source'];
    }

    /* Platform anywhere in referral messages of the conversation. */
    if (!empty($p['platform'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.source_platform = :platform
              AND s.has_referral = 1
        )";
        $params[':platform'] = $p['platform'];
    }

    if (!empty($p['source_type'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.source_type = :source_type
              AND s.has_referral = 1
        )";
        $params[':source_type'] = $p['source_type'];
    }

    if (!empty($p['product'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.product_code = :product
              AND s.has_referral = 1
        )";
        $params[':product'] = $p['product'];
    }

    if (!empty($p['reference'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.reference_code LIKE :reference
              AND s.has_referral = 1
        )";
        $params[':reference'] = '%' . $p['reference'] . '%';
    }

    if (($p['referral'] ?? '') === 'yes') {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.has_referral = 1
        )";
    } elseif (($p['referral'] ?? '') === 'no') {
        $where[] = "NOT EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.has_referral = 1
        )";
    }

    if (($p['ctwa'] ?? '') === 'yes') {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.ctwa_clid IS NOT NULL
              AND s.ctwa_clid <> ''
        )";
    }

    if (!empty($p['message_type'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.message_type = :message_type
        )";
        $params[':message_type'] = $p['message_type'];
    }

    if (!empty($p['date_from'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND DATE(s.message_timestamp) >= :date_from
        )";
        $params[':date_from'] = $p['date_from'];
    }

    if (!empty($p['date_to'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND DATE(s.message_timestamp) <= :date_to
        )";
        $params[':date_to'] = $p['date_to'];
    }

    return $where;
}

function buildLeadFilters(array $p, array &$params, string $messageAlias = 'm'): array
{
    $m = preg_replace('/[^a-zA-Z0-9_]/', '', $messageAlias) ?: 'm';

    $where = [
        "$m.has_referral = 1",
        "$m.customer_phone IS NOT NULL",
        "$m.customer_phone <> ''",
    ];

    if (!empty($p['q'])) {
        $searchFields = [
            "$m.customer_phone",
            "$m.customer_name",
            "$m.message_text",
            "$m.message_type",
            "$m.message_source",
            "$m.status",
            "$m.reference_code",
            "$m.product_code",
            "$m.source_type",
            "$m.source_platform",
            "$m.content_title",
            "$m.headline",
            "$m.body",
            "$m.ctwa_clid",
            "$m.campaign_name",
            "$m.ad_name",
            "$m.creative_name",
            "$m.source_id",
            "$m.source_url",
        ];

        $searchParts = [];
        $like = '%' . $p['q'] . '%';
        foreach ($searchFields as $i => $field) {
            $key = ':q' . ($i + 1);
            $searchParts[] = "$field LIKE $key";
            $params[$key] = $like;
        }

        $where[] = '(' . implode(' OR ', $searchParts) . ')';
    }

    if (!empty($p['platform'])) {
        $where[] = "$m.source_platform = :platform";
        $params[':platform'] = $p['platform'];
    }

    if (!empty($p['source_type'])) {
        $where[] = "$m.source_type = :source_type";
        $params[':source_type'] = $p['source_type'];
    }

    if (!empty($p['product'])) {
        $where[] = "$m.product_code = :product";
        $params[':product'] = $p['product'];
    }

    if (!empty($p['reference'])) {
        $where[] = "$m.reference_code LIKE :reference";
        $params[':reference'] = '%' . $p['reference'] . '%';
    }

    if (($p['ctwa'] ?? '') === 'yes') {
        $where[] = "$m.ctwa_clid IS NOT NULL AND $m.ctwa_clid <> ''";
    }

    /*
     * Lead call state is based on the exact conversation_message_id.
     * Missing status row = Not called.
     */
    $callState = (string)($p['call_status'] ?? '');
    if (in_array($callState, ['not_called','called','rejected','try_again','attempted'], true)) {
        if ($callState === 'not_called') {
            $where[] = "NOT EXISTS (\n                SELECT 1 FROM whatsapp_customer_call_status cs2\n                WHERE cs2.conversation_message_id = $m.id\n                  AND cs2.call_status IN ('called','rejected','try_again')\n            )";
        } elseif ($callState === 'attempted') {
            $where[] = "EXISTS (\n                SELECT 1 FROM whatsapp_customer_call_status cs2\n                WHERE cs2.conversation_message_id = $m.id\n                  AND cs2.call_status IN ('rejected','try_again')\n            )";
        } else {
            $where[] = "EXISTS (\n                SELECT 1 FROM whatsapp_customer_call_status cs2\n                WHERE cs2.conversation_message_id = $m.id\n                  AND cs2.call_status = :call_status_filter\n            )";
            $params[':call_status_filter'] = $callState;
        }
    }

    if (!empty($p['date_from'])) {
        $where[] = "DATE(COALESCE($m.received_at, $m.message_timestamp)) >= :date_from";
        $params[':date_from'] = $p['date_from'];
    }

    if (!empty($p['date_to'])) {
        $where[] = "DATE(COALESCE($m.received_at, $m.message_timestamp)) <= :date_to";
        $params[':date_to'] = $p['date_to'];
    }

    return $where;
}

<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    define('WA_INBOX_BOOTSTRAPPED', true);
}

require_once dirname(__DIR__) . '/config.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/queries.php';
require_once __DIR__ . '/services/whatsapp.php';

startSecureSession();
applySecurityHeaders();
$waInboxCsrf = ensureCsrfToken();

if (isset($pdo) && $pdo instanceof PDO) {
    try {
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    } catch (Throwable $e) {
        // Leave existing config-level PDO settings intact if the driver rejects an attribute.
    }
}

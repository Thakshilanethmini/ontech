<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                requirePostCsrf();
                $payload = readJsonBody();
                $phones = $payload['phones'] ?? [];
                $bucket = trim((string)($payload['bucket'] ?? ''));

                if (!is_array($phones) || !$phones) {
                    jsonOut(['error' => 'No chats selected'], 400);
                }

                if (!in_array($bucket, ['inbox', 'old'], true)) {
                    jsonOut(['error' => 'Invalid destination'], 400);
                }

                $phones = array_values(array_unique(array_filter(
                    array_map(static fn($v) => normalizeWhatsAppPhone((string)$v), $phones),
                    static fn($v) => $v !== ''
                )));

                if (!$phones) {
                    jsonOut(['error' => 'No valid phone numbers'], 400);
                }

                if (count($phones) > 200) {
                    jsonOut(['error' => 'You can move up to 200 chats at once.'], 400);
                }

                $nameStmt = $pdo->prepare(<<<'SQL'
                    SELECT customer_name
                    FROM whatsapp_conversation_messages
                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                      AND customer_name IS NOT NULL
                      AND customer_name <> ''
                    ORDER BY id DESC
                    LIMIT 1
                SQL);

                $updateBucket = $pdo->prepare(<<<'SQL'
                    UPDATE whatsapp_customer_call_status
                    SET chat_bucket = :bucket,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                SQL);

                $insertBucket = $pdo->prepare(<<<'SQL'
                    INSERT INTO whatsapp_customer_call_status
                        (customer_phone, customer_name, conversation_message_id, call_status, attempt_count, chat_bucket)
                    VALUES
                        (:phone, :name, :message_id, 'not_called', 0, :bucket)
                SQL);

                $pdo->beginTransaction();
                try {
                    foreach ($phones as $phone) {
                        $nameStmt->execute([':phone' => $phone]);
                        $name = $nameStmt->fetchColumn() ?: null;

                        $updateBucket->execute([
                            ':bucket' => $bucket,
                            ':phone' => $phone,
                        ]);

                        if ($updateBucket->rowCount() === 0) {
                            $messageId = resolveRelatedConversationMessageId($pdo, $phone);
                            if ($messageId !== null) {
                                $insertBucket->execute([
                                    ':phone' => normalizeWhatsAppPhone($phone),
                                    ':name' => $name,
                                    ':message_id' => $messageId,
                                    ':bucket' => $bucket,
                                ]);
                            }
                        }
                    }
                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    throw $e;
                }

                jsonOut([
                    'ok' => true,
                    'bucket' => $bucket,
                    'moved' => count($phones),
                ]);

<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $opt = [
                    'sources' => $pdo->query(
                        "SELECT DISTINCT message_source
                         FROM whatsapp_conversation_messages
                         WHERE message_source IS NOT NULL
                           AND message_source <> ''
                         ORDER BY message_source"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'platforms' => $pdo->query(
                        "SELECT DISTINCT source_platform
                         FROM whatsapp_conversation_messages
                         WHERE has_referral = 1
                           AND source_platform IS NOT NULL
                           AND source_platform <> ''
                         ORDER BY source_platform"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'source_types' => $pdo->query(
                        "SELECT DISTINCT source_type
                         FROM whatsapp_conversation_messages
                         WHERE has_referral = 1
                           AND source_type IS NOT NULL
                           AND source_type <> ''
                         ORDER BY source_type"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'products' => $pdo->query(
                        "SELECT DISTINCT product_code
                         FROM whatsapp_conversation_messages
                         WHERE has_referral = 1
                           AND product_code IS NOT NULL
                           AND product_code <> ''
                         ORDER BY product_code"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'message_types' => $pdo->query(
                        "SELECT DISTINCT message_type
                         FROM whatsapp_conversation_messages
                         WHERE message_type IS NOT NULL
                           AND message_type <> ''
                         ORDER BY message_type"
                    )->fetchAll(PDO::FETCH_COLUMN),
                ];

                jsonOut(['data' => $opt]);

            /* ============================================================== 
               CONVERSATION LIST
            ============================================================== */

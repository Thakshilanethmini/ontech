<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $phone = trim((string)($_GET['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $stmt = $pdo->prepare(
                    "SELECT
                        c.id,
                        c.whatsapp_message_id,
                        c.customer_phone,
                        c.customer_name,
                        c.direction,
                        c.message_type,
                        c.message_text,
                        c.message_source,
                        c.status,
                        c.phone_number_id,
                        c.message_timestamp,
                        c.raw_payload,

                        c.has_referral,
                        c.reference_code,
                        c.product_code,
                        c.source_type,
                        c.source_platform,
                        c.content_title,
                        c.headline,
                        c.body AS ad_body,
                        c.media_type AS ref_media_type,
                        c.image_url,
                        c.video_url,
                        c.thumbnail_url,
                        c.source_id,
                        c.source_url,
                        c.ctwa_clid,
                        c.campaign_name,
                        c.ad_name,
                        c.creative_name

                    FROM whatsapp_conversation_messages c

                    WHERE c.customer_phone = :phone

                    ORDER BY c.message_timestamp ASC, c.id ASC
                    LIMIT 500"
                );

                $stmt->execute([':phone' => $phone]);

                jsonOut([
                    'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
                ]);

            /* ============================================================== 
               LATEST REFERRAL OF A CONVERSATION
            ============================================================== */

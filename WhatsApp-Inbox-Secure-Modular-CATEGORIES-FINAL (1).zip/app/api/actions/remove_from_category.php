<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) { http_response_code(403); exit; }

$payload = readJsonBody();
$categoryId = (int)($payload['category_id'] ?? 0);
$phones = $payload['phones'] ?? [];

if ($categoryId <= 0 || !is_array($phones) || !$phones) jsonOut(['error' => 'Category and selected chats are required.'], 400);

$phones = array_values(array_unique(array_filter(
    array_map(static fn($v) => trim((string)$v), $phones),
    static fn($v) => $v !== ''
)));
if (count($phones) > 200) jsonOut(['error' => 'You can remove up to 200 chats at once.'], 400);

$placeholders = [];
$params = [':category_id' => $categoryId];
foreach ($phones as $i => $phone) {
    $key = ':p' . $i;
    $placeholders[] = $key;
    $params[$key] = $phone;
}

$stmt = $pdo->prepare(
    "DELETE FROM whatsapp_chat_category_members WHERE category_id = :category_id AND customer_phone IN (" . implode(',', $placeholders) . ")"
);
$stmt->execute($params);

jsonOut(['ok' => true, 'category_id' => $categoryId, 'removed' => $stmt->rowCount()]);

<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $params = [];
                $where = buildLeadFilters($filters, $params);
                $where[] = "m.reference_code IS NOT NULL";
                $where[] = "m.reference_code <> ''";

                $whereSql = implode(' AND ', $where);

                $summaryStmt = $pdo->prepare("
                    SELECT
                        COUNT(*) AS referral_messages,
                        COUNT(DISTINCT m.customer_phone) AS unique_customers,
                        COUNT(DISTINCT m.reference_code) AS unique_references
                    FROM whatsapp_conversation_messages m
                    WHERE $whereSql
                ");

                $summaryStmt->execute($params);

                $summary = $summaryStmt->fetch(PDO::FETCH_ASSOC) ?: [
                    'referral_messages' => 0,
                    'unique_customers' => 0,
                    'unique_references' => 0,
                ];

                $refStmt = $pdo->prepare("
                    SELECT
                        m.reference_code,
                        COUNT(*) AS message_count,
                        COUNT(DISTINCT m.customer_phone) AS customer_count,
                        MAX(
                            COALESCE(m.received_at, m.message_timestamp)
                        ) AS last_seen,
                        GROUP_CONCAT(
                            DISTINCT NULLIF(m.product_code, '')
                            ORDER BY m.product_code
                            SEPARATOR ', '
                        ) AS products,
                        GROUP_CONCAT(
                            DISTINCT NULLIF(m.source_type, '')
                            ORDER BY m.source_type
                            SEPARATOR ', '
                        ) AS source_types,
                        GROUP_CONCAT(
                            DISTINCT NULLIF(m.source_platform, '')
                            ORDER BY m.source_platform
                            SEPARATOR ', '
                        ) AS platforms
                    FROM whatsapp_conversation_messages m
                    WHERE $whereSql
                    GROUP BY m.reference_code
                    ORDER BY message_count DESC, last_seen DESC
                    LIMIT 100
                ");

                $refStmt->execute($params);

                jsonOut([
                    'summary' => $summary,
                    'data' => $refStmt->fetchAll(PDO::FETCH_ASSOC),
                ]);

            /* ==============================================================
               CUSTOMER CALL TRACKING

               Data model:
               - whatsapp_conversation_messages = all WhatsApp customers/messages
               - whatsapp_customer_call_status  = called customers only
               - All       => every conversation customer + called status when available
               - Called    => read directly from whatsapp_customer_call_status
               - Not called=> read from conversations, excluding customers marked called
            ============================================================== */

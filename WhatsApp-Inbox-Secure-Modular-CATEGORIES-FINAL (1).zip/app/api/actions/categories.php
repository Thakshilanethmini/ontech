<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) { http_response_code(403); exit; }

$stmt = $pdo->query(<<<'SQL'
SELECT
    c.id,
    c.name,
    c.created_at,
    c.updated_at,
    COUNT(DISTINCT m.customer_phone) AS chat_count
FROM whatsapp_chat_categories c
LEFT JOIN whatsapp_chat_category_members cm ON cm.category_id = c.id
LEFT JOIN whatsapp_conversation_messages m ON m.customer_phone = cm.customer_phone
GROUP BY c.id, c.name, c.created_at, c.updated_at
ORDER BY c.name ASC, c.id ASC
SQL);

jsonOut(['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);

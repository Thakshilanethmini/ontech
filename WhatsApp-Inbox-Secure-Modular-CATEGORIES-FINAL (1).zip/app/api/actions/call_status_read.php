<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $phone = trim((string)($_GET['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $stmt = $pdo->prepare("\n                    SELECT cs.customer_phone, cs.customer_name, cs.call_status, cs.attempt_count,\n                           cs.called_at, cs.chat_bucket, cs.conversation_message_id, cs.updated_at\n                    FROM whatsapp_customer_call_status cs\n                    INNER JOIN whatsapp_conversation_messages m ON m.id = cs.conversation_message_id\n                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                    ORDER BY m.id DESC, cs.updated_at DESC, cs.id DESC\n                    LIMIT 1\n                ");
                $stmt->execute([':phone' => $phone]);

                $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [
                    'customer_phone' => $phone,
                    'customer_name' => null,
                    'call_status' => 'not_called',
                    'attempt_count' => 0,
                    'called_at' => null,
                    'chat_bucket' => 'inbox',
                    'conversation_message_id' => null,
                    'updated_at' => null,
                ];

                $row['attempt_count'] = (int)($row['attempt_count'] ?? 0);
                jsonOut(['data' => $row]);

            /* ==============================================================\n               UPDATE CUSTOMER CALL STATE\n            ============================================================== */

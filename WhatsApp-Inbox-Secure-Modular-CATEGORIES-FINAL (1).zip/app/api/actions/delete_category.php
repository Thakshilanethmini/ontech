<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) { http_response_code(403); exit; }

$payload = readJsonBody();
$id = (int)($payload['category_id'] ?? 0);
if ($id <= 0) jsonOut(['error' => 'Invalid category.'], 400);

$stmt = $pdo->prepare("DELETE FROM whatsapp_chat_categories WHERE id = :id");
$stmt->execute([':id' => $id]);
if ($stmt->rowCount() === 0) jsonOut(['error' => 'Category not found.'], 404);

jsonOut(['ok' => true, 'deleted' => true, 'category_id' => $id]);

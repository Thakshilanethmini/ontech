<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $payload = readJsonBody();

                $phones = $payload['phones'] ?? [];
                $text = trim((string)($payload['message'] ?? ''));

                if (!is_array($phones)) {
                    jsonOut(
                        ['error' => 'phones must be an array'],
                        400
                    );
                }

                $phones = array_values(array_unique(array_filter(
                    array_map(
                        static fn($v) => trim((string)$v),
                        $phones
                    ),
                    static fn($v) => $v !== ''
                )));

                if (!$phones) {
                    jsonOut(
                        ['error' => 'No chats selected'],
                        400
                    );
                }

                if (count($phones) > 50) {
                    jsonOut(
                        ['error' => 'Bulk send is limited to 50 chats per action.'],
                        400
                    );
                }

                if ($text === '') {
                    jsonOut(
                        ['error' => 'message is required'],
                        400
                    );
                }

                $success = [];
                $failed = [];

                foreach ($phones as $phone) {

                    try {

                        $nameStmt = $pdo->prepare("
                            SELECT customer_name
                            FROM whatsapp_conversation_messages
                            WHERE customer_phone = :phone
                              AND customer_name IS NOT NULL
                              AND customer_name <> ''
                            ORDER BY id DESC
                            LIMIT 1
                        ");

                        $nameStmt->execute([
                            ':phone' => $phone,
                        ]);

                        $customerName =
                            $nameStmt->fetchColumn() ?: null;

                        $result = sendWhatsAppText(
                            $pdo,
                            $phone,
                            $text,
                            $customerName
                        );

                        $success[] = $result;

                        usleep(150000);

                    } catch (Throwable $e) {

                        error_log('[WhatsApp Inbox] bulk send failed for ' . $phone . ': ' . $e->getMessage());
                        $failed[] = [
                            'phone' => $phone,
                            'error' => 'Message could not be sent for this number.',
                        ];
                    }
                }

                jsonOut([
                    'ok' => count($failed) === 0,
                    'sent_count' => count($success),
                    'failed_count' => count($failed),
                    'sent' => $success,
                    'failed' => $failed,
                ]);


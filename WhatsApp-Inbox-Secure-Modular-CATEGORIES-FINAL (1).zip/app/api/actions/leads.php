<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $limit = min(1000, max(10, (int)($_GET['limit'] ?? 500)));

                $params = [];
                $where = buildLeadFilters($filters, $params, 'm');

                switch ($filters['sort']) {
                    case 'oldest':
                        $order = 'COALESCE(m.received_at, m.message_timestamp) ASC, m.id ASC';
                        break;
                    case 'name':
                        $order = 'COALESCE(m.customer_name, m.customer_phone) ASC, m.id DESC';
                        break;
                    default:
                        $order = 'COALESCE(m.received_at, m.message_timestamp) DESC, m.id DESC';
                        break;
                }

                $sql = "\n                    SELECT\n                        m.id AS message_id,\n                        m.whatsapp_message_id,\n                        m.customer_phone,\n                        m.customer_name,\n                        m.direction,\n                        m.message_type,\n                        m.message_text,\n                        m.message_source,\n                        m.status AS message_status,\n                        m.phone_number_id,\n                        m.received_at,\n                        m.message_timestamp,\n                        m.reference_code,\n                        m.product_code,\n                        m.source_type,\n                        m.source_platform,\n                        m.content_title,\n                        m.headline,\n                        m.body,\n                        m.media_type,\n                        m.image_url,\n                        m.video_url,\n                        m.thumbnail_url,\n                        m.source_id,\n                        m.source_url,\n                        m.ctwa_clid,\n                        m.campaign_name,\n                        m.ad_name,\n                        m.creative_name,\n                        COALESCE(cs.call_status, 'not_called') AS call_status,\n                        cs.conversation_message_id,\n                        cs.called_at,\n                        COALESCE(cs.attempt_count, 0) AS attempt_count\n                    FROM whatsapp_conversation_messages m\n                    LEFT JOIN whatsapp_customer_call_status cs\n                        ON cs.conversation_message_id = m.id\n                ";

                if ($where) {
                    $sql .= ' WHERE ' . implode(' AND ', $where);
                }

                $sql .= " ORDER BY $order LIMIT $limit";

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($rows as &$row) {
                    $row['message_id'] = (int)($row['message_id'] ?? 0);
                    $row['conversation_message_id'] = $row['conversation_message_id'] !== null
                        ? (int)$row['conversation_message_id']
                        : null;
                    $row['attempt_count'] = (int)($row['attempt_count'] ?? 0);
                }
                unset($row);

                jsonOut(['data' => $rows]);

            /* ==============================================================
               REFERENCE ANALYSIS
            ============================================================== */

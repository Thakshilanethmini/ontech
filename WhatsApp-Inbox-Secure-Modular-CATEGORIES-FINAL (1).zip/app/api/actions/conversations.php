<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $limit = min(
                    500,
                    max(10, (int)($_GET['limit'] ?? 300))
                );

                $params = [];
                $where = buildConversationFilters($filters, $params);

                $box = ((string)($_GET['box'] ?? 'inbox') === 'old') ? 'old' : 'inbox';
                $categoryId = (int)($filters['category_id'] ?? 0);
                if ($categoryId <= 0) {
                    if ($box === 'old') {
                        $where[] = "COALESCE(cs.chat_bucket, 'inbox') = 'old'";
                    } else {
                        $where[] = "COALESCE(cs.chat_bucket, 'inbox') = 'inbox'";
                    }
                }

                switch ($filters['sort']) {
                    case 'oldest':
                        $order = 'm.id ASC';
                        break;

                    case 'name':
                        $order = 'COALESCE(m.customer_name, m.customer_phone) ASC';
                        break;

                    case 'messages':
                        $order = 'total_messages DESC';
                        break;

                    default:
                        $order = 'm.id DESC';
                        break;
                }

                /*
                 * m = latest message for each customer.
                 * lr = latest referral-bearing message for the same customer.
                 * Both come from the SAME table.
                 */
                $sql = "
                    SELECT
                        m.id,
                        m.customer_phone,
                        m.customer_name,
                        m.message_text,
                        m.message_type,
                        m.message_source,
                        m.direction,
                        m.status,
                        m.message_timestamp,
                        COALESCE(cs.call_status, 'not_called') AS call_status,
                        cs.called_at,
                        cs.updated_at AS call_status_updated_at,

                        (
                            SELECT COUNT(*)
                            FROM whatsapp_conversation_messages c2
                            WHERE c2.customer_phone = m.customer_phone
                        ) AS total_messages,

                        lr.reference_code,
                        lr.product_code,
                        lr.source_platform,
                        lr.source_type,
                        lr.content_title,
                        lr.ctwa_clid,
                        lr.id AS referral_message_id

                    FROM whatsapp_conversation_messages m

                    INNER JOIN (
                        SELECT customer_phone, MAX(id) AS max_id
                        FROM whatsapp_conversation_messages
                        GROUP BY customer_phone
                    ) latest
                        ON latest.max_id = m.id

                    LEFT JOIN (
                        SELECT
                            customer_phone,
                            MAX(id) AS max_ref_id
                        FROM whatsapp_conversation_messages
                        WHERE has_referral = 1
                        GROUP BY customer_phone
                    ) latest_ref
                        ON latest_ref.customer_phone = m.customer_phone

                    LEFT JOIN whatsapp_conversation_messages lr
                        ON lr.id = latest_ref.max_ref_id
                    LEFT JOIN whatsapp_customer_call_status cs
                        ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                         = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                       AND cs.id = (
                            SELECT cs2.id
                            FROM whatsapp_customer_call_status cs2
                            WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs2.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                                = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                            ORDER BY cs2.updated_at DESC, cs2.id DESC
                            LIMIT 1
                       )
                       AND cs.id = (
                            SELECT cs2.id
                            FROM whatsapp_customer_call_status cs2
                            WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs2.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                                = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                            ORDER BY cs2.updated_at DESC, cs2.id DESC
                            LIMIT 1
                       )
                ";

                if ($where) {
                    $sql .= ' WHERE ' . implode(' AND ', $where);
                }

                $sql .= " ORDER BY $order LIMIT $limit";

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                jsonOut([
                    'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
                ]);

            /* ============================================================== 
               MESSAGES OF ONE CONVERSATION
            ============================================================== */

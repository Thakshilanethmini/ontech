<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $phone = trim((string)($_GET['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $stmt = $pdo->prepare(
                    "SELECT *
                     FROM whatsapp_conversation_messages
                     WHERE customer_phone = :phone
                       AND has_referral = 1
                     ORDER BY id DESC
                     LIMIT 1"
                );

                $stmt->execute([':phone' => $phone]);

                jsonOut([
                    'data' => $stmt->fetch(PDO::FETCH_ASSOC) ?: null
                ]);

            /* ==============================================================
               LEADS TABLE

               For call-status filtering the same storage rule is used here:
               - All       => lead/referral messages, with called status attached
               - Called    => whatsapp_customer_call_status is the source of truth
               - Not called=> lead/referral messages, excluding called customers
            ============================================================== */

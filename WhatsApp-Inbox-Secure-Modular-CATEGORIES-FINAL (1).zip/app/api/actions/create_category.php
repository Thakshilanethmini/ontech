<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) { http_response_code(403); exit; }

$payload = readJsonBody();
$name = trim((string)($payload['name'] ?? ''));

if ($name === '') jsonOut(['error' => 'Category name is required.'], 400);
if (mb_strlen($name) > 100) jsonOut(['error' => 'Category name must be 100 characters or fewer.'], 400);

try {
    $stmt = $pdo->prepare("INSERT INTO whatsapp_chat_categories (name) VALUES (:name)");
    $stmt->execute([':name' => $name]);
    $id = (int)$pdo->lastInsertId();
} catch (PDOException $e) {
    if ((string)$e->getCode() === '23000') {
        jsonOut(['error' => 'A category with this name already exists.'], 409);
    }
    throw $e;
}

jsonOut(['ok' => true, 'category' => ['id' => $id, 'name' => $name, 'chat_count' => 0]]);

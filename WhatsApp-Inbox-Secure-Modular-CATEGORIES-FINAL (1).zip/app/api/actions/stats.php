<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $normMsg = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cm.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)";
                $normStatus = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)";

                jsonOut([
                    'conversations' => (int)$pdo->query("\n                        SELECT COUNT(*)\n                        FROM (\n                            SELECT cm.customer_phone\n                            FROM whatsapp_conversation_messages cm\n                            LEFT JOIN whatsapp_customer_call_status cs\n                              ON $normStatus = $normMsg\n                            GROUP BY cm.customer_phone\n                            HAVING COALESCE(MAX(cs.chat_bucket), 'inbox') = 'inbox'\n                        ) x\n                    ")->fetchColumn(),

                    'old_conversations' => (int)$pdo->query("\n                        SELECT COUNT(*)\n                        FROM (\n                            SELECT cm.customer_phone\n                            FROM whatsapp_conversation_messages cm\n                            LEFT JOIN whatsapp_customer_call_status cs\n                              ON $normStatus = $normMsg\n                            GROUP BY cm.customer_phone\n                            HAVING MAX(cs.chat_bucket) = 'old'\n                        ) x\n                    ")->fetchColumn(),

                    'messages' => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_conversation_messages")->fetchColumn(),

                    'leads' => (int)$pdo->query("\n                        SELECT COUNT(DISTINCT customer_phone)\n                        FROM whatsapp_conversation_messages\n                        WHERE has_referral = 1\n                          AND customer_phone IS NOT NULL\n                          AND customer_phone <> ''\n                    ")->fetchColumn(),

                    'not_called' => (int)$pdo->query("
                        SELECT COUNT(*)
                        FROM whatsapp_conversation_messages m
                        WHERE m.has_referral = 1
                          AND m.customer_phone IS NOT NULL
                          AND m.customer_phone <> ''
                          AND NOT EXISTS (
                              SELECT 1
                              FROM whatsapp_customer_call_status cs
                              WHERE cs.conversation_message_id = m.id
                                AND cs.call_status IN ('called','rejected','try_again')
                          )
                    ")->fetchColumn(),

                    'called' => (int)$pdo->query("
                        SELECT COUNT(*)
                        FROM whatsapp_conversation_messages m
                        INNER JOIN whatsapp_customer_call_status cs
                            ON cs.conversation_message_id = m.id
                           AND cs.call_status = 'called'
                        WHERE m.has_referral = 1
                          AND m.customer_phone IS NOT NULL
                          AND m.customer_phone <> ''
                    ")->fetchColumn(),

                    'rejected' => (int)$pdo->query("
                        SELECT COUNT(*)
                        FROM whatsapp_conversation_messages m
                        INNER JOIN whatsapp_customer_call_status cs
                            ON cs.conversation_message_id = m.id
                           AND cs.call_status = 'rejected'
                        WHERE m.has_referral = 1
                          AND m.customer_phone IS NOT NULL
                          AND m.customer_phone <> ''
                    ")->fetchColumn(),

                    'try_again' => (int)$pdo->query("
                        SELECT COUNT(*)
                        FROM whatsapp_conversation_messages m
                        INNER JOIN whatsapp_customer_call_status cs
                            ON cs.conversation_message_id = m.id
                           AND cs.call_status = 'try_again'
                        WHERE m.has_referral = 1
                          AND m.customer_phone IS NOT NULL
                          AND m.customer_phone <> ''
                    ")->fetchColumn(),

                    'lead_messages' => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_conversation_messages WHERE has_referral = 1")->fetchColumn(),

                    'today' => (int)$pdo->query("\n                        SELECT COUNT(*)\n                        FROM whatsapp_conversation_messages\n                        WHERE DATE(message_timestamp) = CURDATE()\n                    ")->fetchColumn(),
                ]);

            /* ============================================================== 
               FILTER OPTIONS
            ============================================================== */

<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) { http_response_code(403); exit; }

$payload = readJsonBody();
$categoryId = (int)($payload['category_id'] ?? 0);
$phones = $payload['phones'] ?? [];

if ($categoryId <= 0) jsonOut(['error' => 'Invalid category.'], 400);
if (!is_array($phones)) jsonOut(['error' => 'phones must be an array'], 400);

$phones = array_values(array_unique(array_filter(
    array_map(static fn($v) => trim((string)$v), $phones),
    static fn($v) => $v !== ''
)));
if (!$phones) jsonOut(['error' => 'No chats selected.'], 400);
if (count($phones) > 200) jsonOut(['error' => 'You can add up to 200 chats at once.'], 400);

$cat = $pdo->prepare("SELECT id, name FROM whatsapp_chat_categories WHERE id = :id LIMIT 1");
$cat->execute([':id' => $categoryId]);
$category = $cat->fetch(PDO::FETCH_ASSOC);
if (!$category) jsonOut(['error' => 'Category not found.'], 404);

$placeholders = [];
$params = [];
foreach ($phones as $i => $phone) {
    $key = ':p' . $i;
    $placeholders[] = $key;
    $params[$key] = $phone;
}

$existingStmt = $pdo->prepare(
    "SELECT DISTINCT customer_phone FROM whatsapp_conversation_messages WHERE customer_phone IN (" . implode(',', $placeholders) . ")"
);
$existingStmt->execute($params);
$existing = array_map('strval', $existingStmt->fetchAll(PDO::FETCH_COLUMN));
if (!$existing) jsonOut(['error' => 'None of the selected chats exist in the database.'], 400);

$insert = $pdo->prepare(
    "INSERT INTO whatsapp_chat_category_members (category_id, customer_phone) VALUES (:category_id, :customer_phone) ON DUPLICATE KEY UPDATE customer_phone = VALUES(customer_phone)"
);
$added = 0;
foreach ($existing as $phone) {
    $insert->execute([':category_id' => $categoryId, ':customer_phone' => $phone]);
    if ($insert->rowCount() > 0) $added++;
}

jsonOut(['ok' => true, 'category' => $category, 'requested' => count($phones), 'available' => count($existing), 'added' => $added]);

<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                requirePostCsrf();
                $payload = readJsonBody();

                $phone = trim((string)($payload['phone'] ?? ''));
                $status = trim((string)($payload['status'] ?? ''));
                $candidateMessageId = isset($payload['conversation_message_id'])
                    ? (int)$payload['conversation_message_id']
                    : 0;

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                if (!in_array($status, ['not_called', 'called', 'rejected', 'try_again'], true)) {
                    jsonOut(['error' => 'Invalid call state'], 400);
                }

                $normalizedPhone = normalizeWhatsAppPhone($phone);
                if ($normalizedPhone === '') {
                    jsonOut(['error' => 'Invalid phone number'], 400);
                }

                $nameStmt = $pdo->prepare("\n                    SELECT customer_name\n                    FROM whatsapp_conversation_messages\n                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                      AND customer_name IS NOT NULL\n                      AND customer_name <> ''\n                    ORDER BY id DESC\n                    LIMIT 1\n                ");
                $nameStmt->execute([':phone' => $normalizedPhone]);
                $customerName = $nameStmt->fetchColumn() ?: null;

                $relatedMessageId = resolveRelatedConversationMessageId(
                    $pdo,
                    $normalizedPhone,
                    $candidateMessageId > 0 ? $candidateMessageId : null
                );
                if ($relatedMessageId === null) {
                    jsonOut(['error' => 'No related conversation message found for this customer.'], 400);
                }

                $tz = new DateTimeZone('Asia/Colombo');
                $now = (new DateTimeImmutable('now', $tz))->format('Y-m-d H:i:s');
                $pdo->beginTransaction();
                try {
                    $find = $pdo->prepare("SELECT id FROM whatsapp_customer_call_status WHERE conversation_message_id=:message_id LIMIT 1 FOR UPDATE");
                    $find->execute([':message_id' => $relatedMessageId]);
                    $existingId = $find->fetchColumn();

                    if ($existingId !== false) {
                        $up = $pdo->prepare("UPDATE whatsapp_customer_call_status
                            SET customer_phone = :upd_phone,
                                customer_name = COALESCE(:upd_name, customer_name),
                                call_status = :upd_status,
                                attempt_count = GREATEST(attempt_count, :upd_min_attempts),
                                called_at = CASE
                                    WHEN :upd_status_case = 'not_called' THEN called_at
                                    WHEN called_at IS NULL THEN :upd_called_at
                                    ELSE called_at
                                END,
                                updated_at = CURRENT_TIMESTAMP
                            WHERE id = :upd_id");
                        $up->execute([
                            ':upd_phone' => $normalizedPhone,
                            ':upd_name' => $customerName,
                            ':upd_status' => $status,
                            ':upd_min_attempts' => ($status === 'not_called' ? 0 : 1),
                            ':upd_status_case' => $status,
                            ':upd_called_at' => $now,
                            ':upd_id' => (int)$existingId,
                        ]);
                    } else {
                        $ins = $pdo->prepare("INSERT INTO whatsapp_customer_call_status
                            (customer_phone,customer_name,conversation_message_id,call_status,attempt_count,called_at,chat_bucket)
                            VALUES(:phone,:name,:message_id,:status,:attempt_count,:called_at,'inbox')");
                        $ins->execute([
                            ':phone'=>$normalizedPhone,
                            ':name'=>$customerName,
                            ':message_id'=>$relatedMessageId,
                            ':status'=>$status,
                            ':attempt_count'=>$status==='not_called'?0:1,
                            ':called_at'=>$status==='not_called'?null:$now,
                        ]);
                    }
                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    throw $e;
                }

                $readStmt = $pdo->prepare("SELECT customer_phone,customer_name,call_status,attempt_count,called_at,chat_bucket,conversation_message_id,updated_at
                    FROM whatsapp_customer_call_status
                    WHERE conversation_message_id=:message_id
                    ORDER BY id DESC LIMIT 1");
                $readStmt->execute([':message_id'=>$relatedMessageId]);
                $result = $readStmt->fetch(PDO::FETCH_ASSOC);
                if (!$result) jsonOut(['error'=>'Call status could not be read after update.'],500);
                $result['attempt_count']=(int)($result['attempt_count']??0);
                $result['conversation_message_id']=$result['conversation_message_id']!==null?(int)$result['conversation_message_id']:null;
                jsonOut(['ok'=>true,'data'=>$result]);

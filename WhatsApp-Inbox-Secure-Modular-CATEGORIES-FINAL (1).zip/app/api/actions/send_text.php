<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                requirePostCsrf();
                $payload = readJsonBody();

                $phone = trim((string)($payload['phone'] ?? ''));
                $text = trim((string)($payload['message'] ?? ''));

                if ($phone === '') {
                    jsonOut(
                        ['error' => 'phone is required'],
                        400
                    );
                }

                if ($text === '') {
                    jsonOut(
                        ['error' => 'message is required'],
                        400
                    );
                }

                $nameStmt = $pdo->prepare("
                    SELECT customer_name
                    FROM whatsapp_conversation_messages
                    WHERE customer_phone = :phone
                      AND customer_name IS NOT NULL
                      AND customer_name <> ''
                    ORDER BY id DESC
                    LIMIT 1
                ");

                $nameStmt->execute([
                    ':phone' => $phone,
                ]);

                $customerName =
                    $nameStmt->fetchColumn() ?: null;

                $result = sendWhatsAppText(
                    $pdo,
                    $phone,
                    $text,
                    $customerName
                );

                jsonOut([
                    'ok' => true,
                    'data' => $result,
                ]);

            /* ==============================================================
               SEND SAME TEXT TO MULTIPLE CHATS
            ============================================================== */

<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                requirePostCsrf();
                $payload = readJsonBody();

                $phones = $payload['phones'] ?? [];

                if (!is_array($phones)) {
                    jsonOut(
                        ['error' => 'phones must be an array'],
                        400
                    );
                }

                $phones = array_values(array_unique(array_filter(
                    array_map(
                        static fn($v) => trim((string)$v),
                        $phones
                    ),
                    static fn($v) => $v !== ''
                )));

                if (!$phones) {
                    jsonOut(
                        ['error' => 'No chats selected'],
                        400
                    );
                }

                if (count($phones) > 100) {
                    jsonOut(
                        ['error' => 'You can delete up to 100 chats at once.'],
                        400
                    );
                }

                $placeholders = [];
                $params = [];

                foreach ($phones as $i => $phone) {
                    $key = ':p' . $i;
                    $placeholders[] = $key;
                    $params[$key] = $phone;
                }

                $stmt = $pdo->prepare(
                    "DELETE FROM whatsapp_conversation_messages
                     WHERE customer_phone IN (" .
                    implode(',', $placeholders) .
                    ")"
                );

                $stmt->execute($params);

                $statusConditions = [];
                $statusParams = [];
                foreach ($phones as $i => $phone) {
                    $key = ':sp' . $i;
                    $statusConditions[] = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9) = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE($key, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)";
                    $statusParams[$key] = $phone;
                }

                $statusStmt = $pdo->prepare(
                    "DELETE FROM whatsapp_customer_call_status WHERE " . implode(' OR ', $statusConditions)
                );
                $statusStmt->execute($statusParams);

                $categoryDelete = $pdo->prepare(
                    "DELETE FROM whatsapp_chat_category_members WHERE customer_phone IN (" . implode(',', $placeholders) . ")"
                );
                $categoryDelete->execute($params);

                jsonOut([
                    'ok' => true,
                    'requested_chats' => count($phones),
                    'deleted_rows' => $stmt->rowCount(),
                ]);

            /* ==============================================================
               SEND ONE TEXT MESSAGE
            ============================================================== */

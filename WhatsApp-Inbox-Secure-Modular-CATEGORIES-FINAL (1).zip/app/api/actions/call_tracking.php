<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $limit = min(500, max(10, (int)($_GET['limit'] ?? 500)));

                $params = [];
                $where = buildConversationFilters($filters, $params);
                $where[] = "COALESCE(cs.chat_bucket, 'inbox') = 'inbox'";

                $callState = $filters['call_status'] ?? '';
                if (in_array($callState, ['not_called', 'called', 'rejected', 'try_again'], true)) {
                    $where[] = "COALESCE(cs.call_status, 'not_called') = :tracking_call_state";
                    $params[':tracking_call_state'] = $callState;
                }

                $sql = "\n                    SELECT\n                        m.customer_phone,\n                        m.customer_name,\n                        m.message_timestamp AS last_message_at,\n                        m.message_text AS last_message_text,\n                        COALESCE(cs.call_status, 'not_called') AS call_status,\n                        COALESCE(cs.attempt_count, 0) AS attempt_count,\n                        cs.called_at,\n                        cs.updated_at AS call_status_updated_at,\n                        (\n                            SELECT COUNT(*)\n                            FROM whatsapp_conversation_messages c2\n                            WHERE c2.customer_phone = m.customer_phone\n                        ) AS total_messages\n                    FROM whatsapp_conversation_messages m\n                    INNER JOIN (\n                        SELECT customer_phone, MAX(id) AS max_id\n                        FROM whatsapp_conversation_messages\n                        WHERE customer_phone IS NOT NULL\n                          AND customer_phone <> ''\n                        GROUP BY customer_phone\n                    ) latest\n                        ON latest.max_id = m.id\n                    LEFT JOIN whatsapp_customer_call_status cs\n                        ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                         = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                       AND cs.id = (\n                            SELECT cs2.id\n                            FROM whatsapp_customer_call_status cs2\n                            WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs2.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                                = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                            ORDER BY cs2.updated_at DESC, cs2.id DESC\n                            LIMIT 1\n                       )
                ";

                if ($where) {
                    $sql .= ' WHERE ' . implode(' AND ', $where);
                }

                $sql .= ' ORDER BY m.id DESC LIMIT ' . $limit;

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                jsonOut(['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);

            /* ==============================================================
               READ CUSTOMER NORMAL-CALL STATUS
            ============================================================== */

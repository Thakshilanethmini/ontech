<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                requirePostCsrf();
                $payload = readJsonBody();

                $phone = trim((string)($payload['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $stmt = $pdo->prepare(
                    "DELETE FROM whatsapp_conversation_messages
                     WHERE customer_phone = :phone"
                );
                $stmt->execute([':phone' => $phone]);

                $statusStmt = $pdo->prepare(
                    "DELETE FROM whatsapp_customer_call_status
                     WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                     = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)"
                );
                $statusStmt->execute([':phone' => $phone]);

                jsonOut([
                    'ok' => true,
                    'phone' => $phone,
                    'deleted_rows' => $stmt->rowCount(),
                ]);

            /* ==============================================================
               DELETE MULTIPLE CHATS
            ============================================================== */

<?php

declare(strict_types=1);

if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}


                $payload = readJsonBody();

                $phone = trim((string)($payload['phone'] ?? ''));
                $candidateMessageId = isset($payload['conversation_message_id'])
                    ? (int)$payload['conversation_message_id']
                    : 0;
                $statusAfter = trim((string)($payload['status_after'] ?? 'called'));
                if (!in_array($statusAfter, ['called', 'rejected', 'try_again'], true)) {
                    jsonOut(['error' => 'Invalid status_after'], 400);
                }

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $normalizedPhone = normalizeWhatsAppPhone($phone);
                if ($normalizedPhone === '') {
                    jsonOut(['error' => 'Invalid phone number'], 400);
                }

                $nameStmt = $pdo->prepare("\n                    SELECT customer_name\n                    FROM whatsapp_conversation_messages\n                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                      AND customer_name IS NOT NULL\n                      AND customer_name <> ''\n                    ORDER BY id DESC\n                    LIMIT 1\n                ");
                $nameStmt->execute([':phone' => $normalizedPhone]);
                $customerName = $nameStmt->fetchColumn() ?: null;

                $relatedMessageId = resolveRelatedConversationMessageId(
                    $pdo,
                    $normalizedPhone,
                    $candidateMessageId > 0 ? $candidateMessageId : null
                );
                if ($relatedMessageId === null) {
                    jsonOut(['error' => 'No related conversation message found for this customer.'], 400);
                }

                $tz = new DateTimeZone('Asia/Colombo');
                $now = (new DateTimeImmutable('now', $tz))->format('Y-m-d H:i:s');
                $pdo->beginTransaction();
                try {
                    $find = $pdo->prepare("SELECT id FROM whatsapp_customer_call_status WHERE conversation_message_id=:message_id LIMIT 1 FOR UPDATE");
                    $find->execute([':message_id'=>$relatedMessageId]);
                    $existingId = $find->fetchColumn();

                    if ($existingId !== false) {
                        $up = $pdo->prepare("UPDATE whatsapp_customer_call_status
                            SET customer_phone=:phone,
                                customer_name=COALESCE(:name,customer_name),
                                attempt_count=attempt_count+1,
                                call_status=:status_after,
                                called_at=:called_at,
                                updated_at=CURRENT_TIMESTAMP
                            WHERE id=:id");
                        $up->execute([
                            ':phone'=>$normalizedPhone,
                            ':name'=>$customerName,
                            ':status_after'=>$statusAfter,
                            ':called_at'=>$now,
                            ':id'=>(int)$existingId,
                        ]);
                    } else {
                        $ins = $pdo->prepare("INSERT INTO whatsapp_customer_call_status
                            (customer_phone,customer_name,conversation_message_id,call_status,attempt_count,called_at,chat_bucket)
                            VALUES(:phone,:name,:message_id,:status_after,1,:called_at,'inbox')");
                        $ins->execute([
                            ':phone'=>$normalizedPhone,
                            ':name'=>$customerName,
                            ':message_id'=>$relatedMessageId,
                            ':status_after'=>$statusAfter,
                            ':called_at'=>$now,
                        ]);
                    }
                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    throw $e;
                }

                $readStmt = $pdo->prepare("SELECT customer_phone,customer_name,call_status,attempt_count,called_at,chat_bucket,conversation_message_id,updated_at
                    FROM whatsapp_customer_call_status
                    WHERE conversation_message_id=:message_id
                    ORDER BY id DESC LIMIT 1");
                $readStmt->execute([':message_id'=>$relatedMessageId]);
                $result = $readStmt->fetch(PDO::FETCH_ASSOC);
                if (!$result) jsonOut(['error'=>'Attempt could not be read after update.'],500);
                $result['attempt_count']=(int)($result['attempt_count']??0);
                $result['conversation_message_id']=$result['conversation_message_id']!==null?(int)$result['conversation_message_id']:null;
                jsonOut(['ok'=>true,'data'=>$result]);

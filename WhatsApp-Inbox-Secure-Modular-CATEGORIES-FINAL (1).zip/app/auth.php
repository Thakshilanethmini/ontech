<?php

declare(strict_types=1);

function authRequired(): bool
{
    if (array_key_exists('waInboxRequireAuth', $GLOBALS)) {
        return (bool)$GLOBALS['waInboxRequireAuth'];
    }

    $env = getenv('WA_INBOX_REQUIRE_AUTH');
    if ($env !== false && $env !== '') {
        return filter_var($env, FILTER_VALIDATE_BOOLEAN);
    }

    // Secure-by-default: authentication is ON unless explicitly disabled.
    return true;
}

function authUsername(): string
{
    if (array_key_exists('waInboxUsername', $GLOBALS)) {
        return trim((string)$GLOBALS['waInboxUsername']);
    }

    return trim((string)(getenv('WA_INBOX_USERNAME') ?: ''));
}

function authPasswordHash(): string
{
    if (array_key_exists('waInboxPasswordHash', $GLOBALS)) {
        return trim((string)$GLOBALS['waInboxPasswordHash']);
    }

    return trim((string)(getenv('WA_INBOX_PASSWORD_HASH') ?: ''));
}

function authConfigured(): bool
{
    $username = authUsername();
    $hash = authPasswordHash();

    if ($username === '' || $hash === '') {
        return false;
    }

    $info = password_get_info($hash);
    return !empty($info['algo']);
}

function authUser(): ?string
{
    return !empty($_SESSION['wa_inbox_auth_user'])
        ? (string)$_SESSION['wa_inbox_auth_user']
        : null;
}

function isAuthenticated(): bool
{
    if (!authRequired()) {
        return true;
    }

    $user = authUser();
    if ($user === null) {
        return false;
    }

    $last = (int)($_SESSION['wa_inbox_auth_last_activity'] ?? 0);
    $now = time();

    // 8-hour idle timeout.
    if ($last > 0 && ($now - $last) > 8 * 3600) {
        logoutUser();
        return false;
    }

    $_SESSION['wa_inbox_auth_last_activity'] = $now;
    return true;
}

function requireAuth(bool $json = false): void
{
    if (!authRequired() || isAuthenticated()) {
        return;
    }

    if ($json) {
        if (!authConfigured()) {
            jsonOut(['error' => 'Authentication is not configured on this server.'], 503);
        }

        jsonOut(['error' => 'Authentication required.'], 401);
    }

    $next = (string)($_SERVER['REQUEST_URI'] ?? 'index.php');
    header('Location: login.php?next=' . rawurlencode($next), true, 302);
    exit;
}

function attemptLogin(string $username, string $password): bool
{
    rateLimit('login', 8, 300);

    if (!authConfigured()) {
        return false;
    }

    if (!hash_equals(authUsername(), trim($username))) {
        return false;
    }

    if (!password_verify($password, authPasswordHash())) {
        return false;
    }

    session_regenerate_id(true);
    $_SESSION['wa_inbox_auth_user'] = authUsername();
    $_SESSION['wa_inbox_auth_login_at'] = time();
    $_SESSION['wa_inbox_auth_last_activity'] = time();

    return true;
}

function logoutUser(): void
{
    unset(
        $_SESSION['wa_inbox_auth_user'],
        $_SESSION['wa_inbox_auth_login_at'],
        $_SESSION['wa_inbox_auth_last_activity']
    );

    session_regenerate_id(true);
}

<?php

declare(strict_types=1);

function jsonOut($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}

function cleanVal(?string $v): ?string
{
    $v = trim((string)$v);
    return $v === '' ? null : $v;
}

function readJsonBody(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '', true);

    if (!is_array($data)) {
        jsonOut(['error' => 'Invalid JSON body'], 400);
    }

    return $data;
}

function normalizeWhatsAppPhone(string $phone): string
{
    $phone = trim($phone);
    $phone = preg_replace('/[^\d+]/', '', $phone) ?? '';

    if (str_starts_with($phone, '+')) {
        $phone = substr($phone, 1);
    }

    if (preg_match('/^0\d{8,11}$/', $phone)) {
        $phone = '94' . substr($phone, 1);
    }

    $phone = preg_replace('/\D+/', '', $phone) ?? '';

    // WhatsApp E.164-like range. Keep this permissive enough for international leads.
    if ($phone === '' || strlen($phone) < 8 || strlen($phone) > 15) {
        return '';
    }

    return $phone;
}

<?php

declare(strict_types=1);

function graphApiPost(
    string $url,
    string $accessToken,
    array $payload
): array {
    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS => json_encode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        ),
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
        CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
    ]);

    $body = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    if ($body === false) {
        throw new RuntimeException(
            'Graph API connection failed: ' . $curlError
        );
    }

    $data = json_decode($body, true);

    if (!is_array($data)) {
        throw new RuntimeException(
            'Graph API returned invalid JSON. HTTP ' . $httpCode
        );
    }

    if (
        $httpCode < 200 ||
        $httpCode >= 300 ||
        isset($data['error'])
    ) {
        $message = $data['error']['message'] ?? 'Unknown Graph API error';
        $code = $data['error']['code'] ?? $httpCode;

        throw new RuntimeException(
            'WhatsApp API error [' . $code . ']: ' . $message
        );
    }

    return $data;
}


function sendWhatsAppText(
    PDO $pdo,
    string $to,
    string $text,
    ?string $customerName = null
): array {
    global $accessToken, $phoneNumberId, $graphApiVersion;

    if (
        !isset($accessToken) ||
        trim((string)$accessToken) === ''
    ) {
        throw new RuntimeException(
            'WhatsApp access token is not configured.'
        );
    }

    if (
        !isset($phoneNumberId) ||
        trim((string)$phoneNumberId) === ''
    ) {
        throw new RuntimeException(
            'WhatsApp phone number ID is not configured.'
        );
    }

    $storedPhone = trim($to);
    $to = normalizeWhatsAppPhone($to);
    $text = trim($text);

    if ($to === '') {
        throw new RuntimeException('Invalid recipient phone number.');
    }

    if ($text === '') {
        throw new RuntimeException('Message text is empty.');
    }

    if (mb_strlen($text) > 4096) {
        throw new RuntimeException(
            'Text message is too long. Maximum is 4096 characters.'
        );
    }

    $version = trim((string)($graphApiVersion ?? 'v23.0'));

    if ($version === '') {
        $version = 'v23.0';
    }

    $url =
        'https://graph.facebook.com/' .
        rawurlencode($version) . '/' .
        rawurlencode((string)$phoneNumberId) .
        '/messages';

    $apiResponse = graphApiPost(
        $url,
        (string)$accessToken,
        [
            'messaging_product' => 'whatsapp',
            'recipient_type' => 'individual',
            'to' => $to,
            'type' => 'text',
            'text' => [
                'preview_url' => false,
                'body' => $text,
            ],
        ]
    );

    $messageId =
        $apiResponse['messages'][0]['id'] ?? null;

    if (!$messageId) {
        throw new RuntimeException(
            'WhatsApp API accepted the request but did not return a message ID.'
        );
    }

    $timestamp = date('Y-m-d H:i:s');

    $stmt = $pdo->prepare("
        INSERT INTO whatsapp_conversation_messages (
            whatsapp_message_id,
            customer_phone,
            customer_name,
            direction,
            message_type,
            message_text,
            message_source,
            has_referral,
            status,
            phone_number_id,
            message_timestamp,
            received_at,
            raw_payload
        )
        VALUES (
            :message_id,
            :customer_phone,
            :customer_name,
            'outgoing',
            'text',
            :message_text,
            'Manual Reply',
            0,
            'sent',
            :phone_number_id,
            :message_timestamp,
            :received_at,
            :raw_payload
        )
        ON DUPLICATE KEY UPDATE
            customer_name =
                COALESCE(VALUES(customer_name), customer_name),
            message_text =
                VALUES(message_text),
            status =
                VALUES(status),
            updated_at =
                CURRENT_TIMESTAMP
    ");

    $stmt->execute([
        ':message_id' => $messageId,
        ':customer_phone' => $storedPhone,
        ':customer_name' => $customerName,
        ':message_text' => $text,
        ':phone_number_id' => $phoneNumberId,
        ':message_timestamp' => $timestamp,
        ':received_at' => $timestamp,
        ':raw_payload' => json_encode(
            [
                'source' => 'whatsapp_inbox',
                'api_response' => $apiResponse,
            ],
            JSON_UNESCAPED_UNICODE |
            JSON_UNESCAPED_SLASHES
        ),
    ]);

    return [
        'to' => $to,
        'message_id' => $messageId,
        'status' => 'sent',
    ];
}

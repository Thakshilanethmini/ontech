<?php

declare(strict_types=1);

function ensureCallTrackingTable(PDO $pdo): void
{
    $pdo->exec("\n        CREATE TABLE IF NOT EXISTS whatsapp_customer_call_status (\n            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n            customer_phone VARCHAR(32) NOT NULL,\n            customer_name VARCHAR(255) NULL,\n            conversation_message_id BIGINT UNSIGNED NULL,\n            call_status ENUM('not_called','called','rejected','try_again') NOT NULL DEFAULT 'not_called',\n            attempt_count INT UNSIGNED NOT NULL DEFAULT 0,\n            called_at DATETIME NULL,\n            chat_bucket ENUM('inbox','old') NOT NULL DEFAULT 'inbox',\n            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n            PRIMARY KEY (id),\n            KEY idx_call_customer_phone (customer_phone),\n            KEY idx_call_status (call_status),\n            KEY idx_call_related_message (conversation_message_id),\n            KEY idx_called_at (called_at),\n            KEY idx_chat_bucket (chat_bucket)\n        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci\n    ");

    $dbName = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();

    $columnExists = static function (string $column) use ($pdo, $dbName): bool {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=:schema AND TABLE_NAME='whatsapp_customer_call_status' AND COLUMN_NAME=:column");
        $stmt->execute([':schema'=>$dbName, ':column'=>$column]);
        return (int)$stmt->fetchColumn() > 0;
    };
    $indexExists = static function (string $indexName) use ($pdo, $dbName): bool {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=:schema AND TABLE_NAME='whatsapp_customer_call_status' AND INDEX_NAME=:index_name");
        $stmt->execute([':schema'=>$dbName, ':index_name'=>$indexName]);
        return (int)$stmt->fetchColumn() > 0;
    };

    try {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status MODIFY call_status ENUM('uncalled','not_called','called','rejected','try_again') NOT NULL DEFAULT 'not_called'");
    } catch (Throwable $e) {}

    if (!$columnExists('conversation_message_id')) {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD COLUMN conversation_message_id BIGINT UNSIGNED NULL AFTER customer_name");
    }
    if (!$columnExists('attempt_count')) {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD COLUMN attempt_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER call_status");
    }
    if (!$columnExists('called_at')) {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD COLUMN called_at DATETIME NULL AFTER attempt_count");
    }
    if (!$columnExists('chat_bucket')) {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD COLUMN chat_bucket ENUM('inbox','old') NOT NULL DEFAULT 'inbox' AFTER called_at");
    }

    // IMPORTANT: statuses are per conversation message, not per customer.
    if ($indexExists('uq_customer_phone')) {
        try { $pdo->exec("ALTER TABLE whatsapp_customer_call_status DROP INDEX uq_customer_phone"); }
        catch (Throwable $e) {}
    }
    if (!$indexExists('idx_call_customer_phone')) {
        try { $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD KEY idx_call_customer_phone (customer_phone)"); }
        catch (Throwable $e) {}
    }
    if (!$indexExists('idx_call_related_message')) {
        try { $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD KEY idx_call_related_message (conversation_message_id)"); }
        catch (Throwable $e) {}
    }

    $pdo->exec("UPDATE whatsapp_customer_call_status SET call_status='not_called' WHERE call_status='uncalled'");
    $pdo->exec("UPDATE whatsapp_customer_call_status SET attempt_count=1 WHERE call_status IN ('called','rejected','try_again') AND attempt_count=0");
    $pdo->exec("ALTER TABLE whatsapp_customer_call_status MODIFY call_status ENUM('not_called','called','rejected','try_again') NOT NULL DEFAULT 'not_called'");

    // Back-fill legacy rows without a relation. Prefer lead/referral messages.
    $pdo->exec("\n        UPDATE whatsapp_customer_call_status cs
        INNER JOIN (\n            SELECT RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9) AS phone9,\n                   MAX(id) AS max_message_id\n            FROM whatsapp_conversation_messages\n            WHERE has_referral=1 AND customer_phone IS NOT NULL AND customer_phone<>''\n            GROUP BY RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n        ) lm ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)=lm.phone9\n        SET cs.conversation_message_id=lm.max_message_id\n        WHERE cs.conversation_message_id IS NULL\n    ");

    $pdo->exec("\n        UPDATE whatsapp_customer_call_status cs
        INNER JOIN (
            SELECT RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9) AS phone9,
                   MAX(id) AS max_message_id
            FROM whatsapp_conversation_messages
            WHERE customer_phone IS NOT NULL AND customer_phone<>''
            GROUP BY RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
        ) lm ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)=lm.phone9
        SET cs.conversation_message_id=lm.max_message_id
        WHERE cs.conversation_message_id IS NULL
    ");

    $attemptTableExists=(int)$pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='whatsapp_customer_call_attempts'")->fetchColumn()>0;
    if ($attemptTableExists) {
        $pdo->exec("\n            UPDATE whatsapp_customer_call_status cs
            INNER JOIN (SELECT customer_phone,COUNT(*) AS cnt FROM whatsapp_customer_call_attempts GROUP BY customer_phone) a
              ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)=RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(a.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
            SET cs.attempt_count=GREATEST(cs.attempt_count,a.cnt),
                cs.call_status=CASE WHEN cs.call_status='not_called' AND a.cnt>0 THEN 'called' ELSE cs.call_status END,
                cs.called_at=CASE WHEN cs.called_at IS NULL AND a.cnt>0 THEN CURRENT_TIMESTAMP ELSE cs.called_at END
        ");
    }
    $pdo->exec("DROP TABLE IF EXISTS whatsapp_customer_call_attempts");
}

function resolveRelatedConversationMessageId(PDO $pdo, string $phone, ?int $candidateId = null): ?int
{
    $phone = trim($phone);
    if ($phone === '') {
        return null;
    }

    $phoneNorm = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)";
    $candidate = (int)($candidateId ?? 0);

    if ($candidate > 0) {
        $stmt = $pdo->prepare("\n            SELECT id\n            FROM whatsapp_conversation_messages\n            WHERE id = :id\n              AND $phoneNorm = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n            LIMIT 1\n        ");
        $stmt->execute([
            ':id' => $candidate,
            ':phone' => $phone,
        ]);
        $valid = $stmt->fetchColumn();
        if ($valid !== false) {
            return (int)$valid;
        }
    }

    $stmt = $pdo->prepare("\n        SELECT id\n        FROM whatsapp_conversation_messages\n        WHERE $phoneNorm = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n        ORDER BY id DESC\n        LIMIT 1\n    ");
    $stmt->execute([':phone' => $phone]);

    $id = $stmt->fetchColumn();
    return $id === false ? null : (int)$id;
}

function getCallStatusRows(PDO $pdo, array $filters = [], int $limit = 500): array
{
    $limit = min(500, max(10, $limit));
    $params = [];
    $where = buildConversationFilters($filters, $params);

    $sql = "
        SELECT
            m.customer_phone,
            m.customer_name,
            m.message_timestamp AS last_message_at,
            m.message_text AS last_message_text,
            m.direction AS last_message_direction,
            m.message_source AS last_message_source,
            (
                SELECT COUNT(*)
                FROM whatsapp_conversation_messages c2
                WHERE c2.customer_phone = m.customer_phone
            ) AS total_messages,
            COALESCE(cs.call_status, 'not_called') AS call_status,
            cs.called_at,
            cs.updated_at AS call_status_updated_at
        FROM whatsapp_conversation_messages m
        INNER JOIN (
            SELECT customer_phone, MAX(id) AS max_id
            FROM whatsapp_conversation_messages
            GROUP BY customer_phone
        ) latest
            ON latest.max_id = m.id
        LEFT JOIN whatsapp_customer_call_status cs
            ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
             = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
           AND cs.id = (
                SELECT cs2.id
                FROM whatsapp_customer_call_status cs2
                WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs2.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                    = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                ORDER BY cs2.updated_at DESC, cs2.id DESC
                LIMIT 1
           )
    ";

    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }

    $sql .= "
        ORDER BY
            CASE WHEN COALESCE(cs.call_status, 'not_called') = 'not_called' THEN 0 ELSE 1 END ASC,
            m.id DESC
        LIMIT $limit
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


function ensureCategoryTables(PDO $pdo): void
{
    $pdo->exec("\n        CREATE TABLE IF NOT EXISTS whatsapp_chat_categories (\n            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n            name VARCHAR(100) NOT NULL,\n            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n            PRIMARY KEY (id),\n            UNIQUE KEY uq_chat_category_name (name)\n        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci\n    ");

    $pdo->exec("\n        CREATE TABLE IF NOT EXISTS whatsapp_chat_category_members (\n            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n            category_id BIGINT UNSIGNED NOT NULL,\n            customer_phone VARCHAR(64) NOT NULL,\n            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n            PRIMARY KEY (id),\n            UNIQUE KEY uq_category_phone (category_id, customer_phone),\n            KEY idx_category_id (category_id),\n            KEY idx_category_phone (customer_phone),\n            CONSTRAINT fk_category_member_category\n                FOREIGN KEY (category_id) REFERENCES whatsapp_chat_categories(id)\n                ON DELETE CASCADE\n        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci\n    ");
}

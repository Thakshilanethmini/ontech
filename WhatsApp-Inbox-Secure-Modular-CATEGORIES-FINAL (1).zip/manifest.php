<?php

declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';
requireAuth(true);

header('Content-Type: application/manifest+json; charset=utf-8');
header('Cache-Control: private, no-store');

echo json_encode([
    'name' => 'WhatsApp Inbox',
    'short_name' => 'Inbox',
    'description' => 'WhatsApp inbox and lead management dashboard.',
    'start_url' => './index.php',
    'scope' => './',
    'display' => 'standalone',
    'background_color' => '#eef2f6',
    'theme_color' => '#25d366',
    'icons' => [
        [
            'src' => 'assets/icon.svg',
            'sizes' => '192x192',
            'type' => 'image/svg+xml',
            'purpose' => 'any maskable',
        ],
        [
            'src' => 'assets/icon.svg',
            'sizes' => '512x512',
            'type' => 'image/svg+xml',
            'purpose' => 'any maskable',
        ],
    ],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

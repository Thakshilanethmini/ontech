<?php

// Copy this file's values into environment variables or into config.php.
// Do NOT put real secrets into a file that you commit to Git.

$waInboxRequireAuth = true;
$waInboxUsername = 'admin';
$waInboxPasswordHash = 'PASTE_PASSWORD_HASH_HERE';

$dbHost = 'localhost';
$dbPort = '3306';
$dbName = 'YOUR_DATABASE_NAME';
$dbUser = 'YOUR_DATABASE_USER';
$dbPass = 'YOUR_DATABASE_PASSWORD';
$dbCharset = 'utf8mb4';

$accessToken = 'YOUR_WHATSAPP_SYSTEM_USER_ACCESS_TOKEN';
$phoneNumberId = 'YOUR_WHATSAPP_PHONE_NUMBER_ID';
$graphApiVersion = 'v23.0';

// Recommended environment variables:
// DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS
// WA_ACCESS_TOKEN, WA_PHONE_NUMBER_ID, WA_GRAPH_API_VERSION
// WA_INBOX_USERNAME, WA_INBOX_PASSWORD_HASH, WA_INBOX_REQUIRE_AUTH

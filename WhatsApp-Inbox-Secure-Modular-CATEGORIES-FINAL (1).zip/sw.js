const CACHE_NAME = 'wa-inbox-v3';
const STATIC_ASSETS = [
  './assets/css/app.css?v=2',
  './assets/js/app.js?v=2',
  './assets/icon.svg'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys
        .filter(key => key !== CACHE_NAME)
        .map(key => caches.delete(key))
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;

  const requestUrl = new URL(event.request.url);
  if (requestUrl.origin !== self.location.origin) return;

  // Never cache PHP pages, API responses, manifests, login state or CSRF tokens.
  if (requestUrl.pathname.endsWith('.php')) return;

  event.respondWith(
    fetch(event.request)
      .then(response => {
        if (response.ok && requestUrl.pathname.includes('/assets/')) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
        }
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});

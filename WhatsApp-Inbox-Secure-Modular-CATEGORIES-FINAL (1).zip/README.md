# WhatsApp Inbox — Secure Modular Build

This package is the modularized version of the supplied `index_fixed.php` application. The original backend action set is preserved and split into separate handlers so another developer can maintain each part without editing one very large PHP file.

## 1. Folder structure

```text
whatsapp_inbox_secure/
├── index.php                    # Protected dashboard entry point
├── login.php                    # Secure login
├── logout.php                   # POST + CSRF logout
├── api.php                      # Protected API router
├── config.php                   # Server configuration / PDO / WhatsApp credentials
├── config.example.php           # Safe reference template
├── manifest.php                 # PWA manifest
├── sw.js                        # Static-asset-only service worker
├── .htaccess                    # Web-server protections
│
├── app/
│   ├── bootstrap.php            # Loads configuration and common services
│   ├── security.php             # Session, headers, CSRF, rate limiting
│   ├── auth.php                 # Authentication/session state
│   ├── helpers.php              # JSON, input and phone helpers
│   ├── database.php              # Call-tracking schema + DB helpers
│   ├── queries.php                # Reusable search/filter SQL
│   ├── quick_replies.php         # Quick-message library
│   ├── services/
│   │   └── whatsapp.php          # WhatsApp Cloud API send service
│   └── api/actions/              # One file per API action
│       ├── stats.php
│       ├── filter_options.php
│       ├── conversations.php
│       ├── messages.php
│       ├── referral.php
│       ├── leads.php
│       ├── reference_analysis.php
│       ├── call_tracking.php
│       ├── call_status_read.php
│       ├── call_status.php
│       ├── call_attempt.php
│       ├── move_chats.php
│       ├── delete_chat.php
│       ├── delete_chats.php
│       ├── send_text.php
│       └── bulk_send_text.php
│
├── resources/
│   └── dashboard.php             # HTML UI only
├── assets/
│   ├── css/app.css               # UI styling
│   ├── js/app.js                 # UI behavior/API calls
│   └── icon.svg
├── storage/
│   └── ratelimits/               # Runtime rate-limit state
└── tools/
    ├── create-password.php       # CLI password-hash helper
    └── check-install.php         # CLI installation/config checker
```

## 2. Important: configure `config.php`

Open `config.php` in the same folder as `index.php`.

Set these values:

```php
'username' => 'admin',
'password_hash' => 'PASTE_PASSWORD_HASH_HERE',

'db_host' => 'localhost',
'db_port' => '3306',
'db_name' => 'YOUR_DATABASE_NAME',
'db_user' => 'YOUR_DATABASE_USER',
'db_pass' => 'YOUR_DATABASE_PASSWORD',

'access_token' => 'YOUR_WHATSAPP_SYSTEM_USER_ACCESS_TOKEN',
'phone_number_id' => 'YOUR_WHATSAPP_PHONE_NUMBER_ID',
'graph_api_version' => 'v23.0',
```

Environment variables with the same names override the defaults in `config.php`, so secrets can also be kept outside the file.

## 3. Create the admin password hash

Run on the server:

```bash
php tools/create-password.php 'YourStrongPasswordHere'
```

Copy the printed hash into `config.php`:

```php
'password_hash' => '$2y$...'
```

Use a strong unique password of at least 12 characters.

## 4. Database prerequisite

The supplied application expects the existing table:

```text
whatsapp_conversation_messages
```

with the columns used by the original application, including customer/message/referral fields such as:

```text
id
whatsapp_message_id
customer_phone
customer_name
direction
message_type
message_text
message_source
status
phone_number_id
message_timestamp
received_at
raw_payload
has_referral
reference_code
product_code
source_type
source_platform
content_title
headline
body
media_type
image_url
video_url
thumbnail_url
source_id
source_url
ctwa_clid
campaign_name
ad_name
creative_name
```

The application automatically creates/migrates `whatsapp_customer_call_status` for call tracking. It does not fabricate or replace the existing WhatsApp message table.

## 5. Security included

- Secure-by-default authentication
- Session ID regeneration on successful login
- HttpOnly + SameSite Strict session cookies
- CSRF token validation for state-changing requests
- Same-origin validation for POST API requests when `Origin` is supplied
- Login and API rate limiting
- Request body size limit
- Security headers including CSP, frame protection and MIME sniffing protection
- PDO exceptions are logged server-side rather than exposed to visitors
- Prepared statements remain in the data layer
- Application, resource, storage and tools folders are blocked from direct web access
- `config.php`, backups, logs and environment files are blocked from web access
- Service worker does **not** cache PHP pages, login pages, API responses or CSRF tokens
- WhatsApp access token is never inserted into the HTML page

No web application can honestly be guaranteed “impossible to hack”. The package instead reduces common attack surfaces and keeps secrets server-side.

## 6. Quick messages included

### Customer details

Asks the customer for:
- Customer name
- Company / Business name
- Industry / Business type
- One phone number or two phone numbers for normal calls

### Call attempted — no answer

Uses the customer name and current Colombo time, tells the customer that the team tried to call, and asks for a convenient day/time to talk.

When this quick message is successfully sent from the open chat, the call attempt is recorded as `try_again` and the attempt count is updated.

## 7. Deployment

Upload the full folder as-is.

The public entry points are:

```text
/index.php
/login.php
/api.php?action=...
```

Do not make `app/`, `resources/`, `storage/` or `tools/` public. The included `.htaccess` rules also protect them when Apache configuration allows it.

Use HTTPS in production.

## 8. Installation check

After configuring `config.php`, run:

```bash
php tools/check-install.php
```

This checks PHP, required extensions, authentication configuration, DB connection and the expected WhatsApp message table without printing secrets.

## 9. Existing UI behavior retained

The modular build retains the original inbox, old-chat, lead, referral/reference analysis, filtering, message viewing, call status tracking, chat moving/deletion, individual send, bulk send and WhatsApp Web flows, while keeping the UI code in `resources/dashboard.php`, `assets/css/app.css` and `assets/js/app.js`.


## Chat categories

The dashboard now includes a **Categories** tab. Authenticated users can:

- Create named chat categories.
- Select multiple chats from Inbox or Old and add them to a category.
- Open a category as a full chat workspace using the existing conversation UI: search/filtering, message thread, referral details, call status/attempts, quick replies, WhatsApp Web, sending and chat deletion remain available.
- Remove selected chats from the open category without deleting the underlying WhatsApp conversation.
- Delete a category without deleting the chats themselves.

The category feature creates these tables automatically in the configured database:

```text
whatsapp_chat_categories
whatsapp_chat_category_members
```

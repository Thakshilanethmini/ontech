/* =========================================================================
   HELPERS
   ========================================================================= */
const $ = (id) => document.getElementById(id);
const $$ = (sel) => document.querySelectorAll(sel);

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => (
    {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]
));

function safeUrl(value) {
    try {
        const url = new URL(String(value || ''), window.location.origin);
        if (url.protocol === 'https:' || url.protocol === 'http:') {
            return url.href;
        }
    } catch (e) {}
    return null;
}

function api(action, params = {}) {
    const url = new URL('api.php', window.location.href);
    url.search = '';
    url.searchParams.set('action', action);

    Object.entries(params).forEach(([k, v]) => {
        if (v !== '' && v !== null && v !== undefined) {
            url.searchParams.set(k, v);
        }
    });

    return fetch(url.toString(), {
        credentials: 'same-origin',
        headers: { 'Accept':'application/json' }
    }).then(async r => {
        const text = await r.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error(text || ('HTTP ' + r.status));
        }
        if (!r.ok && !data.error) {
            throw new Error('HTTP ' + r.status);
        }
        return data;
    });
}

async function apiPost(action, payload = {}) {
    const url = new URL('api.php', window.location.href);
    url.search = '';
    url.searchParams.set('action', action);

    const response = await fetch(url.toString(), {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-CSRF-Token': CSRF_TOKEN
        },
        body: JSON.stringify(payload)
    });

    const text = await response.text();
    let data;

    try {
        data = JSON.parse(text);
    } catch (e) {
        throw new Error(text || ('HTTP ' + response.status));
    }

    if (!response.ok) {
        throw new Error(data.error || ('HTTP ' + response.status));
    }

    return data;
}

function fmtDateTime(s) {
    if (!s) return '—';

    const d = new Date(String(s).replace(' ', 'T'));
    if (isNaN(d)) return String(s);

    const now = new Date();
    const same = d.toDateString() === now.toDateString();

    if (same) {
        return d.toLocaleTimeString([], {
            hour:'2-digit',
            minute:'2-digit'
        });
    }

    return d.toLocaleDateString([], {
        day:'2-digit',
        month:'short'
    }) + ' ' + d.toLocaleTimeString([], {
        hour:'2-digit',
        minute:'2-digit'
    });
}

function fmtFull(s) {
    if (!s) return '—';

    const d = new Date(String(s).replace(' ', 'T'));
    return isNaN(d) ? String(s) : d.toLocaleString();
}

function initials(name, phone) {
    if (name) {
        return name
            .trim()
            .split(/\s+/)
            .slice(0,2)
            .map(w => w[0])
            .join('')
            .toUpperCase();
    }

    return String(phone || '?').slice(-2);
}

function colorClass(key) {
    let h = 0;
    for (const ch of String(key || '')) {
        h = (h * 31 + ch.charCodeAt(0)) % 5;
    }
    return 'a' + (h + 1);
}

function sourceBadge(source) {
    const s = String(source || 'Unknown');
    let cls = 'gray';

    if (s === 'Normal Chat') cls = 'gray';
    else if (/video/i.test(s)) cls = 'purple';
    else if (/flyer|image/i.test(s)) cls = 'amber';
    else if (/^Ad/i.test(s)) cls = 'blue';
    else cls = 'green';

    return `<span class="badge ${cls}">${esc(s)}</span>`;
}

function tickMark(status) {
    const s = String(status || '').toLowerCase();

    if (!s) return '';
    if (s === 'read') return '<span class="tick read">✓✓</span>';
    if (s === 'delivered') return '<span class="tick">✓✓</span>';
    if (s === 'sent') return '<span class="tick">✓</span>';
    if (s === 'failed') return '<span class="tick" style="color:#dc2626">✕</span>';

    return `<span class="tick">${esc(s)}</span>`;
}

/* =========================================================================
   PWA INSTALL
   ========================================================================= */
let deferredInstallPrompt = null;

window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    deferredInstallPrompt = event;

    const btn = $('installAppBtn');
    if (btn) {
        btn.style.display = '';
    }
});

window.addEventListener('appinstalled', () => {
    deferredInstallPrompt = null;
    const btn = $('installAppBtn');
    if (btn) {
        btn.style.display = 'none';
    }
});

async function promptInstallApp() {
    const btn = $('installAppBtn');

    if (!deferredInstallPrompt) {
        if (btn) {
            btn.style.display = 'none';
        }
        window.alert('Install is not available in this browser yet. Open the page in Chrome, Edge, or Safari and try again.');
        return;
    }

    deferredInstallPrompt.prompt();
    const choice = await deferredInstallPrompt.userChoice;

    if (choice && choice.outcome === 'accepted') {
        deferredInstallPrompt = null;
        if (btn) {
            btn.style.display = 'none';
        }
    }
}

/* =========================================================================
   QUICK REPLIES
   ========================================================================= */
let QUICK_REPLIES = [];

function customerDisplayName() {
    return String(state.customerName || $('chatName')?.textContent || 'Customer').trim() || 'Customer';
}

function currentColomboTime() {
    try {
        return new Intl.DateTimeFormat('en-LK', {
            timeZone: 'Asia/Colombo',
            dateStyle: 'medium',
            timeStyle: 'short'
        }).format(new Date());
    } catch (e) {
        return new Date().toLocaleString();
    }
}

function resolveQuickReplyText(item) {
    if (!item) return '';

    const replacements = {
        name: customerDisplayName(),
        call_time: currentColomboTime()
    };

    return String(item.message || '').replace(/\{([a-z_]+)\}/gi, (match, key) => {
        return Object.prototype.hasOwnProperty.call(replacements, String(key).toLowerCase())
            ? replacements[String(key).toLowerCase()]
            : match;
    });
}

async function loadQuickReplies() {
    try {
        const res = await api('quick_replies');
        QUICK_REPLIES = Array.isArray(res.data) ? res.data : [];
    } catch (e) {
        console.warn('quick replies:', e);
        QUICK_REPLIES = [];
    }
    populateQuickReplies();
}

function populateQuickReplies() {
    const select = $('quickReplySelect');
    if (!select) return;

    select.innerHTML =
        '<option value="">⚡ Quick reply — choose a ready message</option>' +
        QUICK_REPLIES.map(item =>
            `<option value="${esc(item.id)}">${esc(item.label)}</option>`
        ).join('');

    updateQuickReplyUI();
}

function getQuickReplyById(id) {
    return QUICK_REPLIES.find(item => item.id === id) || null;
}

function getSelectedQuickReply() {
    const select = $('quickReplySelect');
    if (!select || !select.value) return null;
    return getQuickReplyById(select.value);
}

function getSelectedQuickReplyText() {
    const item = getSelectedQuickReply();
    return item ? resolveQuickReplyText(item) : '';
}

function updateQuickReplyUI() {
    const select = $('quickReplySelect');
    const useBtn = $('useQuickReplyBtn');
    const sendBtn = $('sendQuickReplyBtn');

    if (!select) return;

    const item = getSelectedQuickReply();
    const hasReply = !!item && !!resolveQuickReplyText(item);
    const currentOnly = !!item?.current_chat_only;
    const hasTarget = currentOnly ? !!state.phone : (!!state.phone || state.selectedPhones.size > 0);

    if (useBtn) useBtn.disabled = !hasReply;
    if (sendBtn) sendBtn.disabled = !hasReply || !hasTarget;

    const hint = document.querySelector('.quick-reply-hint');
    if (hint) {
        hint.textContent = item?.auto_mark_call_attempt
            ? '📞 This message is for a completed call attempt; sending it will also record the attempt automatically.'
            : 'Choose a ready-made reply, personalize the placeholders, then send.';
    }
}

function useQuickReply() {
    const text = getSelectedQuickReplyText();
    if (!text) return;

    const textarea = $('messageComposer');
    if (!textarea) return;

    textarea.value = text;
    textarea.focus();
    textarea.setSelectionRange(textarea.value.length, textarea.value.length);
    updateComposerState();
    updateQuickReplyUI();
}

async function sendQuickReply() {
    const item = getSelectedQuickReply();
    const text = item ? resolveQuickReplyText(item) : '';
    if (!item || !text) return;

    if (item.current_chat_only && !state.phone) {
        window.alert('Please open the customer chat first.');
        return;
    }

    const textarea = $('messageComposer');
    if (!textarea) return;

    textarea.value = text;
    updateComposerState();

    /* Selected checkboxes take priority for normal bulk quick-send. */
    if (!item.current_chat_only && state.selectedPhones.size > 0) {
        await sendSelectedMessage();
    } else if (state.phone) {
        const sent = await sendCurrentMessage();
        if (!sent) return;
        if (item.auto_mark_call_attempt) {
            const attempt = await addCallAttempt(state.phone, state.currentMessageId, 'try_again');
            if (!attempt) return;
        }
    }
}

/* =========================================================================
   STATE
   ========================================================================= */
const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]')?.content || '';

const state = {
    phone: null,
    customerName: null,
    selectedPhones: new Set(),
    callStatus: 'not_called',
    callCalledAt: null,
    callAttemptCount: 0,
    callLastAt: null,
    currentMessageId: null,
    chatBox: 'inbox',
    auto: true,
    timer: null,
    view: 'inbox',
    categories: [],
    activeCategoryId: null,
    activeCategoryName: null,
    returnToAssignAfterCreate: false,

    filters: {
        q: '',
        source: '',
        platform: '',
        source_type: '',
        product: '',
        reference: '',
        referral: '',
        ctwa: '',
        message_type: '',
        date_from: '',
        date_to: '',
        sort: 'latest',
    },

    leadFilters: {
        q: '',
        platform: '',
        source_type: '',
        product: '',
        reference: '',
        ctwa: '',
        call_status: '',
        date_from: '',
        date_to: '',
        sort: 'latest',
    },
};

/* =========================================================================
   FILTER OPTIONS
   ========================================================================= */
async function loadFilterOptions() {
    try {
        const res = await api('filter_options');
        if (!res.data) return;

        const o = res.data;

        fillSelect('sourceFilter',      o.sources,       'All sources');
        fillSelect('platformFilter',    o.platforms,     'All platforms');
        fillSelect('sourceTypeFilter',  o.source_types,  'Any type');
        fillSelect('productFilter',     o.products,      'Any product');
        fillSelect('messageTypeFilter', o.message_types, 'Any msg type');

        fillSelect('leadPlatform',   o.platforms,     'All platforms');
        fillSelect('leadSourceType', o.source_types,  'Any source type');
        fillSelect('leadProduct',    o.products,      'Any product');
    } catch (e) {
        console.error('filter_options:', e);
    }
}

function fillSelect(id, values, placeholder) {
    const el = $(id);
    if (!el) return;

    const keep = el.value;

    el.innerHTML =
        `<option value="">${esc(placeholder)}</option>` +
        (values || [])
            .map(v => `<option value="${esc(v)}">${esc(v)}</option>`)
            .join('');

    if (keep) el.value = keep;
}

/* =========================================================================
   STATS
   ========================================================================= */
async function loadStats() {
    try {
        const s = await api('stats');
        if (s.error) return;

        $('s-conv').textContent     = s.conversations ?? 0;
        $('s-msg').textContent      = s.messages ?? 0;
        $('s-old').textContent      = s.old_conversations ?? 0;
        $('s-leads').textContent    = s.leads ?? 0;
        $('s-not-called').textContent = s.not_called ?? 0;
        $('s-called').textContent   = s.called ?? 0;
        $('s-rejected').textContent = s.rejected ?? 0;
        $('s-try-again').textContent = s.try_again ?? 0;
        $('s-today').textContent    = s.today ?? 0;
    } catch (e) {
        console.error('stats:', e);
    }
}

/* =========================================================================
   INBOX FILTERS UI
   ========================================================================= */
const filterInputMap = {
    searchInput:        'q',
    sourceFilter:       'source',
    platformFilter:     'platform',
    sourceTypeFilter:   'source_type',
    productFilter:      'product',
    referenceFilter:    'reference',
    referralFilter:     'referral',
    ctwaFilter:         'ctwa',
    messageTypeFilter:  'message_type',
    dateFrom:           'date_from',
    dateTo:             'date_to',
    sortFilter:         'sort',
};

function bindInboxFilters() {
    let timer = null;

    const apply = (debounce = true) => {
        clearTimeout(timer);

        const run = () => {
            loadConversations();
            renderFilterChips();
            updateAdvCount();
        };

        debounce ? timer = setTimeout(run, 250) : run();
    };

    Object.entries(filterInputMap).forEach(([id, key]) => {
        const el = $(id);
        if (!el) return;

        const evt =
            (el.tagName === 'INPUT' && el.type !== 'date')
                ? 'input'
                : 'change';

        el.addEventListener(evt, () => {
            state.filters[key] = el.value;
            apply(evt === 'input');
        });
    });

    $('toggleAdv').addEventListener('click', () => {
        $('advFilters').classList.toggle('hidden');
        $('toggleAdv').classList.toggle('active');
    });

    $$('.chip[data-range]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const r = btn.dataset.range;
            const from = new Date();
            const to   = new Date();

            if (r === 'today') {
                // Same day.
            } else if (r === '7') {
                from.setDate(from.getDate() - 6);
            } else if (r === '30') {
                from.setDate(from.getDate() - 29);
            } else if (r === 'month') {
                from.setDate(1);
            }

            const iso = d => {
                const local = new Date(
                    d.getTime() - d.getTimezoneOffset() * 60000
                );
                return local.toISOString().slice(0,10);
            };

            $('dateFrom').value = iso(from);
            $('dateTo').value   = iso(to);

            state.filters.date_from = iso(from);
            state.filters.date_to   = iso(to);

            loadConversations();
            renderFilterChips();
            updateAdvCount();
        });
    });

    $('filterChips').addEventListener('click', (e) => {
        if (e.target.closest('.chip.clear-all')) {
            clearAllInboxFilters();
        } else if (e.target.dataset.clear) {
            const key = e.target.dataset.clear;
            state.filters[key] = '';

            const id = Object.keys(filterInputMap)
                .find(k => filterInputMap[k] === key);

            if (id && $(id)) {
                $(id).value = '';
            }

            loadConversations();
            renderFilterChips();
            updateAdvCount();
        }
    });
}

function clearAllInboxFilters() {
    Object.keys(state.filters).forEach(k => {
        state.filters[k] = k === 'sort' ? 'latest' : '';
    });

    $('searchInput').value = '';
    $('sourceFilter').value = '';
    $('platformFilter').value = '';
    $('sourceTypeFilter').value = '';
    $('productFilter').value = '';
    $('referenceFilter').value = '';
    $('referralFilter').value = '';
    $('ctwaFilter').value = '';
    $('messageTypeFilter').value = '';
    $('dateFrom').value = '';
    $('dateTo').value = '';
    $('sortFilter').value = 'latest';

    loadConversations();
    renderFilterChips();
    updateAdvCount();
}

const filterLabels = {
    q: 'Search',
    source: 'Source',
    platform: 'Platform',
    source_type: 'Type',
    product: 'Product',
    reference: 'Ref',
    referral: 'Referral',
    ctwa: 'CTWA',
    message_type: 'Msg type',
    date_from: 'From',
    date_to: 'To',
};

function renderFilterChips() {
    const chips = [];

    Object.entries(state.filters).forEach(([k, v]) => {
        if (!v || k === 'sort') return;

        const label = filterLabels[k] || k;
        const val =
            k === 'referral'
                ? (v === 'yes' ? 'With referral' : 'No referral')
                : k === 'ctwa'
                    ? 'Has CLID'
                    : v;

        chips.push(
            `<span class="chip">${esc(label)}: ${esc(val)}
                <button data-clear="${esc(k)}" title="Remove">×</button>
             </span>`
        );
    });

    if (chips.length > 1) {
        chips.push(`<span class="chip clear-all">Clear all ×</span>`);
    }

    $('filterChips').innerHTML = chips.join('');
}

function countActiveInboxFilters() {
    let n = 0;

    [
        'source_type',
        'product',
        'reference',
        'referral',
        'ctwa',
        'message_type',
        'date_from',
        'date_to'
    ].forEach(k => {
        if (state.filters[k]) n++;
    });

    return n;
}

function updateAdvCount() {
    const n = countActiveInboxFilters();
    const badge = $('advCount');

    if (n > 0) {
        badge.textContent = n;
        badge.classList.remove('hidden');
        $('toggleAdv').classList.add('active');
        $('advFilters').classList.remove('hidden');
    } else {
        badge.classList.add('hidden');
    }
}

/* =========================================================================
   CONVERSATIONS
   ========================================================================= */
async function loadConversations() {
    try {
        const conversationParams = { ...state.filters, box: state.chatBox };
        if (state.view === 'category' && state.activeCategoryId) {
            conversationParams.category_id = state.activeCategoryId;
        }
        const res = await api('conversations', conversationParams);

        if (res.error) {
            $('convList').innerHTML =
                `<div class="empty"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        $('convCount').textContent = rows.length;

        const visiblePhones = new Set(
            rows.map(r => String(r.customer_phone || '')).filter(Boolean)
        );

        state.selectedPhones.forEach(phone => {
            if (!visiblePhones.has(phone)) {
                state.selectedPhones.delete(phone);
            }
        });

        if (!rows.length) {
            $('convList').innerHTML =
                '<div class="empty"><div class="big">🔍</div>No conversations match filters</div>';
            return;
        }

        $('convList').innerHTML = rows.map(r => {
            const name = r.customer_name || r.customer_phone || 'Unknown';
            const active =
                r.customer_phone === state.phone ? ' active' : '';

            const preview =
                r.direction === 'outgoing'
                    ? 'You: ' + (r.message_text || '')
                    : (r.message_text || '');

            const badges = [sourceBadge(r.message_source)];

            if (r.source_platform) {
                badges.push(
                    `<span class="badge blue">${esc(r.source_platform)}</span>`
                );
            }

            if (r.reference_code) {
                badges.push(
                    `<span class="badge green mono">${esc(r.reference_code)}</span>`
                );
            }

            const callStatus = normalizeCallState(r.call_status);
            badges.push(
                `<span class="call-status-badge ${callStatusCssClass(callStatus)}">${esc(callStatusLabel(callStatus))}</span>`
            );

            return `
                <div class="conv${active}" data-phone="${esc(r.customer_phone)}">
                    <div class="conv-select">
                        <input
                            type="checkbox"
                            class="conv-check"
                            data-phone="${esc(r.customer_phone)}"
                            ${state.selectedPhones.has(r.customer_phone) ? 'checked' : ''}
                            aria-label="Select ${esc(name)}"
                        >
                    </div>
                    <div class="avatar ${colorClass(r.customer_phone)}">
                        ${esc(initials(r.customer_name, r.customer_phone))}
                    </div>

                    <div class="conv-main">
                        <div class="conv-top">
                            <div class="conv-name">${esc(name)}</div>
                            <div class="conv-time">
                                ${esc(fmtDateTime(r.message_timestamp))}
                            </div>
                        </div>

                        <div class="conv-preview">
                            ${esc(preview).slice(0, 90)}
                        </div>

                        <div class="conv-badges">
                            ${badges.join('')}
                            <span class="count-pill">
                                ${esc(r.total_messages)} msgs
                            </span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        $$('.conv').forEach(el => {
            el.addEventListener('click', (event) => {
                if (event.target.closest('.conv-check')) {
                    return;
                }

                selectConversation(el.dataset.phone);
            });
        });

        $$('.conv-check').forEach(check => {
            check.addEventListener('click', (event) => {
                event.stopPropagation();

                const phone = check.dataset.phone || '';

                if (check.checked) {
                    state.selectedPhones.add(phone);
                } else {
                    state.selectedPhones.delete(phone);
                }

                updateSelectionUI();
            });
        });

        updateSelectionUI();
        if (state.view === 'inbox') {
            await loadCallTracking();
        }

    } catch (e) {
        $('convList').innerHTML =
            `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

/* =========================================================================
   SELECTION / BULK ACTIONS
   ========================================================================= */
function updateSelectionUI() {
    const count = state.selectedPhones.size;
    const deleteBtn = $('deleteSelected');
    const moveBtn = $('moveSelected');
    const sendSelectedBtn = $('sendSelectedBtn');
    const selectedCountText = $('selectedCountText');

    if (moveBtn) {
        moveBtn.disabled = count === 0;
        if (state.view === 'category') {
            moveBtn.textContent = count ? `↩ Remove from Category (${count})` : '↩ Remove from Category';
        } else {
            moveBtn.textContent = state.chatBox === 'old'
                ? '↩ Move to Inbox'
                : '📦 Move to Old';
        }
    }

    const categoryBtn = $('categorySelectedBtn');
    if (categoryBtn) {
        categoryBtn.disabled = count === 0;
        categoryBtn.classList.toggle('hidden', state.view === 'category');
        if (state.view !== 'category') {
            categoryBtn.textContent = count ? `🏷 Add to Category (${count})` : '🏷 Add to Category';
        }
    }

    if (deleteBtn) {
        deleteBtn.disabled = count === 0;
        deleteBtn.textContent = count
            ? `🗑 Delete (${count})`
            : '🗑 Delete';
    }

    if (selectedCountText) {
        selectedCountText.textContent =
            count === 1
                ? '1 chat selected'
                : `${count} chats selected`;
    }

    if (sendSelectedBtn) {
        sendSelectedBtn.disabled =
            count === 0 ||
            !String($('messageComposer')?.value || '').trim();
    }

    $$('.conv-check').forEach(check => {
        check.checked = state.selectedPhones.has(
            check.dataset.phone || ''
        );
    });

    const selectAllBtn = $('selectAllVisible');
    const visibleChecks = Array.from(
        document.querySelectorAll('.conv-check')
    );

    if (selectAllBtn) {
        const allVisibleSelected =
            visibleChecks.length > 0 &&
            visibleChecks.every(check =>
                state.selectedPhones.has(
                    check.dataset.phone || ''
                )
            );

        selectAllBtn.textContent =
            allVisibleSelected
                ? '☐ Clear visible'
                : '☑ Select all';
    }

    updateQuickReplyUI();
}

function selectAllVisibleChats() {
    const checks = Array.from(
        document.querySelectorAll('.conv-check')
    );

    if (!checks.length) {
        return;
    }

    const allSelected = checks.every(check =>
        state.selectedPhones.has(check.dataset.phone || '')
    );

    checks.forEach(check => {
        const phone = check.dataset.phone || '';

        if (allSelected) {
            state.selectedPhones.delete(phone);
        } else {
            state.selectedPhones.add(phone);
        }
    });

    const btn = $('selectAllVisible');

    if (btn) {
        btn.textContent = allSelected
            ? '☑ Select all'
            : '☐ Clear visible';
    }

    updateSelectionUI();
}

function resetSelectedChatUI() {
    $('chatAvatar').textContent = '–';
    $('chatAvatar').className = 'avatar';
    $('chatName').textContent = 'Select a conversation';
    $('chatSub').textContent = state.view === 'category'
        ? `Pick a chat from “${state.activeCategoryName || 'Category'}” to view messages`
        : (state.chatBox === 'old'
            ? 'Pick an old chat from the list to view messages'
            : 'Pick a chat from the Inbox list to view messages');

    state.callStatus = 'not_called';
    state.callCalledAt = null;
    state.callAttemptCount = 0;
    state.callLastAt = null;
    state.currentMessageId = null;
    state.customerName = null;
    updateCallStatusUI();

    $('thread').innerHTML =
        '<div class="empty" style="margin:auto">' +
        '<div class="big">💬</div>' +
        'No conversation selected</div>';

    $('detailsPanel').innerHTML =
        '<div class="empty">' +
        '<div class="big">📋</div>' +
        'No lead data</div>';

    updateComposerState();
}

function normalizeCallState(status) {
    const s = String(status || '').toLowerCase();
    return ['not_called', 'called', 'rejected', 'try_again'].includes(s)
        ? s
        : 'not_called';
}

function callStatusLabel(status) {
    const labels = {
        not_called: 'Not called',
        called: 'Called',
        rejected: 'Rejected',
        try_again: 'Try again',
    };
    return labels[normalizeCallState(status)] || 'Not called';
}

function callStatusCssClass(status) {
    return normalizeCallState(status).replace('_', '-');
}

function setCallStatusControls(data = {}) {
    state.callStatus = normalizeCallState(data.call_status);
    state.callCalledAt = data.called_at || null;
    state.callAttemptCount = Number(data.attempt_count || 0);
    state.callLastAt = data.called_at || null;
    state.chatBox = String(data.chat_bucket || state.chatBox || 'inbox') === 'old'
        ? 'old'
        : 'inbox';
    updateCallStatusUI();
}

function updateCallStatusUI() {
    const select = $('chatCallStatus');
    const last = $('chatCallLast');
    const addAttemptBtn = $('addCallAttemptBtn');
    const moveBtn = $('moveChatBtn');

    if (select) {
        select.disabled = !state.phone;
        select.value = normalizeCallState(state.callStatus);
        select.classList.remove('called', 'rejected', 'try_again');
        if (state.callStatus !== 'not_called') {
            select.classList.add(state.callStatus);
        }
    }

    if (last) {
        const count = Number(state.callAttemptCount || 0);
        last.textContent =
            `${count} attempt${count === 1 ? '' : 's'} · Last call: ` +
            (state.callLastAt ? fmtFull(state.callLastAt) : '—');
    }

    if (addAttemptBtn) {
        addAttemptBtn.disabled = !state.phone;
    }

    if (moveBtn) {
        moveBtn.disabled = !state.phone;
        moveBtn.textContent = state.chatBox === 'old'
            ? '↩ Move to Inbox'
            : '📦 Move to Old';
    }
}

async function loadCallStatus(phone) {
    if (!phone) {
        setCallStatusControls({
            call_status: 'not_called',
            called_at: null,
            attempt_count: 0,
            chat_bucket: state.chatBox
        });
        return null;
    }

    try {
        const res = await api('call_status_read', { phone });
        if (res && res.data) {
            setCallStatusControls(res.data);
            if (res.data.conversation_message_id) {
                state.currentMessageId = Number(res.data.conversation_message_id);
            }
            return res.data;
        }
    } catch (e) {
        console.warn('call status:', e);
    }

    setCallStatusControls({
        call_status: 'not_called',
        called_at: null,
        attempt_count: 0,
        chat_bucket: state.chatBox
    });
    return null;
}

async function saveCallStatus(phone, status, conversationMessageId = null) {
    if (!phone) return null;

    const select = $('chatCallStatus');
    const isCurrentChat = state.phone === phone;
    const previousStatus = state.callStatus;
    const previousCalledAt = state.callCalledAt;
    const previousAttempts = state.callAttemptCount;

    try {
        if (isCurrentChat && select) select.disabled = true;

        const res = await apiPost('call_status', {
            phone,
            status,
            conversation_message_id: conversationMessageId ? Number(conversationMessageId) : null,
            status_after: statusAfter
        });

        if (res.error) throw new Error(res.error);

        if (isCurrentChat) {
            if (res.data?.conversation_message_id) {
                state.currentMessageId = Number(res.data.conversation_message_id);
            }
            setCallStatusControls(res.data || {
                call_status: status,
                called_at: previousCalledAt,
                attempt_count: previousAttempts,
                conversation_message_id: conversationMessageId || state.currentMessageId || null,
                chat_bucket: state.chatBox
            });
        }

        await Promise.all([
            loadStats(),
            loadConversations(),
            loadCallTracking(),
            state.view === 'leads' ? loadLeads() : Promise.resolve()
        ]);

        if (isCurrentChat && state.phone === phone) {
            await loadDetails(phone);
        }

        return res.data;
    } catch (e) {
        if (isCurrentChat) {
            state.callStatus = previousStatus;
            state.callCalledAt = previousCalledAt;
            state.callAttemptCount = previousAttempts;
            updateCallStatusUI();
        }
        window.alert('Call state update failed: ' + e.message);
        return null;
    } finally {
        if (isCurrentChat && select) select.disabled = !state.phone;
    }
}

async function addCallAttempt(phone, conversationMessageId = null, statusAfter = 'called') {
    if (!phone) return null;

    const isCurrentChat = state.phone === phone;
    const addBtn = $('addCallAttemptBtn');

    try {
        if (isCurrentChat && addBtn) addBtn.disabled = true;

        const res = await apiPost('call_attempt', {
            phone,
            conversation_message_id: conversationMessageId ? Number(conversationMessageId) : null,
            status_after: statusAfter
        });
        if (res.error) throw new Error(res.error);

        if (isCurrentChat) {
            if (res.data?.conversation_message_id) {
                state.currentMessageId = Number(res.data.conversation_message_id);
            }
            setCallStatusControls(res.data || {
                call_status: 'called',
                called_at: null,
                attempt_count: state.callAttemptCount + 1,
                conversation_message_id: conversationMessageId || state.currentMessageId || null,
                chat_bucket: state.chatBox
            });
        }

        await Promise.all([
            loadStats(),
            loadConversations(),
            loadCallTracking(),
            state.view === 'leads' ? loadLeads() : Promise.resolve()
        ]);

        if (isCurrentChat && state.phone === phone) {
            await loadDetails(phone);
        }

        return res.data;
    } catch (e) {
        window.alert('Attempt save failed: ' + e.message);
        return null;
    } finally {
        if (isCurrentChat) updateCallStatusUI();
    }
}

async function moveChats(phones, bucket) {
    const cleanPhones = Array.from(new Set(
        (phones || []).map(v => String(v || '').trim()).filter(Boolean)
    ));
    if (!cleanPhones.length) return null;

    try {
        const res = await apiPost('move_chats', {
            phones: cleanPhones,
            bucket
        });

        if (res.error) throw new Error(res.error);

        const movedCurrent = state.phone && cleanPhones.includes(state.phone);
        cleanPhones.forEach(phone => state.selectedPhones.delete(phone));

        if (movedCurrent) {
            state.phone = null;
            resetSelectedChatUI();
        }

        await Promise.all([
            loadStats(),
            loadConversations(),
            state.view === 'inbox' ? loadCallTracking() : Promise.resolve()
        ]);

        updateSelectionUI();
        return res.data;
    } catch (e) {
        window.alert('Move failed: ' + e.message);
        return null;
    }
}

async function moveSelectedChats() {
    if (state.view === 'category') {
        await removeSelectedFromCategory();
        return;
    }
    const phones = Array.from(state.selectedPhones);
    if (!phones.length) return;

    const target = state.chatBox === 'old' ? 'inbox' : 'old';
    const label = target === 'old' ? 'Old' : 'Inbox';

    const ok = window.confirm(
        `Move ${phones.length} selected chat${phones.length === 1 ? '' : 's'} to ${label}?\n\n` +
        `All WhatsApp messages and contact details will remain in the database.`
    );
    if (!ok) return;

    await moveChats(phones, target);
}

async function moveCurrentChat() {
    if (!state.phone) return;
    const target = state.chatBox === 'old' ? 'inbox' : 'old';
    await moveChats([state.phone], target);
}

async function loadCallTracking() {
    const body = $('callTrackingBody');
    const count = $('callTrackingCount');
    if (!body || state.chatBox !== 'inbox') return;

    try {
        const res = await api('call_tracking', {
            ...state.filters,
            call_status: '',
            box: 'inbox'
        });

        if (res.error) {
            body.innerHTML = `<div class="empty"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        if (count) count.textContent = rows.length;

        if (!rows.length) {
            body.innerHTML = '<div class="empty"><div class="big">📞</div>No customers in the current Inbox</div>';
            return;
        }

        const counts = {
            not_called: rows.filter(r => normalizeCallState(r.call_status) === 'not_called').length,
            called: rows.filter(r => normalizeCallState(r.call_status) === 'called').length,
            rejected: rows.filter(r => normalizeCallState(r.call_status) === 'rejected').length,
            try_again: rows.filter(r => normalizeCallState(r.call_status) === 'try_again').length,
        };

        body.innerHTML = `
            <div class="call-stats-row">
                <div class="call-mini-stat"><b>${counts.not_called}</b><span>Not called</span></div>
                <div class="call-mini-stat"><b>${counts.called}</b><span>Called</span></div>
                <div class="call-mini-stat"><b>${counts.rejected}</b><span>Rejected</span></div>
                <div class="call-mini-stat"><b>${counts.try_again}</b><span>Try again</span></div>
                <div class="call-mini-stat"><b>${rows.length}</b><span>Total customers</span></div>
            </div>

            <table class="call-tracking-table">
                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Last WhatsApp</th>
                        <th>Messages</th>
                        <th>State</th>
                        <th>Attempts</th>
                        <th>Last called</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(r => {
                        const status = normalizeCallState(r.call_status);
                        const phone = String(r.customer_phone || '');
                        const normalized = normalizeWebPhone(phone);
                        const name = r.customer_name || phone || 'Unknown';
                        const preview = r.last_message_text || '—';

                        return `
                            <tr data-call-phone="${esc(phone)}">
                                <td>
                                    <div class="call-customer">
                                        <div class="avatar ${colorClass(phone)}">${esc(initials(r.customer_name, phone))}</div>
                                        <div>
                                            <div class="call-customer-name">${esc(name)}</div>
                                            <div class="call-customer-phone">${esc(phone)}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="call-message" title="${esc(preview)}">${esc(preview)}</div>
                                    <div class="conv-time" style="margin-top:3px">${esc(fmtFull(r.last_message_at))}</div>
                                </td>
                                <td>${esc(r.total_messages || 0)}</td>
                                <td>
                                    <span class="call-status-badge ${callStatusCssClass(status)}">${esc(callStatusLabel(status))}</span>
                                </td>
                                <td><b>${esc(r.attempt_count || 0)}</b></td>
                                <td>${esc(r.called_at ? fmtFull(r.called_at) : '—')}</td>
                                <td>
                                    <div class="call-actions">
                                        ${normalized ? `<a class="call-action-btn" href="tel:+${esc(normalized)}">📞 Call</a>` : ''}
                                        <button type="button" class="call-action-btn attempt-btn" data-row-attempt="${esc(phone)}" title="Add one call attempt">
                                            ＋ Attempt <span class="attempt-count-mini">${esc(Number(r.attempt_count || 0))}</span>
                                        </button>
                                        <select class="call-status-select" data-row-call-state="${esc(phone)}" aria-label="Call state">
                                            <option value="not_called" ${status === 'not_called' ? 'selected' : ''}>📞 Not called</option>
                                            <option value="called" ${status === 'called' ? 'selected' : ''}>✅ Called</option>
                                            <option value="rejected" ${status === 'rejected' ? 'selected' : ''}>🚫 Rejected</option>
                                            <option value="try_again" ${status === 'try_again' ? 'selected' : ''}>🔄 Try again</option>
                                        </select>
                                        <button type="button" class="call-action-btn" data-open-chat="${esc(phone)}">💬 Chat</button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;

        body.querySelectorAll('[data-row-attempt]').forEach(btn => {
            btn.addEventListener('click', async (event) => {
                event.stopPropagation();
                await addCallAttempt(btn.dataset.rowAttempt || '');
            });
        });

        body.querySelectorAll('[data-row-call-state]').forEach(select => {
            select.addEventListener('change', async (event) => {
                event.stopPropagation();
                await saveCallStatus(
                    select.dataset.rowCallState || '',
                    select.value || 'not_called'
                );
            });
        });

        body.querySelectorAll('[data-open-chat]').forEach(btn => {
            btn.addEventListener('click', (event) => {
                event.stopPropagation();
                const phone = btn.dataset.openChat || '';
                if (phone) selectConversation(phone);
            });
        });

    } catch (e) {
        body.innerHTML = `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

async function deleteCurrentChat() {
    if (!state.phone) {
        return;
    }

    const name =
        $('chatName').textContent || state.phone;

    const ok = window.confirm(
        `Delete this chat from the database?\n\n` +
        `${name}\n${state.phone}\n\n` +
        `This deletes local database records only. ` +
        `It does not delete the conversation from WhatsApp.`
    );

    if (!ok) {
        return;
    }

    const deletedPhone = state.phone;
    const deleteBtn = $('deleteChat');

    try {
        if (deleteBtn) {
            deleteBtn.disabled = true;
        }

        const res = await apiPost('delete_chats', {
            phones: [deletedPhone]
        });

        if (res.error) {
            throw new Error(res.error);
        }

        state.selectedPhones.delete(deletedPhone);
        state.phone = null;

        resetSelectedChatUI();

        await Promise.all([
            loadStats(),
            loadConversations(),
            loadCallTracking()
        ]);

        window.alert(
            `Deleted ${res.deleted_rows || 0} database rows.`
        );

    } catch (e) {

        window.alert('Delete failed: ' + e.message);
        if (deleteBtn) {
            deleteBtn.disabled = !state.phone;
        }
    }
}

async function deleteSelectedChats() {
    const phones =
        Array.from(state.selectedPhones);

    if (!phones.length) {
        return;
    }

    const ok = window.confirm(
        `Delete ${phones.length} selected chat` +
        `${phones.length === 1 ? '' : 's'} from the database?\n\n` +
        `This deletes local database records only. ` +
        `It does not delete conversations from WhatsApp.`
    );

    if (!ok) {
        return;
    }

    try {
        $('deleteSelected').disabled = true;

        const res = await apiPost('delete_chats', {
            phones
        });

        if (res.error) {
            throw new Error(res.error);
        }

        if (
            state.phone &&
            phones.includes(state.phone)
        ) {
            state.phone = null;
            resetSelectedChatUI();
        }

        state.selectedPhones.clear();

        await Promise.all([
            loadStats(),
            loadConversations()
        ]);

        updateComposerState();

        window.alert(
            `Deleted ${res.deleted_rows || 0} database rows.`
        );

    } catch (e) {

        window.alert('Delete failed: ' + e.message);
        updateSelectionUI();
    }
}

function normalizeWebPhone(phone) {
    let value = String(phone || '').trim();

    value = value.replace(/[^\d+]/g, '');

    if (value.startsWith('+')) {
        value = value.slice(1);
    }

    if (/^0\d{8,11}$/.test(value)) {
        value = '94' + value.slice(1);
    }

    return value.replace(/\D/g, '');
}

function openWhatsAppWeb(
    phone,
    message = ''
) {
    const normalized =
        normalizeWebPhone(phone);

    if (!normalized) {
        window.alert('Invalid phone number.');
        return;
    }

    const url =
        'https://web.whatsapp.com/send?phone=' +
        encodeURIComponent(normalized) +
        (
            message
                ? '&text=' + encodeURIComponent(message)
                : ''
        );

    window.open(
        url,
        '_blank',
        'noopener,noreferrer'
    );
}

function updateComposerState() {
    const composer = $('messageComposer');
    const oneBtn = $('sendOneBtn');
    const bulkBtn = $('sendSelectedBtn');
    const webBtn =
        $('openWhatsAppWebFromComposer');
    const webHeaderBtn =
        $('openWhatsAppWeb');
    const target = $('composerTarget');
    const deleteBtn = $('deleteChat');

    const text =
        String(composer?.value || '').trim();

    if (target) {
        target.textContent =
            state.phone || 'No chat selected';
    }

    if (oneBtn) {
        oneBtn.disabled =
            !state.phone || !text;
    }

    if (bulkBtn) {
        bulkBtn.disabled =
            state.selectedPhones.size === 0 ||
            !text;
    }

    if (webBtn) {
        webBtn.disabled = !state.phone;
    }

    if (webHeaderBtn) {
        webHeaderBtn.disabled = !state.phone;
    }

    if (deleteBtn) {
        deleteBtn.disabled = !state.phone;
    }

    updateSelectionUI();
    updateQuickReplyUI();
}

async function sendCurrentMessage() {
    if (!state.phone) {
        return false;
    }

    const textarea = $('messageComposer');
    const message =
        String(textarea.value || '').trim();

    if (!message) {
        return false;
    }

    const button = $('sendOneBtn');
    const original = button.textContent;

    try {

        button.disabled = true;
        button.textContent = 'Sending…';

        const res = await apiPost(
            'send_text',
            {
                phone: state.phone,
                message
            }
        );

        if (res.error) {
            throw new Error(res.error);
        }

        textarea.value = '';

        await Promise.all([
            loadMessages(state.phone),
            loadDetails(state.phone),
            loadConversations(),
            loadStats()
        ]);

        updateComposerState();
        return true;

    } catch (e) {

        window.alert(
            'Message was not sent: ' +
            e.message +
            '\n\nIf the customer service window has expired, ' +
            'Meta may require an approved template instead of free-form text.'
        );
        return false;

    } finally {

        button.textContent = original;
        updateComposerState();
    }
}

async function sendSelectedMessage() {
    const phones =
        Array.from(state.selectedPhones);

    const textarea = $('messageComposer');

    const message =
        String(textarea.value || '').trim();

    if (!phones.length || !message) {
        return;
    }

    const button = $('sendSelectedBtn');
    const original = button.textContent;

    const ok = window.confirm(
        `Send the same message to ${phones.length} ` +
        `selected chat${phones.length === 1 ? '' : 's'}?\n\n` +
        `Message:\n${message}`
    );

    if (!ok) {
        return;
    }

    try {

        button.disabled = true;
        button.textContent = 'Sending…';

        const res = await apiPost(
            'bulk_send_text',
            {
                phones,
                message
            }
        );

        if (res.error) {
            throw new Error(res.error);
        }

        const failedText = (res.failed || [])
            .map(item =>
                `${item.phone}: ${item.error}`
            )
            .join('\n');

        let summary =
            `Sent: ${res.sent_count || 0}\n` +
            `Failed: ${res.failed_count || 0}`;

        if (failedText) {
            summary +=
                '\n\nFailed details:\n' +
                failedText;
        }

        window.alert(summary);

        await Promise.all([
            loadConversations(),
            loadStats()
        ]);

        if (state.phone) {
            await loadMessages(state.phone);
        }

        textarea.value = '';
        updateComposerState();

    } catch (e) {

        window.alert(
            'Bulk send failed: ' +
            e.message +
            '\n\nFree-form Cloud API messages may require ' +
            'an active customer service window.'
        );

    } finally {

        button.textContent = original;
        updateComposerState();
    }
}

/* =========================================================================
   SELECT CONVERSATION
   ========================================================================= */
async function selectConversation(phone) {
    state.phone = phone;

    updateComposerState();

    $$('.conv').forEach(el => {
        el.classList.toggle('active', el.dataset.phone === phone);
    });

    await loadCallStatus(phone);

    await Promise.all([
        loadMessages(phone),
        loadDetails(phone)
    ]);
}

/* =========================================================================
   REFERRAL CARD
   ========================================================================= */
function referralCard(m) {
    if (!Number(m.has_referral) && !m.reference_code && !m.source_id && !m.ctwa_clid) {
        return '';
    }

    const title =
        m.content_title ||
        m.headline ||
        m.ad_body ||
        m.reference_code ||
        'Ad referral';

    const img = m.image_url || m.thumbnail_url;
    const imgUrl = safeUrl(img);

    return `
        <div class="ad-card">
            <div class="ad-top">📣 Ad Referral</div>
            ${imgUrl ? `
                <img class="ad-img"
                     src="${esc(imgUrl)}"
                     alt=""
                     loading="lazy">
            ` : ''}

            <div class="ad-body">
                <div class="ad-title">
                    ${esc(String(title).slice(0, 120))}
                </div>

                ${m.ad_body && m.ad_body !== title
                    ? `<div>${esc(String(m.ad_body).slice(0, 180))}</div>`
                    : ''}

                ${m.ref_media_type
                    ? `<div style="margin-top:6px;color:#64748b">Media: ${esc(m.ref_media_type)}</div>`
                    : ''}

                ${m.reference_code
                    ? `<div class="ref-chip">${esc(m.reference_code)}</div>`
                    : ''}
            </div>
        </div>
    `;
}

/* =========================================================================
   MESSAGES
   ========================================================================= */
async function loadMessages(phone) {
    const thread = $('thread');

    thread.innerHTML =
        '<div class="empty" style="margin:auto"><span class="spinner"></span></div>';

    try {
        const res = await api('messages', { phone });

        if (res.error) {
            thread.innerHTML =
                `<div class="empty" style="margin:auto"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        const head = rows[rows.length - 1] || {};
        state.currentMessageId = Number(head.id || 0) || null;

        $('chatAvatar').textContent =
            initials(head.customer_name, phone);

        $('chatAvatar').className =
            'avatar ' + colorClass(phone);

        state.customerName = head.customer_name || null;

        $('chatName').textContent =
            head.customer_name || phone;

        $('chatSub').textContent =
            phone + ' · ' + rows.length + ' messages';

        if (head.call_status) {
            setCallStatusControls(head);
        }

        if (!rows.length) {
            thread.innerHTML =
                '<div class="empty" style="margin:auto"><div class="big">💬</div>No messages</div>';
            return;
        }

        thread.innerHTML = rows.map(m => {
            const dir =
                m.direction === 'outgoing'
                    ? 'outgoing'
                    : 'incoming';

            return `
                <div class="msg ${dir}">
                    <div class="bubble">
                        <div class="txt">${esc(m.message_text || '')}</div>

                        ${referralCard(m)}

                        <div class="meta">
                            <span>${esc(fmtDateTime(m.message_timestamp))}</span>
                            ${dir === 'outgoing' ? tickMark(m.status) : ''}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        thread.scrollTop = thread.scrollHeight;

    } catch (e) {
        thread.innerHTML =
            `<div class="empty" style="margin:auto"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

/* =========================================================================
   DETAILS
   ========================================================================= */
function kv(k, v, mono = false, link = false) {
    if (v === null || v === undefined || v === '') return '';

    if (link) {
        const url = safeUrl(v);

        if (!url) {
            return `<div class="kv"><span class="k">${esc(k)}</span>
                    <span class="v ${mono ? 'mono' : ''}">${esc(v)}</span></div>`;
        }

        return `<div class="kv">
                    <span class="k">${esc(k)}</span>
                    <span class="v ${mono ? 'mono' : ''}">
                        <a href="${esc(url)}" target="_blank" rel="noopener noreferrer">
                            ${esc(String(v).slice(0, 46))}${String(v).length > 46 ? '…' : ''}
                        </a>
                    </span>
                </div>`;
    }

    return `<div class="kv">
                <span class="k">${esc(k)}</span>
                <span class="v${mono ? ' mono' : ''}">${esc(v)}</span>
            </div>`;
}

async function loadDetails(phone) {
    const panel = $('detailsPanel');

    panel.innerHTML =
        '<div class="empty"><span class="spinner"></span></div>';

    try {
        const res = await api('referral', { phone });
        const r = res.data;

        if (!r) {
            panel.innerHTML =
                '<div class="empty"><div class="big">📋</div>No referral data for this chat</div>';
            return;
        }

        const raw = (() => {
            try {
                return JSON.stringify(
                    JSON.parse(r.raw_payload || '{}'),
                    null,
                    2
                );
            } catch {
                return r.raw_payload || '';
            }
        })();

        panel.innerHTML = `
            <div class="section">
                <h3>Contact</h3>
                ${kv('Name', r.customer_name)}
                ${kv('Phone', r.customer_phone, true)}
                ${kv('Message time', fmtFull(r.message_timestamp))}
                ${kv('Received', fmtFull(r.received_at))}
            </div>

            <div class="section">
                <h3>Normal Call</h3>
                ${kv('State', callStatusLabel(state.callStatus))}
                ${kv('Attempts', String(state.callAttemptCount || 0))}
                ${kv('Last called', state.callCalledAt ? fmtFull(state.callCalledAt) : 'Not called yet')}
                ${kv('Inbox / Old', state.chatBox === 'old' ? 'Old' : 'Inbox')}
                ${kv('Action', 'Use “＋ Attempt” after each phone-call attempt. Use the state selector to keep the current call state.')}
            </div>

            <div class="section">
                <h3>Attribution</h3>
                ${kv('Reference', r.reference_code, true)}
                ${kv('Product', r.product_code)}
                ${kv('Source type', r.source_type)}
                ${kv('Platform', r.source_platform)}
                ${kv('Content title', r.content_title)}
            </div>

            <div class="section">
                <h3>Campaign</h3>
                ${kv('Campaign', r.campaign_name)}
                ${kv('Ad', r.ad_name)}
                ${kv('Creative', r.creative_name)}
                ${kv('Source ID', r.source_id, true)}
                ${kv('Source URL', r.source_url, false, true)}
            </div>

            <div class="section">
                <h3>Creative Content</h3>
                ${kv('Headline', r.headline)}
                ${kv('Body', r.body)}
                ${kv('Media type', r.media_type)}
                ${kv('Image', r.image_url, false, true)}
                ${kv('Video', r.video_url, false, true)}
                ${kv('Thumbnail', r.thumbnail_url, false, true)}
            </div>

            <div class="section">
                <h3>Click Tracking</h3>
                ${kv('CTWA CLID', r.ctwa_clid, true)}
                ${kv('Phone Number ID', r.phone_number_id, true)}
            </div>

            <div class="section">
                <details class="raw">
                    <summary>Raw webhook payload</summary>
                    <pre class="rawbox">${esc(raw)}</pre>
                </details>
            </div>
        `;

    } catch (e) {
        panel.innerHTML =
            `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

/* =========================================================================
   LEADS FILTERS + TABLE
   ========================================================================= */
const leadInputMap = {
    leadSearch:     'q',
    leadPlatform:   'platform',
    leadSourceType: 'source_type',
    leadProduct:    'product',
    leadReference:  'reference',
    leadCtwa:       'ctwa',
    leadCallStatus: 'call_status',
    leadDateFrom:   'date_from',
    leadDateTo:     'date_to',
    leadSort:       'sort',
};

function bindLeadFilters() {
    let timer = null;

    Object.entries(leadInputMap).forEach(([id, key]) => {
        const el = $(id);
        if (!el) return;

        const evt =
            (el.tagName === 'INPUT' && el.type !== 'date')
                ? 'input'
                : 'change';

        el.addEventListener(evt, () => {
            state.leadFilters[key] = el.value;

            clearTimeout(timer);

            timer = setTimeout(() => {
                loadLeads();
                renderLeadChips();
            }, evt === 'input' ? 250 : 0);
        });
    });

    $('leadChips').addEventListener('click', (e) => {
        if (e.target.closest('.chip.clear-all')) {
            clearAllLeadFilters();
        } else if (e.target.dataset.lclear) {
            const key = e.target.dataset.lclear;
            state.leadFilters[key] = '';

            const id = Object.keys(leadInputMap)
                .find(k => leadInputMap[k] === key);

            if (id && $(id)) {
                $(id).value = '';
            }

            loadLeads();
            renderLeadChips();
        }
    });
}

function clearAllLeadFilters() {
    Object.keys(state.leadFilters).forEach(k => {
        state.leadFilters[k] = k === 'sort' ? 'latest' : '';
    });

    Object.entries(leadInputMap).forEach(([id, key]) => {
        if ($(id)) {
            $(id).value = state.leadFilters[key] ?? '';
        }
    });

    loadLeads();
    renderLeadChips();
}

function renderLeadChips() {
    const labels = {
        q: 'Search',
        platform: 'Platform',
        source_type: 'Type',
        product: 'Product',
        reference: 'Ref',
        ctwa: 'CTWA',
        call_status: 'Call state',
        date_from: 'From',
        date_to: 'To',
    };

    const chips = [];

    Object.entries(state.leadFilters).forEach(([k, v]) => {
        if (!v || k === 'sort') return;

        const label = labels[k] || k;
        const val =
            k === 'ctwa'
                ? 'Has CLID'
                : k === 'call_status'
                    ? (v === 'attempted'
                        ? 'Attempted (Try again + Rejected)'
                        : callStatusLabel(v))
                    : v;

        chips.push(
            `<span class="chip">${esc(label)}: ${esc(val)}
                <button data-lclear="${esc(k)}" title="Remove">×</button>
             </span>`
        );
    });

    if (chips.length > 1) {
        chips.push(`<span class="chip clear-all">Clear all ×</span>`);
    }

    $('leadChips').innerHTML = chips.join('');
}

async function loadLeads() {
    const body = $('leadsBody');
    body.innerHTML =
        '<div class="empty"><span class="spinner"></span></div>';

    try {
        const res = await api('leads', state.leadFilters);

        if (res.error) {
            body.innerHTML =
                `<div class="empty"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        $('leadCount').textContent = rows.length;

        if (!rows.length) {
            body.innerHTML =
                '<div class="empty"><div class="big">🔍</div>No leads match filters</div>';
            return;
        }

        body.innerHTML = `
            <table class="leads">
                <thead>
                    <tr>
                        <th>Received</th>
                        <th>Customer</th>
                        <th>Message</th>
                        <th>Type / Source</th>
                        <th>Reference</th>
                        <th>Message ID</th>
                        <th>Product</th>
                        <th>Source</th>
                        <th>Platform</th>
                        <th>Content</th>
                        <th>Call status</th>
                        <th>Attempts</th>
                        <th>Last called</th>
                        <th>CTWA CLID</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(r => {
                        const phone = String(r.customer_phone || '');
                        const normalized = normalizeWebPhone(phone);
                        const status = normalizeCallState(r.call_status);
                        const attemptCount = Number(r.attempt_count || 0);

                        return `
                            <tr data-lead-phone="${esc(phone)}">
                                <td style="white-space:nowrap">
                                    ${esc(fmtDateTime(r.received_at || r.message_timestamp))}
                                </td>

                                <td>
                                    <div style="font-weight:600">
                                        ${esc(r.customer_name || '—')}
                                    </div>
                                    <div style="color:#64748b;font-size:11.5px">
                                        ${esc(phone)}
                                    </div>
                                </td>

                                <td style="max-width:260px">
                                    <div style="font-size:12px;color:#334155;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${esc(r.message_text || '')}">
                                        ${esc(String(r.message_text || '—').slice(0, 90))}
                                    </div>
                                    <div style="font-size:10.5px;color:#94a3b8;margin-top:3px">
                                        ${esc(r.direction === 'outgoing' ? 'Outgoing' : 'Incoming')}
                                    </div>
                                </td>

                                <td>
                                    <div>${esc(r.message_type || '—')}</div>
                                    <div style="font-size:10.5px;color:#64748b;margin-top:3px">${esc(r.message_source || '—')}</div>
                                </td>

                                <td>
                                    <code style="font-size:11.5px">
                                        ${esc(r.reference_code || '—')}
                                    </code>
                                </td>

                                <td><code style="font-size:10.5px;color:#64748b">${esc(r.message_id || '—')}</code></td>
                                <td>${esc(r.product_code || '—')}</td>
                                <td>${esc(r.source_type || '—')}</td>
                                <td>${esc(r.source_platform || '—')}</td>

                                <td style="max-width:260px">
                                    ${esc(String(r.content_title || r.headline || '—').slice(0, 70))}
                                </td>

                                <td>
                                    <span class="call-status-badge ${callStatusCssClass(status)}" title="Related message ID: ${esc(r.conversation_message_id ?? r.message_id ?? '—')}">
                                        ${esc(callStatusLabel(status))}
                                    </span>
                                </td>

                                <td>
                                    <div class="lead-attempt-cell" title="${esc(`Total call attempts: ${attemptCount}`)}">
                                        <span class="lead-attempt-badge">${esc(attemptCount)}</span>
                                        <span class="lead-attempt-label">
                                            ${attemptCount === 1 ? 'attempt' : 'attempts'}
                                        </span>
                                    </div>
                                </td>

                                <td style="white-space:nowrap">
                                    <div style="font-size:11px;color:#64748b">
                                        ${esc(r.called_at ? fmtDateTime(r.called_at) : '—')}
                                    </div>
                                </td>

                                <td>
                                    <code style="font-size:10.5px;color:#64748b">
                                        ${esc(String(r.ctwa_clid || '—').slice(0, 18))}
                                    </code>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;

    } catch (e) {
        body.innerHTML =
            `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

/* =========================================================================
   REFERENCE ANALYSIS
   ========================================================================= */
async function openReferenceAnalysis() {
    $('referenceModal').classList.remove('hidden');

    $('referenceAnalysisBody').innerHTML =
        '<div class="empty"><span class="spinner"></span></div>';

    try {

        const res = await api(
            'reference_analysis',
            state.leadFilters
        );

        if (res.error) {
            throw new Error(res.error);
        }

        const summary = res.summary || {};

        $('raMessages').textContent =
            summary.referral_messages ?? 0;

        $('raCustomers').textContent =
            summary.unique_customers ?? 0;

        $('raReferences').textContent =
            summary.unique_references ?? 0;

        const rows = res.data || [];

        if (!rows.length) {
            $('referenceAnalysisBody').innerHTML =
                '<div class="empty">' +
                '<div class="big">🔍</div>' +
                'No reference data matches the current filters.' +
                '</div>';
            return;
        }

        $('referenceAnalysisBody').innerHTML = `
            <table class="analysis-table">
                <thead>
                    <tr>
                        <th>Reference</th>
                        <th>Messages</th>
                        <th>Customers</th>
                        <th>Product</th>
                        <th>Type</th>
                        <th>Platform</th>
                        <th>Last seen</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(r => `
                        <tr>
                            <td>
                                <span class="ref-code">
                                    ${esc(r.reference_code || '—')}
                                </span>
                            </td>
                            <td>${esc(r.message_count || 0)}</td>
                            <td>${esc(r.customer_count || 0)}</td>
                            <td>${esc(r.products || '—')}</td>
                            <td>${esc(r.source_types || '—')}</td>
                            <td>${esc(r.platforms || '—')}</td>
                            <td style="white-space:nowrap">
                                ${esc(fmtDateTime(r.last_seen))}
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;

    } catch (e) {

        $('referenceAnalysisBody').innerHTML =
            `<div class="empty">
                <div class="big">⚠️</div>
                ${esc(e.message)}
             </div>`;
    }
}

function closeReferenceAnalysis() {
    $('referenceModal')
        .classList.add('hidden');
}

/* =========================================================================
   NEW ACTION BINDINGS
   ========================================================================= */
$('messageComposer').addEventListener(
    'input',
    updateComposerState
);

$('quickReplySelect').addEventListener(
    'change',
    updateQuickReplyUI
);

$('useQuickReplyBtn').addEventListener(
    'click',
    useQuickReply
);

$('sendQuickReplyBtn').addEventListener(
    'click',
    sendQuickReply
);

$('sendOneBtn').addEventListener(
    'click',
    sendCurrentMessage
);

$('sendSelectedBtn').addEventListener(
    'click',
    sendSelectedMessage
);

$('messageComposer').addEventListener(
    'keydown',
    (event) => {
        if (
            (event.ctrlKey || event.metaKey) &&
            event.key === 'Enter'
        ) {
            event.preventDefault();

            if (state.selectedPhones.size > 1) {
                sendSelectedMessage();
            } else {
                sendCurrentMessage();
            }
        }
    }
);

$('openWhatsAppWeb').addEventListener(
    'click',
    () => {
        openWhatsAppWeb(
            state.phone,
            $('messageComposer').value || ''
        );
    }
);

$('openWhatsAppWebFromComposer').addEventListener(
    'click',
    () => {
        openWhatsAppWeb(
            state.phone,
            $('messageComposer').value || ''
        );
    }
);

$('deleteChat').addEventListener(
    'click',
    deleteCurrentChat
);

$('deleteSelected').addEventListener(
    'click',
    deleteSelectedChats
);

$('selectAllVisible').addEventListener(
    'click',
    selectAllVisibleChats
);

$('referenceAnalysisBtn').addEventListener(
    'click',
    openReferenceAnalysis
);

$('closeReferenceModal').addEventListener(
    'click',
    closeReferenceAnalysis
);

$('referenceModalBackdrop').addEventListener(
    'click',
    closeReferenceAnalysis
);

$('chatCallStatus').addEventListener(
    'change',
    () => {
        if (!state.phone) return;
        saveCallStatus(
            state.phone,
            $('chatCallStatus').value || 'not_called',
            state.currentMessageId
        );
    }
);

$('addCallAttemptBtn').addEventListener(
    'click',
    () => {
        if (state.phone) addCallAttempt(state.phone, state.currentMessageId);
    }
);

$('moveSelected').addEventListener(
    'click',
    () => moveSelectedChats()
);

$('categorySelectedBtn').addEventListener(
    'click',
    () => openAssignCategoryModal()
);

$('backToCategories').addEventListener(
    'click',
    () => showCategoriesView()
);

$('createCategoryBtn').addEventListener(
    'click',
    () => openCreateCategoryModal()
);

$('refreshCategoriesBtn').addEventListener(
    'click',
    () => loadCategories()
);

$('confirmCategoryAssign').addEventListener(
    'click',
    () => confirmAddToCategory()
);

$('cancelCategoryAssign').addEventListener(
    'click',
    () => closeAssignCategoryModal()
);

$('closeCategoryModal').addEventListener(
    'click',
    () => closeAssignCategoryModal()
);

$('categoryModalBackdrop').addEventListener(
    'click',
    () => closeAssignCategoryModal()
);

$('createCategoryFromAssign').addEventListener(
    'click',
    () => {
        state.returnToAssignAfterCreate = true;
        closeAssignCategoryModal();
        openCreateCategoryModal();
    }
);

$('saveCategoryBtn').addEventListener(
    'click',
    () => createCategoryFromForm()
);

$('cancelCreateCategory').addEventListener(
    'click',
    () => closeCreateCategoryModal()
);

$('closeCreateCategoryModal').addEventListener(
    'click',
    () => closeCreateCategoryModal()
);

$('createCategoryModalBackdrop').addEventListener(
    'click',
    () => closeCreateCategoryModal()
);

$('newCategoryName').addEventListener(
    'keydown',
    (event) => {
        if (event.key === 'Enter') {
            event.preventDefault();
            createCategoryFromForm();
        }
    }
);

$('moveChatBtn').addEventListener(
    'click',
    () => moveCurrentChat()
);

const installAppBtn = $('installAppBtn');
if (installAppBtn) {
    installAppBtn.addEventListener('click', promptInstallApp);
}

$('refreshCallTracking').addEventListener(
    'click',
    () => loadCallTracking()
);

/* =========================================================================
   CATEGORIES
   ========================================================================= */
async function loadCategories() {
    const body = $('categoriesList');
    if (body) body.innerHTML = '<div class="empty"><div class="big">⏳</div>Loading categories…</div>';

    try {
        const res = await api('categories');
        if (res.error) throw new Error(res.error);

        state.categories = Array.isArray(res.data) ? res.data : [];
        $('categoryCount').textContent = state.categories.length;

        if (!state.categories.length) {
            body.innerHTML =
                '<div class="empty" style="grid-column:1/-1"><div class="big">🏷️</div>No categories yet. Create your first category.</div>';
            return;
        }

        body.innerHTML = state.categories.map(c => `
            <div class="category-card" data-category-id="${esc(c.id)}">
                <div class="category-card-top">
                    <div class="category-icon">🏷️</div>
                    <div>
                        <div class="category-name">${esc(c.name)}</div>
                        <div class="category-meta">${esc(c.chat_count || 0)} chat${Number(c.chat_count || 0) === 1 ? '' : 's'}</div>
                    </div>
                </div>
                <div class="category-card-actions">
                    <button class="mini-btn primary" data-open-category="${esc(c.id)}" type="button">Open</button>
                    <button class="mini-btn danger" data-delete-category="${esc(c.id)}" type="button">Delete</button>
                </div>
            </div>
        `).join('');

        body.querySelectorAll('[data-open-category]').forEach(btn => {
            btn.addEventListener('click', () => openCategory(Number(btn.dataset.openCategory)));
        });
        body.querySelectorAll('[data-delete-category]').forEach(btn => {
            btn.addEventListener('click', () => deleteCategory(Number(btn.dataset.deleteCategory)));
        });
    } catch (e) {
        if (body) body.innerHTML = `<div class="empty" style="grid-column:1/-1"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

function setActiveTopTab(view) {
    $$('.tab').forEach(tab => tab.classList.toggle('active', tab.dataset.view === view));
}

function showCategoriesView() {
    state.view = 'categories';
    state.activeCategoryId = null;
    state.activeCategoryName = null;
    setActiveTopTab('categories');
    $('inboxView').classList.add('hidden');
    $('leadsView').classList.add('hidden');
    $('callTrackingPanel').classList.add('hidden');
    $('categoriesView').classList.remove('hidden');
    state.selectedPhones.clear();
    state.phone = null;
    resetSelectedChatUI();
    updateSelectionUI();
    loadCategories();
}

async function openCategory(id) {
    const category = state.categories.find(c => Number(c.id) === Number(id));
    if (!category) return;

    state.view = 'category';
    state.activeCategoryId = Number(category.id);
    state.activeCategoryName = String(category.name || 'Category');
    state.chatBox = 'inbox';
    state.selectedPhones.clear();
    state.phone = null;

    setActiveTopTab('categories');
    $('categoriesView').classList.add('hidden');
    $('leadsView').classList.add('hidden');
    $('callTrackingPanel').classList.add('hidden');
    $('inboxView').classList.remove('hidden');
    $('backToCategories').classList.remove('hidden');
    $('conversationsTitle').textContent = `Category: ${state.activeCategoryName}`;

    resetSelectedChatUI();
    updateSelectionUI();
    await loadConversations();
}

function openCreateCategoryModal() {
    $('newCategoryName').value = '';
    $('createCategoryModal').classList.remove('hidden');
    setTimeout(() => $('newCategoryName').focus(), 30);
}

function closeCreateCategoryModal() {
    $('createCategoryModal').classList.add('hidden');
    state.returnToAssignAfterCreate = false;
}

async function createCategoryFromForm() {
    const input = $('newCategoryName');
    const name = String(input.value || '').trim();
    if (!name) {
        window.alert('Please enter a category name.');
        input.focus();
        return null;
    }

    try {
        const btn = $('saveCategoryBtn');
        btn.disabled = true;
        const res = await apiPost('create_category', { name });
        if (res.error) throw new Error(res.error);
        const returnToAssign = state.returnToAssignAfterCreate;
        state.returnToAssignAfterCreate = false;
        closeCreateCategoryModal();
        await loadCategories();
        const created = res.category || null;
        if (created && returnToAssign) {
            await openAssignCategoryModal();
            $('categorySelect').value = String(created.id || '');
        }
        return created;
    } catch (e) {
        window.alert('Category could not be created: ' + e.message);
        return null;
    } finally {
        $('saveCategoryBtn').disabled = false;
    }
}

async function deleteCategory(id) {
    const category = state.categories.find(c => Number(c.id) === Number(id));
    if (!category) return;

    const ok = window.confirm(
        `Delete category “${category.name}”?\n\nThe chats themselves will not be deleted. They will only be unassigned from this category.`
    );
    if (!ok) return;

    try {
        const res = await apiPost('delete_category', { category_id: Number(id) });
        if (res.error) throw new Error(res.error);

        if (state.activeCategoryId === Number(id)) {
            showCategoriesView();
        } else {
            await loadCategories();
        }
    } catch (e) {
        window.alert('Category could not be deleted: ' + e.message);
    }
}

async function openAssignCategoryModal() {
    const phones = Array.from(state.selectedPhones);
    if (!phones.length) return;

    await loadCategories();
    const select = $('categorySelect');
    select.innerHTML = '<option value="">Choose category…</option>' +
        state.categories.map(c => `<option value="${esc(c.id)}">${esc(c.name)} (${esc(c.chat_count || 0)})</option>`).join('');

    $('categoryModalSub').textContent = `${phones.length} selected chat${phones.length === 1 ? '' : 's'} — choose where to add them`;
    $('categoryModal').classList.remove('hidden');
}

function closeAssignCategoryModal() {
    $('categoryModal').classList.add('hidden');
}

async function confirmAddToCategory() {
    const categoryId = Number($('categorySelect').value || 0);
    const phones = Array.from(state.selectedPhones);
    if (!categoryId) {
        window.alert('Please choose a category.');
        return;
    }
    if (!phones.length) {
        closeAssignCategoryModal();
        return;
    }

    try {
        const res = await apiPost('add_to_category', { category_id: categoryId, phones });
        if (res.error) throw new Error(res.error);
        closeAssignCategoryModal();
        window.alert(`Processed ${res.available || phones.length} selected chat${(res.available || phones.length) === 1 ? '' : 's'} for ${res.category?.name || 'the category'} (${res.added || 0} newly added).`);
        state.selectedPhones.clear();
        updateSelectionUI();
        await loadCategories();
    } catch (e) {
        window.alert('Chats could not be added: ' + e.message);
    }
}

async function removeSelectedFromCategory() {
    const phones = Array.from(state.selectedPhones);
    if (!state.activeCategoryId || !phones.length) return;

    const ok = window.confirm(
        `Remove ${phones.length} selected chat${phones.length === 1 ? '' : 's'} from “${state.activeCategoryName}”?`
    );
    if (!ok) return;

    try {
        const res = await apiPost('remove_from_category', {
            category_id: state.activeCategoryId,
            phones
        });
        if (res.error) throw new Error(res.error);
        state.selectedPhones.clear();
        await loadCategories();
        await loadConversations();
        updateSelectionUI();
    } catch (e) {
        window.alert('Chats could not be removed: ' + e.message);
    }
}

/* =========================================================================
   VIEW SWITCH
   ========================================================================= */
$$('.tab').forEach(tab => {
    tab.addEventListener('click', async () => {
        $$('.tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        state.view = tab.dataset.view;

        if (state.view === 'categories') {
            showCategoriesView();
            return;
        }

        if (state.view === 'leads') {
            $('categoriesView').classList.add('hidden');
            $('inboxView').classList.add('hidden');
            $('leadsView').classList.remove('hidden');
            $('callTrackingPanel').classList.add('hidden');
            $('backToCategories').classList.add('hidden');
            return loadLeads();
        }

        $('categoriesView').classList.add('hidden');
        $('inboxView').classList.remove('hidden');
        $('leadsView').classList.add('hidden');
        $('callTrackingPanel').classList.toggle('hidden', state.view !== 'inbox');
        $('backToCategories').classList.add('hidden');
        state.activeCategoryId = null;
        state.activeCategoryName = null;

        state.chatBox = state.view === 'old' ? 'old' : 'inbox';
        $('conversationsTitle').textContent = state.chatBox === 'old'
            ? 'Old Conversations'
            : 'Inbox Conversations';

        state.selectedPhones.clear();
        state.phone = null;
        resetSelectedChatUI();
        await loadConversations();
        updateSelectionUI();
    });
});

/* =========================================================================
   AUTO REFRESH
   ========================================================================= */
$('autoBtn').addEventListener('click', () => {
    state.auto = !state.auto;
    $('autoBtn').classList.toggle('on', state.auto);
    setupAutoRefresh();
});

function setupAutoRefresh() {
    clearInterval(state.timer);

    if (!state.auto) return;

    state.timer = setInterval(() => {
        loadStats();

        if (state.view === 'inbox') {
            loadConversations();
            loadCallTracking();
            if (state.phone) loadMessages(state.phone);
        } else if (state.view === 'old' || state.view === 'category') {
            loadConversations();
            if (state.phone) loadMessages(state.phone);
        } else if (state.view === 'categories') {
            loadCategories();
        } else {
            loadLeads();
        }
    }, 8000);
}

/* =========================================================================
   BOOT
   ========================================================================= */
async function boot() {
    bindInboxFilters();
    bindLeadFilters();

    if ('serviceWorker' in navigator) {
        try {
            await navigator.serviceWorker.register('sw.js', { scope: './' });
        } catch (e) {
            console.warn('service worker registration failed', e);
        }
    }

    await loadStats();
    await Promise.all([loadFilterOptions(), loadQuickReplies(), loadCategories()]);
    state.chatBox = 'inbox';
    $('conversationsTitle').textContent = 'Inbox Conversations';
    $('backToCategories').classList.add('hidden');
    await loadConversations();

    populateQuickReplies();
    renderFilterChips();
    renderLeadChips();
    updateComposerState();
    setupAutoRefresh();
}

boot();

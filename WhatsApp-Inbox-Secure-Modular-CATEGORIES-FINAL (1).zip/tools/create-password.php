<?php

declare(strict_types=1);

/*
 * One-time browser password hash generator.
 * Remove/rename this file after creating the admin password.
 */
$message = '';
$hash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = (string)($_POST['password'] ?? '');
    $confirm  = (string)($_POST['confirm_password'] ?? '');

    if ($password === '') {
        $message = 'Password is required.';
    } elseif (strlen($password) < 8) {
        $message = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm) {
        $message = 'Passwords do not match.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $message = 'Password hash generated successfully.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Create Password Hash</title>
    <style>
        body{font-family:Arial,sans-serif;background:#111;color:#fff;padding:40px 20px}
        .box{max-width:520px;margin:auto;background:#1d1d1d;padding:30px;border-radius:12px}
        h2{margin-top:0}
        label{display:block;margin:10px 0 6px;font-weight:700}
        input,button,textarea{width:100%;box-sizing:border-box;padding:12px;margin-bottom:15px;border-radius:6px;border:1px solid #555;font:inherit}
        input{background:#fff;color:#111}
        button{background:#ffd700;border:none;color:#111;font-weight:800;cursor:pointer}
        textarea{min-height:110px;background:#000;color:#0f0}
        .success{color:#00ff88}.error{color:#ff6666}.warning{color:#ffd700;font-size:14px}
    </style>
</head>
<body>
<div class="box">
    <h2>Create Password Hash</h2>

    <?php if ($message !== ''): ?>
        <p class="<?= $hash !== '' ? 'success' : 'error' ?>">
            <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
        </p>
    <?php endif; ?>

    <form method="post" autocomplete="off">
        <label for="password">New Password</label>
        <input id="password" type="password" name="password" required autocomplete="new-password">

        <label for="confirm_password">Confirm Password</label>
        <input id="confirm_password" type="password" name="confirm_password" required autocomplete="new-password">

        <button type="submit">Generate Password Hash</button>
    </form>

    <?php if ($hash !== ''): ?>
        <p class="success">Copy this hash into <code>config.php</code>:</p>
        <textarea readonly><?= htmlspecialchars($hash, ENT_QUOTES, 'UTF-8') ?></textarea>
        <p class="warning">After copying the hash, delete or rename this file.</p>
    <?php endif; ?>
</div>
</body>
</html>

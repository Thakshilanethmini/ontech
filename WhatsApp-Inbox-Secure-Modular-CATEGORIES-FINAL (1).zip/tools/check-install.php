<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "CLI only\n");
    exit(1);
}

require_once dirname(__DIR__) . '/config.php';

$checks = [];
$failures = 0;

function checkLine(string $name, bool $ok, string $detail = ''): void
{
    global $failures;
    printf("[%s] %s%s\n", $ok ? 'OK' : 'FAIL', $name, $detail !== '' ? ': ' . $detail : '');
    if (!$ok) {
        $failures++;
    }
}

checkLine('PHP >= 8.1', PHP_VERSION_ID >= 80100, PHP_VERSION);
checkLine('PDO extension', extension_loaded('pdo'));
checkLine('PDO MySQL extension', extension_loaded('pdo_mysql'));
checkLine('cURL extension', extension_loaded('curl'));
checkLine('mbstring extension', extension_loaded('mbstring'));
checkLine('OpenSSL extension', extension_loaded('openssl'));
checkLine('Authentication configured', (bool)($waInboxUsername !== '' && $waInboxPasswordHash !== '' && password_get_info($waInboxPasswordHash)['algo'] !== 0));
checkLine('WhatsApp access token configured', $accessToken !== '', 'value not printed');
checkLine('WhatsApp phone number ID configured', $phoneNumberId !== '', 'value not printed');
checkLine('Database configuration present', $dbName !== '' && $dbUser !== '');

if ($pdo instanceof PDO) {
    checkLine('Database connection', true);
    try {
        $tableExists = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'whatsapp_conversation_messages'")->fetchColumn() > 0;
        checkLine('whatsapp_conversation_messages table', $tableExists);
    } catch (Throwable $e) {
        checkLine('whatsapp_conversation_messages table', false, 'query failed');
    }
} else {
    checkLine('Database connection', false, 'configure DB_* values in config.php');
}

exit($failures === 0 ? 0 : 1);

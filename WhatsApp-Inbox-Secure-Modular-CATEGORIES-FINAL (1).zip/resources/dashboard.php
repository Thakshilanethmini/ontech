<?php
if (!defined('WA_INBOX_BOOTSTRAPPED')) {
    http_response_code(403);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WhatsApp Inbox</title>
<meta name="theme-color" content="#25d366">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="manifest" href="manifest.php">
<link rel="stylesheet" href="assets/css/app.css?v=2">
<meta name="csrf-token" content="<?= htmlspecialchars($waInboxCsrf, ENT_QUOTES, 'UTF-8') ?>">


<script defer src="assets/js/app.js?v=2"></script>
</head>
<body>

<div class="topbar">
    <div class="brand">
        <div class="dot">💬</div>
        <span>WhatsApp Inbox</span>
    </div>

    <div class="tabs">
        <button class="tab active" data-view="inbox">Inbox</button>
        <button class="tab" data-view="old">Old</button>
        <button class="tab" data-view="leads">Leads</button>
        <button class="tab" data-view="categories">Categories</button>
    </div>

    <div class="stats">
        <div class="stat"><b id="s-conv">–</b><span>Chats</span></div>
        <div class="stat"><b id="s-msg">–</b><span>Messages</span></div>
        <div class="stat"><b id="s-old">–</b><span>Old</span></div>
        <div class="stat"><b id="s-leads">–</b><span>Leads</span></div>
        <div class="stat call-stat"><b id="s-not-called">–</b><span>Not called</span></div>
        <div class="stat call-stat"><b id="s-called">–</b><span>Called</span></div>
        <div class="stat call-stat"><b id="s-rejected">–</b><span>Rejected</span></div>
        <div class="stat call-stat"><b id="s-try-again">–</b><span>Try again</span></div>
        <div class="stat"><b id="s-today">–</b><span>Today</span></div>
    </div>

    <div class="toolbar">
        <button class="auto-btn on" id="autoBtn">
            <span class="pulse"></span> Live
        </button>
        <button class="auto-btn install-btn" id="installAppBtn">⤓ Install</button>
        <span class="security-pill">🔐 Protected</span>
        <form class="logout-form" action="logout.php" method="post">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($waInboxCsrf, ENT_QUOTES, 'UTF-8') ?>">
            <button class="auto-btn logout-btn" type="submit" title="Sign out">🔒 Sign out</button>
        </form>
    </div>
</div>

<div class="wrap">

<div class="grid" id="inboxView">

    <div class="panel">
        <div class="filters">
            <input class="input" id="searchInput" type="search" placeholder="Search name, phone, message, ref…">

            <div class="filter-row">
                <select class="select" id="sourceFilter">
                    <option value="">All sources</option>
                </select>
                <select class="select" id="platformFilter">
                    <option value="">All platforms</option>
                </select>
            </div>

            <button class="filter-toggle" id="toggleAdv">
                ⚙️ More filters <span class="cnt hidden" id="advCount">0</span>
            </button>

            <div class="adv-filters hidden" id="advFilters">
                <div class="filter-row">
                    <select class="select" id="sourceTypeFilter">
                        <option value="">Any type</option>
                    </select>
                    <select class="select" id="productFilter">
                        <option value="">Any product</option>
                    </select>
                </div>

                <input class="input" id="referenceFilter" placeholder="Reference code (contains)">

                <div class="filter-row">
                    <select class="select" id="referralFilter">
                        <option value="">All chats</option>
                        <option value="yes">Only with referral</option>
                        <option value="no">Only without referral</option>
                    </select>
                    <select class="select" id="ctwaFilter">
                        <option value="">Any CLID</option>
                        <option value="yes">Has CTWA CLID</option>
                    </select>
                </div>

                <div class="filter-row">
                    <select class="select" id="messageTypeFilter">
                        <option value="">Any msg type</option>
                    </select>
                    <select class="select" id="sortFilter">
                        <option value="latest">Latest first</option>
                        <option value="oldest">Oldest first</option>
                        <option value="name">Name A–Z</option>
                        <option value="messages">Most messages</option>
                    </select>
                </div>

                <div class="adv-label">Date range</div>

                <div class="filter-row">
                    <input class="input" type="date" id="dateFrom" placeholder="From">
                    <input class="input" type="date" id="dateTo" placeholder="To">
                </div>

                <div class="chips">
                    <button class="chip" data-range="today">Today</button>
                    <button class="chip" data-range="7">Last 7 days</button>
                    <button class="chip" data-range="30">Last 30 days</button>
                    <button class="chip" data-range="month">This month</button>
                </div>
            </div>

            <div class="chips" id="filterChips"></div>
        </div>
 <div class="conversation-title-row" id="conversationTitleRow">
            <h2 id="conversationsTitle"></h2>
            <button class="mini-btn hidden" id="backToCategories" type="button">← Categories</button>
        </div>
        <div class="panel-head">
     
           
        
            <div class="head-actions">
                <button class="mini-btn" id="selectAllVisible" title="Select all visible chats">☑ Select all</button>
                <button class="mini-btn" id="moveSelected" title="Move selected chats">📦 Move to Old</button>
                <button class="mini-btn category-action" id="categorySelectedBtn" title="Add selected chats to a category">🏷 Add to Category</button>
                <button class="mini-btn danger" id="deleteSelected" title="Delete selected chats from database" disabled>🗑 Delete</button>
                <span class="count-pill" id="convCount">0</span>
            </div>
        </div>

        <div class="panel-body" id="convList">
            <div class="empty"><div class="big">⏳</div>Loading…</div>
        </div>
    </div>

    <div class="panel">
        <div class="chat-head" id="chatHead">
            <div class="avatar" id="chatAvatar">–</div>
            <div class="chat-head-main">
                <div class="name" id="chatName">Select a conversation</div>
                <div class="sub" id="chatSub">Pick a chat from the list to view messages</div>
              
            </div>
            <div>
            </div>
        <div class="chat-call-controls">
                <button class="mini-btn call-attempt-btn" id="addCallAttemptBtn" type="button" disabled>＋ Attempt</button>
                <select class="call-status-select" id="chatCallStatus" disabled aria-label="Call state">
                    <option value="not_called">📞 Not called</option>
                    <option value="called">✅ Called</option>
                    <option value="rejected">🚫 Rejected</option>
                    <option value="try_again">🔄 Try again</option>
                </select>
                <span class="call-last" id="chatCallLast">0 attempts · Last call: —</span>
            </div>
            <div class="chat-actions">
                <button class="mini-btn" id="openWhatsAppWeb" title="Open this chat in WhatsApp Web">🌐 WhatsApp Web</button>
                <button class="mini-btn" id="moveChatBtn" title="Move this chat">📦 Move to Old</button>
                <button class="mini-btn danger" id="deleteChat" title="Delete this chat from the database" disabled>🗑 Delete chat</button>
            </div>
        </div>

        <div class="thread" id="thread">
            <div class="empty" class="empty empty-center">
                <div class="big">💬</div>No conversation selected
            </div>
        </div>

        <div class="composer">
            <div class="composer-top">
                <span class="composer-label">Send message</span>
                <span class="composer-target" id="composerTarget">No chat selected</span>
            </div>

            <div class="quick-reply-row">
                <select id="quickReplySelect" class="quick-reply-select" aria-label="Quick reply">
                    <option value="">⚡ Quick reply — choose a ready message</option>
                </select>
                <button class="quick-reply-btn" id="useQuickReplyBtn" type="button" disabled>Use</button>
                <button class="quick-reply-btn primary" id="sendQuickReplyBtn" type="button" disabled>⚡ Send quick</button>
            </div>
            <div class="quick-reply-hint">Choose a ready-made reply, personalize the placeholders, then send. The call follow-up can also record the call attempt automatically.</div>
            <div class="quick-reply-vars" aria-label="Quick reply placeholders">
                <span>{name}</span><span>{call_time}</span>
            </div>

            <textarea id="messageComposer" class="composer-input" rows="3"
                placeholder="Type a WhatsApp message…"></textarea>

            <div class="composer-actions">
                <div class="composer-hint">
                    <span id="selectedCountText">0 chats selected</span>
                </div>
                <div class="composer-buttons">
                    <button class="mini-btn" id="openWhatsAppWebFromComposer" disabled>🌐 Web</button>
                    <button class="send-btn" id="sendOneBtn" disabled>➤ Send</button>
                    <button class="send-btn bulk" id="sendSelectedBtn" disabled>➤ Send to selected</button>
                </div>
            </div>

            <div class="composer-note">
                Cloud API sends through the configured WhatsApp number (bulk: up to 50 selected chats per action). WhatsApp Web opens the official Web chat with the message prefilled; sending there is manual.
            </div>
        </div>
    </div>

    <div class="panel details">
        <div class="panel-head"><h2>Lead / Referral Details</h2></div>
        <div class="panel-body" id="detailsPanel">
            <div class="empty"><div class="big">📋</div>No lead data</div>
        </div>
    </div>
</div>

<div class="panel call-tracking-panel" id="callTrackingPanel">
    <div class="panel-head call-tracking-head">
        <div>
            <h2>Customer Call Tracking</h2>
            <div class="panel-sub">Track call state and attempt count. Use “＋ Attempt” after each phone-call attempt. No call-result history is stored.</div>
        </div>
        <div class="head-actions">
            <span class="count-pill" id="callTrackingCount">0</span>
            <button class="mini-btn" id="refreshCallTracking" type="button">↻ Refresh</button>
        </div>
    </div>
    <div class="panel-body call-tracking-body" id="callTrackingBody">
        <div class="empty"><div class="big">📞</div>Loading…</div>
    </div>
</div>

<div class="panel hidden leads-panel" id="leadsView">

    <div class="leads-filters">
        <div class="filter-row">
            <input class="input" id="leadSearch" placeholder="Search leads…" class="input lead-search-input">
            <select class="select" id="leadSort" class="select lead-sort-select">
                <option value="latest">Latest first</option>
                <option value="oldest">Oldest first</option>
                <option value="name">Name A–Z</option>
            </select>
        </div>

        <div class="leads-filter-grid">
            <select class="select" id="leadPlatform">
                <option value="">All platforms</option>
            </select>
            <select class="select" id="leadSourceType">
                <option value="">Any source type</option>
            </select>
            <select class="select" id="leadProduct">
                <option value="">Any product</option>
            </select>
            <input class="input" id="leadReference" placeholder="Reference code">
            <select class="select" id="leadCtwa">
                <option value="">Any CLID</option>
                <option value="yes">Has CTWA CLID</option>
            </select>
            <select class="select" id="leadCallStatus">
                <option value="">Any call state</option>
                <option value="not_called">📞 Not called</option>
                <option value="called">✅ Called</option>
                <option value="rejected">🚫 Rejected</option>
                <option value="try_again">🔄 Try again</option>
                <option value="attempted">🔄🚫 Attempted (Try again + Rejected)</option>
            </select>
            <input class="input" type="date" id="leadDateFrom">
            <input class="input" type="date" id="leadDateTo">
        </div>

        <div class="chips" id="leadChips"></div>
    </div>

    <div class="panel-head">
        <h2>Captured Leads</h2>
        <div class="head-actions">
            <button class="mini-btn" id="referenceAnalysisBtn">📊 Reference Analysis</button>
            <span class="count-pill" id="leadCount">0</span>
        </div>
    </div>

    <div class="panel-body leads-wrap" id="leadsBody">
        <div class="empty"><div class="big">📥</div>Loading…</div>
    </div>
</div>

<div class="panel hidden categories-panel" id="categoriesView">
    <div class="panel-head categories-head">
        <div>
            <h2>Chat Categories</h2>
            <div class="panel-sub">Create folders for conversations, then add selected chats from Inbox or Old</div>
        </div>
        <div class="head-actions">
            <span class="count-pill" id="categoryCount">0</span>
            <button class="mini-btn primary" id="createCategoryBtn" type="button">＋ New Category</button>
            <button class="mini-btn" id="refreshCategoriesBtn" type="button">↻ Refresh</button>
        </div>
    </div>
    <div class="panel-body categories-body" id="categoriesList">
        <div class="empty"><div class="big">⏳</div>Loading…</div>
    </div>
</div>

</div>

<div class="modal hidden" id="categoryModal">
    <div class="modal-backdrop" id="categoryModalBackdrop"></div>
    <div class="modal-card category-modal-card">
        <div class="modal-head">
            <div>
                <div class="modal-title">Add Chats to Category</div>
                <div class="modal-sub" id="categoryModalSub">Choose a category for the selected chats</div>
            </div>
            <button class="modal-close" id="closeCategoryModal" type="button">×</button>
        </div>
        <div class="category-modal-body">
            <label class="modal-label" for="categorySelect">Category</label>
            <div class="filter-row category-select-row">
                <select class="select" id="categorySelect">
                    <option value="">Choose category…</option>
                </select>
                <button class="mini-btn" id="createCategoryFromAssign" type="button">＋ New</button>
            </div>
            <div class="category-modal-actions">
                <button class="mini-btn" id="cancelCategoryAssign" type="button">Cancel</button>
                <button class="mini-btn primary" id="confirmCategoryAssign" type="button">🏷 Add chats</button>
            </div>
        </div>
    </div>
</div>

<div class="modal hidden" id="createCategoryModal">
    <div class="modal-backdrop" id="createCategoryModalBackdrop"></div>
    <div class="modal-card category-modal-card">
        <div class="modal-head">
            <div>
                <div class="modal-title">Create Category</div>
                <div class="modal-sub">Give this chat group a clear name</div>
            </div>
            <button class="modal-close" id="closeCreateCategoryModal" type="button">×</button>
        </div>
        <div class="category-modal-body">
            <label class="modal-label" for="newCategoryName">Category name</label>
            <input class="input" id="newCategoryName" maxlength="100" placeholder="e.g. Hot Leads">
            <div class="category-modal-actions">
                <button class="mini-btn" id="cancelCreateCategory" type="button">Cancel</button>
                <button class="mini-btn primary" id="saveCategoryBtn" type="button">Create Category</button>
            </div>
        </div>
    </div>
</div>

<div class="modal hidden" id="referenceModal">
    <div class="modal-backdrop" id="referenceModalBackdrop"></div>

    <div class="modal-card">
        <div class="modal-head">
            <div>
                <div class="modal-title">Reference Analysis</div>
                <div class="modal-sub">Reference performance for the current lead filters</div>
            </div>
            <button class="modal-close" id="closeReferenceModal">×</button>
        </div>

        <div class="analysis-stats">
            <div class="analysis-stat">
                <b id="raMessages">0</b>
                <span>Referral messages</span>
            </div>
            <div class="analysis-stat">
                <b id="raCustomers">0</b>
                <span>Unique customers</span>
            </div>
            <div class="analysis-stat">
                <b id="raReferences">0</b>
                <span>Unique references</span>
            </div>
        </div>

        <div class="analysis-table-wrap" id="referenceAnalysisBody">
            <div class="empty"><span class="spinner"></span></div>
        </div>
    </div>
</div>


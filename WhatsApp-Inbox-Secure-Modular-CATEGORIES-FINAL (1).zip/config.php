<?php

declare(strict_types=1);

// Prevent accidental direct execution through PHP's built-in server or other
// setups where .htaccess is not available. Includes/CLI checks still work.
if (PHP_SAPI !== 'cli') {
    $scriptFile = realpath((string)($_SERVER['SCRIPT_FILENAME'] ?? ''));
    if ($scriptFile !== false && $scriptFile === realpath(__FILE__)) {
        http_response_code(404);
        exit;
    }
}

/**
 * WhatsApp Inbox configuration.
 *
 * For cPanel/shared hosting, edit the SAFE DEFAULTS below.
 * For stronger secret management, set the matching environment variables.
 * Never commit real credentials or access tokens to a public repository.
 */

if (!function_exists('waInboxEnvOrDefault')) {
    function waInboxEnvOrDefault(string $key, string $default = ''): string
    {
        $value = getenv($key);
        return ($value !== false && trim((string)$value) !== '')
            ? trim((string)$value)
            : $default;
    }
}

// ============================================================================
// EDIT THESE VALUES ON YOUR SERVER (or provide environment variables)
// ============================================================================
$CFG = [
    // App
    'timezone' => 'Asia/Colombo',
    'app_name' => 'WhatsApp Inbox',

    // Authentication: ON by default.
    // Generate the hash with: php tools/create-password.php 'YourStrongPassword'
    'require_auth' => true,
    'username' => '',
    'password_hash' => '',

    // MySQL database containing whatsapp_conversation_messages.
    'db_host' => 'localhost',
    'db_port' => '3306',
    'db_name' => '',
    'db_user' => '',
    'db_pass' => '',
    'db_charset' => 'utf8mb4',

    // Meta WhatsApp Cloud API.
    'access_token' => '',
    'phone_number_id' => '',
    'graph_api_version' => 'v23.0',
];

$timezone = waInboxEnvOrDefault('WA_INBOX_TIMEZONE', (string)$CFG['timezone']);
date_default_timezone_set($timezone);

$waInboxAppName = waInboxEnvOrDefault('WA_INBOX_APP_NAME', (string)$CFG['app_name']);
$waInboxRequireAuth = filter_var(
    waInboxEnvOrDefault('WA_INBOX_REQUIRE_AUTH', $CFG['require_auth'] ? 'true' : 'false'),
    FILTER_VALIDATE_BOOLEAN,
    FILTER_NULL_ON_FAILURE
);
$waInboxRequireAuth = $waInboxRequireAuth ?? true;

$waInboxUsername = waInboxEnvOrDefault('WA_INBOX_USERNAME', (string)$CFG['username']);
$waInboxPasswordHash = waInboxEnvOrDefault('WA_INBOX_PASSWORD_HASH', (string)$CFG['password_hash']);

$dbHost = waInboxEnvOrDefault('DB_HOST', (string)$CFG['db_host']);
$dbPort = waInboxEnvOrDefault('DB_PORT', (string)$CFG['db_port']);
$dbName = waInboxEnvOrDefault('DB_NAME', (string)$CFG['db_name']);
$dbUser = waInboxEnvOrDefault('DB_USER', (string)$CFG['db_user']);
$dbPass = waInboxEnvOrDefault('DB_PASS', (string)$CFG['db_pass']);
$dbCharset = waInboxEnvOrDefault('DB_CHARSET', (string)$CFG['db_charset']);

$accessToken = waInboxEnvOrDefault('WA_ACCESS_TOKEN', (string)$CFG['access_token']);
$phoneNumberId = waInboxEnvOrDefault('WA_PHONE_NUMBER_ID', (string)$CFG['phone_number_id']);
$graphApiVersion = waInboxEnvOrDefault('WA_GRAPH_API_VERSION', (string)$CFG['graph_api_version']);

$pdo = null;

// The login page can still load before the DB is configured. API requests will
// return a safe configuration error instead of exposing connection details.
if ($dbName !== '' && $dbUser !== '') {
    try {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            $dbHost,
            $dbPort,
            $dbName,
            $dbCharset
        );

        $pdo = new PDO($dsn, $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_PERSISTENT => false,
        ]);
    } catch (Throwable $e) {
        error_log('[WhatsApp Inbox] database connection failed: ' . $e->getMessage());
        $pdo = null;
    }
}

unset($CFG);

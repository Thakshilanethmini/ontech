<?php

require_once __DIR__ . '/config.php';


/*
|--------------------------------------------------------------------------
| HELPER: WRITE WEBHOOK LOG
|--------------------------------------------------------------------------
*/
function writeWebhookLog($title, $data)
{
    $logFile = __DIR__ . '/webhook_log.txt';

    $content =
        "\n" .
        date('Y-m-d H:i:s') . PHP_EOL .
        $title . PHP_EOL .
        json_encode(
            $data,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
        ) .
        PHP_EOL .
        "==============================" .
        PHP_EOL;

    file_put_contents(
        $logFile,
        $content,
        FILE_APPEND | LOCK_EX
    );
}


/*
|--------------------------------------------------------------------------
| HELPER: EXTRACT REF FROM MESSAGE
|--------------------------------------------------------------------------
|
| Example:
| Hi, I need ERP Demo Details.
| [REF:ERP-VIDEO-01]
|
| Returns:
| reference_code = ERP-VIDEO-01
| product_code   = ERP
| source_type    = Video
|
|--------------------------------------------------------------------------
*/
function extractReferenceData($messageText)
{
    $result = [
        'reference_code' => null,
        'product_code'   => null,
        'source_type'    => null,
    ];

    if (!$messageText) {
        return $result;
    }

    /*
    | Accept:
    | [REF:ERP-VIDEO-01]
    | [ref:ERP-VIDEO-01]
    */
    if (
        preg_match(
            '/\[REF\s*:\s*([A-Z0-9_-]+)\]/i',
            $messageText,
            $matches
        )
    ) {
        $referenceCode = strtoupper(trim($matches[1]));

        $result['reference_code'] = $referenceCode;

        /*
        | Split:
        | ERP-VIDEO-01
        |
        | ERP    = product
        | VIDEO  = content type
        | 01     = number
        */
        $parts = explode('-', $referenceCode);

        if (!empty($parts[0])) {
            $result['product_code'] = strtoupper(trim($parts[0]));
        }

        if (!empty($parts[1])) {

            $type = strtoupper(trim($parts[1]));

            switch ($type) {

                case 'VIDEO':
                    $result['source_type'] = 'Video';
                    break;

                case 'VID':
                    $result['source_type'] = 'Video';
                    break;

                case 'FLYER':
                    $result['source_type'] = 'Flyer';
                    break;

                case 'FLY':
                    $result['source_type'] = 'Flyer';
                    break;

                case 'IMAGE':
                    $result['source_type'] = 'Image';
                    break;

                case 'IMG':
                    $result['source_type'] = 'Image';
                    break;

                case 'AD':
                    $result['source_type'] = 'Ad';
                    break;

                case 'POST':
                    $result['source_type'] = 'Post';
                    break;

                default:
                    $result['source_type'] = ucfirst(strtolower($type));
                    break;
            }
        }
    }

    return $result;
}


/*
|--------------------------------------------------------------------------
| HELPER: DETECT SOURCE PLATFORM
|--------------------------------------------------------------------------
*/
function detectSourcePlatform($sourceUrl)
{
    if (!$sourceUrl) {
        return null;
    }

    $host = strtolower(
        parse_url($sourceUrl, PHP_URL_HOST) ?? ''
    );

    if (
        strpos($host, 'facebook.com') !== false ||
        strpos($host, 'fb.com') !== false
    ) {
        return 'Facebook';
    }

    if (
        strpos($host, 'instagram.com') !== false
    ) {
        return 'Instagram';
    }

    return null;
}


/*
|--------------------------------------------------------------------------
| HELPER: CLEAN TEXT
|--------------------------------------------------------------------------
*/
function cleanNullableString($value)
{
    if ($value === null) {
        return null;
    }

    $value = trim((string)$value);

    return $value === '' ? null : $value;
}


/*
|--------------------------------------------------------------------------
| 1. META WEBHOOK VERIFICATION
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $mode      = $_GET['hub_mode'] ?? '';
    $token     = $_GET['hub_verify_token'] ?? '';
    $challenge = $_GET['hub_challenge'] ?? '';

    if (
        $mode === 'subscribe' &&
        hash_equals($verifyToken, $token)
    ) {
        http_response_code(200);
        echo $challenge;
        exit;
    }

    http_response_code(403);
    echo 'Verification failed';
    exit;
}


/*
|--------------------------------------------------------------------------
| 2. ONLY POST ALLOWED
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);
    echo 'Method Not Allowed';
    exit;
}


/*
|--------------------------------------------------------------------------
| 3. READ RAW JSON
|--------------------------------------------------------------------------
*/

$rawInput = file_get_contents('php://input');

$data = json_decode($rawInput, true);


/*
|--------------------------------------------------------------------------
| 4. VALIDATE JSON
|--------------------------------------------------------------------------
*/

if (!is_array($data)) {

    http_response_code(400);
    echo 'Invalid JSON';
    exit;
}


/*
|--------------------------------------------------------------------------
| 5. LOG EVERY RAW WEBHOOK
|--------------------------------------------------------------------------
*/

writeWebhookLog(
    'WHATSAPP WEBHOOK',
    $data
);


/*
|--------------------------------------------------------------------------
| 6. CHECK WHATSAPP OBJECT
|--------------------------------------------------------------------------
*/

if (
    !isset($data['object']) ||
    $data['object'] !== 'whatsapp_business_account'
) {

    http_response_code(200);
    echo 'EVENT_RECEIVED';
    exit;
}


/*
|--------------------------------------------------------------------------
| 7. PROCESS ENTRIES
|--------------------------------------------------------------------------
*/

foreach ($data['entry'] ?? [] as $entry) {

    foreach ($entry['changes'] ?? [] as $change) {

        if (($change['field'] ?? '') !== 'messages') {
            continue;
        }

        $value = $change['value'] ?? [];


        /*
        |--------------------------------------------------------------------------
        | COMMON DATA
        |--------------------------------------------------------------------------
        */

        $webhookPhoneNumberId =
            $value['metadata']['phone_number_id']
            ?? $phoneNumberId;


        /*
        |--------------------------------------------------------------------------
        | CUSTOMER NAME
        |--------------------------------------------------------------------------
        */

        $customerName = null;

        if (!empty($value['contacts'][0]['profile']['name'])) {

            $customerName =
                $value['contacts'][0]['profile']['name'];
        }


        /*
        |--------------------------------------------------------------------------
        | A) INCOMING MESSAGES
        |--------------------------------------------------------------------------
        */

        $messages = $value['messages'] ?? [];

        foreach ($messages as $message) {

            /*
            |--------------------------------------------------------------------------
            | CUSTOMER PHONE
            |--------------------------------------------------------------------------
            */

            $customerPhone =
                $message['from'] ?? null;


            /*
            |--------------------------------------------------------------------------
            | MESSAGE ID
            |--------------------------------------------------------------------------
            */

            $messageId =
                $message['id'] ?? null;


            /*
            |--------------------------------------------------------------------------
            | MESSAGE TYPE
            |--------------------------------------------------------------------------
            */

            $messageType =
                $message['type'] ?? 'unknown';


            /*
            |--------------------------------------------------------------------------
            | MESSAGE TEXT
            |--------------------------------------------------------------------------
            */

            $messageText = null;

            if (
                $messageType === 'text' &&
                isset($message['text']['body'])
            ) {

                $messageText =
                    $message['text']['body'];
            }


            /*
            |--------------------------------------------------------------------------
            | NON-TEXT MESSAGE LABELS
            |--------------------------------------------------------------------------
            */

            if ($messageText === null) {

                switch ($messageType) {

                    case 'image':
                        $messageText = '[Image]';
                        break;

                    case 'video':
                        $messageText = '[Video]';
                        break;

                    case 'audio':
                        $messageText = '[Audio]';
                        break;

                    case 'document':
                        $messageText = '[Document]';
                        break;

                    case 'sticker':
                        $messageText = '[Sticker]';
                        break;

                    case 'location':
                        $messageText = '[Location]';
                        break;

                    case 'contacts':
                        $messageText = '[Contact]';
                        break;

                    default:
                        $messageText =
                            '[' . $messageType . ']';
                        break;
                }
            }


            /*
            |--------------------------------------------------------------------------
            | MESSAGE TIMESTAMP
            |--------------------------------------------------------------------------
            */

            $timestamp =
                $message['timestamp'] ?? time();

            $messageDate =
                date(
                    'Y-m-d H:i:s',
                    (int)$timestamp
                );


            /*
            |--------------------------------------------------------------------------
            | REFERRAL DATA FROM META
            |--------------------------------------------------------------------------
            */

            $referral =
                $message['referral'] ?? [];

            $sourceId =
                $referral['source_id'] ?? null;

            $sourceUrl =
                $referral['source_url'] ?? null;

            $metaSourceType =
                $referral['source_type'] ?? null;

            $headline =
                $referral['headline'] ?? null;

            $body =
                $referral['body'] ?? null;

            $mediaType =
                $referral['media_type'] ?? null;

            $imageUrl =
                $referral['image_url'] ?? null;

            $videoUrl =
                $referral['video_url'] ?? null;

            $thumbnailUrl =
                $referral['thumbnail_url'] ?? null;

            $ctwaClid =
                $referral['ctwa_clid'] ?? null;


            /*
            |--------------------------------------------------------------------------
            | EXTRACT OWN REF CODE
            |--------------------------------------------------------------------------
            */

            $referenceData =
                extractReferenceData($messageText);

            $referenceCode =
                $referenceData['reference_code'];

            $productCode =
                $referenceData['product_code'];

            /*
            | Own REF type gets priority.
            | Otherwise use Meta's referral source_type.
            */
            $sourceType =
                $referenceData['source_type']
                ?? $metaSourceType;


            /*
            |--------------------------------------------------------------------------
            | DETECT PLATFORM
            |--------------------------------------------------------------------------
            */

            $sourcePlatform =
                detectSourcePlatform($sourceUrl);


            /*
            |--------------------------------------------------------------------------
            | CONTENT TITLE
            |--------------------------------------------------------------------------
            */

            $contentTitle =
                cleanNullableString($headline);

            if (!$contentTitle && $body) {
                $contentTitle =
                    cleanNullableString($body);
            }

            if (
                !$contentTitle &&
                $referenceCode
            ) {
                $contentTitle = $referenceCode;
            }


            /*
            |--------------------------------------------------------------------------
            | CAMPAIGN / AD / CREATIVE
            |--------------------------------------------------------------------------
            |
            | WhatsApp referral payload normally gives us source_id,
            | source_url, headline, body, etc.
            |
            | Campaign / Ad / Creative cannot safely be guessed from
            | those fields.
            |
            | Therefore these remain NULL unless we map them by REF.
            |
            |--------------------------------------------------------------------------
            */

            $campaignName = null;
            $adName       = null;
            $creativeName  = null;


            /*
            |--------------------------------------------------------------------------
            | SAVE CONVERSATION HISTORY
            |--------------------------------------------------------------------------
            */

            if ($customerPhone && $messageId) {

                $conversationSql = "

                    INSERT INTO whatsapp_conversation_messages (

                        whatsapp_message_id,
                        customer_phone,
                        customer_name,
                        direction,
                        message_type,
                        message_text,
                        status,
                        phone_number_id,
                        message_timestamp,
                        raw_payload

                    )

                    VALUES (

                        :whatsapp_message_id,
                        :customer_phone,
                        :customer_name,
                        'incoming',
                        :message_type,
                        :message_text,
                        'received',
                        :phone_number_id,
                        :message_timestamp,
                        :raw_payload

                    )

                    ON DUPLICATE KEY UPDATE

                        customer_name =
                            VALUES(customer_name),

                        message_text =
                            VALUES(message_text),

                        message_type =
                            VALUES(message_type),

                        updated_at =
                            CURRENT_TIMESTAMP
                ";


                $conversationStmt =
                    $pdo->prepare($conversationSql);


                $conversationStmt->execute([

                    ':whatsapp_message_id' =>
                        $messageId,

                    ':customer_phone' =>
                        $customerPhone,

                    ':customer_name' =>
                        $customerName,

                    ':message_type' =>
                        $messageType,

                    ':message_text' =>
                        $messageText,

                    ':phone_number_id' =>
                        $webhookPhoneNumberId,

                    ':message_timestamp' =>
                        $messageDate,

                    ':raw_payload' =>
                        $rawInput

                ]);
            }


            /*
            |--------------------------------------------------------------------------
            | SAVE REFERRAL DATA
            |--------------------------------------------------------------------------
            */

            if ($customerPhone) {

                $sql = "

                    INSERT INTO whatsapp_referrals (

                        customer_phone,
                        customer_name,

                        whatsapp_message_id,
                        message_text,
                        message_type,

                        reference_code,
                        product_code,
                        source_platform,

                        campaign_name,
                        ad_name,
                        creative_name,
                        content_title,

                        source_id,
                        source_url,
                        source_type,

                        headline,
                        body,

                        media_type,
                        image_url,
                        video_url,
                        thumbnail_url,

                        ctwa_clid,

                        phone_number_id,
                        received_at,

                        raw_payload

                    )

                    VALUES (

                        :customer_phone,
                        :customer_name,

                        :message_id,
                        :message_text,
                        :message_type,

                        :reference_code,
                        :product_code,
                        :source_platform,

                        :campaign_name,
                        :ad_name,
                        :creative_name,
                        :content_title,

                        :source_id,
                        :source_url,
                        :source_type,

                        :headline,
                        :body,

                        :media_type,
                        :image_url,
                        :video_url,
                        :thumbnail_url,

                        :ctwa_clid,

                        :phone_number_id,
                        :received_at,

                        :raw_payload

                    )

                    ON DUPLICATE KEY UPDATE

                        customer_name =
                            VALUES(customer_name),

                        message_text =
                            VALUES(message_text),

                        message_type =
                            VALUES(message_type),

                        reference_code =
                            VALUES(reference_code),

                        product_code =
                            VALUES(product_code),

                        source_platform =
                            VALUES(source_platform),

                        campaign_name =
                            VALUES(campaign_name),

                        ad_name =
                            VALUES(ad_name),

                        creative_name =
                            VALUES(creative_name),

                        content_title =
                            VALUES(content_title),

                        source_id =
                            VALUES(source_id),

                        source_url =
                            VALUES(source_url),

                        source_type =
                            VALUES(source_type),

                        headline =
                            VALUES(headline),

                        body =
                            VALUES(body),

                        media_type =
                            VALUES(media_type),

                        image_url =
                            VALUES(image_url),

                        video_url =
                            VALUES(video_url),

                        thumbnail_url =
                            VALUES(thumbnail_url),

                        ctwa_clid =
                            VALUES(ctwa_clid),

                        updated_at =
                            CURRENT_TIMESTAMP
                ";


                $stmt =
                    $pdo->prepare($sql);


                $stmt->execute([

                    ':customer_phone' =>
                        $customerPhone,

                    ':customer_name' =>
                        $customerName,

                    ':message_id' =>
                        $messageId,

                    ':message_text' =>
                        $messageText,

                    ':message_type' =>
                        $messageType,

                    ':reference_code' =>
                        $referenceCode,

                    ':product_code' =>
                        $productCode,

                    ':source_platform' =>
                        $sourcePlatform,

                    ':campaign_name' =>
                        $campaignName,

                    ':ad_name' =>
                        $adName,

                    ':creative_name' =>
                        $creativeName,

                    ':content_title' =>
                        $contentTitle,

                    ':source_id' =>
                        $sourceId,

                    ':source_url' =>
                        $sourceUrl,

                    ':source_type' =>
                        $sourceType,

                    ':headline' =>
                        $headline,

                    ':body' =>
                        $body,

                    ':media_type' =>
                        $mediaType,

                    ':image_url' =>
                        $imageUrl,

                    ':video_url' =>
                        $videoUrl,

                    ':thumbnail_url' =>
                        $thumbnailUrl,

                    ':ctwa_clid' =>
                        $ctwaClid,

                    ':phone_number_id' =>
                        $webhookPhoneNumberId,

                    ':received_at' =>
                        $messageDate,

                    ':raw_payload' =>
                        $rawInput
                ]);
            }


            /*
            |--------------------------------------------------------------------------
            | LOG INCOMING MESSAGE
            |--------------------------------------------------------------------------
            */

            writeWebhookLog(
                'INCOMING MESSAGE SAVED',
                [

                    'customer_phone' =>
                        $customerPhone,

                    'customer_name' =>
                        $customerName,

                    'message_id' =>
                        $messageId,

                    'message_type' =>
                        $messageType,

                    'message_text' =>
                        $messageText,

                    'reference_code' =>
                        $referenceCode,

                    'product_code' =>
                        $productCode,

                    'source_platform' =>
                        $sourcePlatform,

                    'source_type' =>
                        $sourceType,

                    'direction' =>
                        'incoming'
                ]
            );
        }


        /*
        |--------------------------------------------------------------------------
        | B) OUTGOING MESSAGE STATUS
        |--------------------------------------------------------------------------
        */

        $statuses =
            $value['statuses'] ?? [];


        foreach ($statuses as $statusItem) {

            $outgoingMessageId =
                $statusItem['id'] ?? null;

            $status =
                $statusItem['status'] ?? null;

            $recipientPhone =
                $statusItem['recipient_id'] ?? null;

            $statusTimestamp =
                $statusItem['timestamp'] ?? time();

            $statusDate =
                date(
                    'Y-m-d H:i:s',
                    (int)$statusTimestamp
                );


            if (!$outgoingMessageId) {
                continue;
            }


            /*
            |--------------------------------------------------------------------------
            | UPDATE EXISTING OUTGOING MESSAGE
            |--------------------------------------------------------------------------
            */

            $updateSql = "

                UPDATE whatsapp_conversation_messages

                SET

                    status =
                        :status,

                    updated_at =
                        CURRENT_TIMESTAMP

                WHERE whatsapp_message_id =
                    :message_id

            ";


            $updateStmt =
                $pdo->prepare($updateSql);


            $updateStmt->execute([

                ':status' =>
                    $status,

                ':message_id' =>
                    $outgoingMessageId

            ]);


            /*
            |--------------------------------------------------------------------------
            | IF OUTGOING MESSAGE WAS NOT SAVED BEFORE,
            | CREATE PLACEHOLDER
            |--------------------------------------------------------------------------
            */

            if ($updateStmt->rowCount() === 0) {

                $insertOutgoingSql = "

                    INSERT INTO whatsapp_conversation_messages (

                        whatsapp_message_id,
                        customer_phone,
                        customer_name,

                        direction,

                        message_type,
                        message_text,

                        status,

                        phone_number_id,
                        message_timestamp,
                        raw_payload

                    )

                    VALUES (

                        :message_id,
                        :customer_phone,
                        NULL,

                        'outgoing',

                        'unknown',
                        NULL,

                        :status,

                        :phone_number_id,
                        :message_timestamp,
                        :raw_payload

                    )

                    ON DUPLICATE KEY UPDATE

                        status =
                            VALUES(status),

                        updated_at =
                            CURRENT_TIMESTAMP
                ";


                $insertOutgoingStmt =
                    $pdo->prepare($insertOutgoingSql);


                $insertOutgoingStmt->execute([

                    ':message_id' =>
                        $outgoingMessageId,

                    ':customer_phone' =>
                        $recipientPhone,

                    ':status' =>
                        $status,

                    ':phone_number_id' =>
                        $webhookPhoneNumberId,

                    ':message_timestamp' =>
                        $statusDate,

                    ':raw_payload' =>
                        $rawInput
                ]);
            }


            /*
            |--------------------------------------------------------------------------
            | LOG OUTGOING STATUS
            |--------------------------------------------------------------------------
            */

            writeWebhookLog(
                'OUTGOING MESSAGE STATUS',
                [

                    'message_id' =>
                        $outgoingMessageId,

                    'recipient' =>
                        $recipientPhone,

                    'status' =>
                        $status,

                    'direction' =>
                        'outgoing',

                    'timestamp' =>
                        $statusDate
                ]
            );
        }
    }
}


/*
|--------------------------------------------------------------------------
| 8. TELL META SUCCESS
|--------------------------------------------------------------------------
*/

http_response_code(200);

echo 'EVENT_RECEIVED';
<?php

// ================================
// DATABASE CONFIG
// ================================

$dbHost = 'localhost';
$dbName = 'ontechslco_crm';
$dbUser = 'ontechslco_crm';
$dbPass = 'Ontech@2022';


// ================================
// WHATSAPP CONFIG
// ================================

$accessToken = 'EAARflyYnf8oBPIfm7XLUdjKne5PO1U5hlPL1P5LHlj4roWF97sQYmk3zHAfyomfuJBsaFMZAp7NxmmZAk6flhMiBOrZBPA4vm6lFihBxdoAk6CNTQd69WvSeShvzlaTrcwW7OWTs8fUlcx086vObgDBcTYaV3ld4XQLeZBiUG1ZCQinMaGmD6wxJigvTuIlQDzwZDZD';

$phoneNumberId = '693326623870717';


// ================================
// WEBHOOK VERIFICATION
// ================================

// මේක ඔයාම හදන secret word එකක්.
// Example:
// OntechWebhook2026Secure

$verifyToken = 'OntechWebhook2026Secure';


// ================================
// DATABASE CONNECTION
// ================================

try {

    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

} catch (PDOException $e) {

    http_response_code(500);

    die("Database connection failed.");

}
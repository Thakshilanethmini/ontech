<?php

return [
    'api_key' => 'AIzaSyB5ARzMWD-SLvnmE-CaOQHjootLkOWVbEE',
    'model' => 'gemini-3.8-flash',
];


<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$conn = new mysqli(
    "localhost",
    "ontechslco_kulathunga",
    "kulathunga1",
    "ontechslco_kulathunga"
);


if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
<?php

require_once "db_connect.php";

if ($conn->ping()) {
    echo "Database Connected Successfully!";
} else {
    echo "Database Connection Failed!";
}
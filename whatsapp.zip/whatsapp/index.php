<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';

/* ========================================================================
   PWA / ASSET ROUTES
   ======================================================================== */
$action = (string)($_GET['action'] ?? '');

if ($action === 'manifest') {
    $basePath = strtok($_SERVER['REQUEST_URI'] ?? '/', '?') ?: '/';
    $scope = preg_replace('~/[^/]*$~', '/', $basePath) ?: '/';

    $iconSvg = <<<'SVG'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <rect width="512" height="512" rx="112" fill="#25d366"/>
  <path d="M160 144h192c17.7 0 32 14.3 32 32v160c0 17.7-14.3 32-32 32H226l-66 56v-56h-0c-17.7 0-32-14.3-32-32V176c0-17.7 14.3-32 32-32z" fill="#ffffff"/>
  <circle cx="206" cy="248" r="18" fill="#25d366"/>
  <circle cx="256" cy="248" r="18" fill="#25d366"/>
  <circle cx="306" cy="248" r="18" fill="#25d366"/>
</svg>
SVG;
    $iconData = 'data:image/svg+xml;base64,' . base64_encode($iconSvg);

    header('Content-Type: application/manifest+json; charset=utf-8');
    echo json_encode([
        'name' => 'WhatsApp Inbox',
        'short_name' => 'Inbox',
        'description' => 'WhatsApp inbox and lead management dashboard.',
        'start_url' => $basePath,
        'scope' => $scope,
        'display' => 'standalone',
        'background_color' => '#eef2f6',
        'theme_color' => '#25d366',
        'icons' => [
            [
                'src' => $iconData,
                'sizes' => '192x192',
                'type' => 'image/svg+xml',
                'purpose' => 'any maskable'
            ],
            [
                'src' => $iconData,
                'sizes' => '512x512',
                'type' => 'image/svg+xml',
                'purpose' => 'any maskable'
            ],
        ],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($action === 'sw.js') {
    $basePath = strtok($_SERVER['REQUEST_URI'] ?? '/', '?') ?: '/';
    $startUrl = $basePath;

    header('Content-Type: application/javascript; charset=utf-8');
    echo <<<JS
const CACHE_NAME = 'wa-inbox-v1';
const APP_SHELL = ['{$startUrl}'];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;

  const requestUrl = new URL(event.request.url);
  if (requestUrl.origin !== self.location.origin) return;

  event.respondWith(
    fetch(event.request)
      .then(response => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
        return response;
      })
      .catch(() => caches.match(event.request).then(cached => cached || caches.match(APP_SHELL[0])))
  );
});
JS;
    exit;
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (empty($_SESSION['wa_inbox_csrf'])) {
    $_SESSION['wa_inbox_csrf'] = bin2hex(random_bytes(32));
}

$waInboxCsrf = $_SESSION['wa_inbox_csrf'];

/* ========================================================================
   JSON API
   ======================================================================== */
function jsonOut($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}

function cleanVal(?string $v): ?string
{
    $v = trim((string)$v);
    return $v === '' ? null : $v;
}

function ensureCallTrackingTable(PDO $pdo): void
{
    $pdo->exec("\n        CREATE TABLE IF NOT EXISTS whatsapp_customer_call_status (\n            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n            customer_phone VARCHAR(32) NOT NULL,\n            customer_name VARCHAR(255) NULL,\n            conversation_message_id BIGINT UNSIGNED NULL,\n            call_status ENUM('not_called','called','rejected','try_again') NOT NULL DEFAULT 'not_called',\n            attempt_count INT UNSIGNED NOT NULL DEFAULT 0,\n            called_at DATETIME NULL,\n            chat_bucket ENUM('inbox','pending','old') NOT NULL DEFAULT 'inbox',\n            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n            PRIMARY KEY (id),\n            KEY idx_call_customer_phone (customer_phone),\n            KEY idx_call_status (call_status),\n            KEY idx_call_related_message (conversation_message_id),\n            KEY idx_called_at (called_at),\n            KEY idx_chat_bucket (chat_bucket)\n        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci\n    ");

    $dbName = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();

    $columnExists = static function (string $column) use ($pdo, $dbName): bool {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=:schema AND TABLE_NAME='whatsapp_customer_call_status' AND COLUMN_NAME=:column");
        $stmt->execute([':schema'=>$dbName, ':column'=>$column]);
        return (int)$stmt->fetchColumn() > 0;
    };
    $indexExists = static function (string $indexName) use ($pdo, $dbName): bool {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=:schema AND TABLE_NAME='whatsapp_customer_call_status' AND INDEX_NAME=:index_name");
        $stmt->execute([':schema'=>$dbName, ':index_name'=>$indexName]);
        return (int)$stmt->fetchColumn() > 0;
    };

    try {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status MODIFY call_status ENUM('uncalled','not_called','called','rejected','try_again') NOT NULL DEFAULT 'not_called'");
    } catch (Throwable $e) {}

    if (!$columnExists('conversation_message_id')) {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD COLUMN conversation_message_id BIGINT UNSIGNED NULL AFTER customer_name");
    }
    if (!$columnExists('attempt_count')) {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD COLUMN attempt_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER call_status");
    }
    if (!$columnExists('called_at')) {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD COLUMN called_at DATETIME NULL AFTER attempt_count");
    }
    if (!$columnExists('chat_bucket')) {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD COLUMN chat_bucket ENUM('inbox','pending','old') NOT NULL DEFAULT 'inbox' AFTER called_at");
    }

    // Keep the chat bucket compatible with Inbox / Pending / Old.
    try {
        $pdo->exec("ALTER TABLE whatsapp_customer_call_status MODIFY chat_bucket ENUM('inbox','pending','old') NOT NULL DEFAULT 'inbox'");
    } catch (Throwable $e) {}

    // IMPORTANT: statuses are per conversation message, not per customer.
    if ($indexExists('uq_customer_phone')) {
        try { $pdo->exec("ALTER TABLE whatsapp_customer_call_status DROP INDEX uq_customer_phone"); }
        catch (Throwable $e) {}
    }
    if (!$indexExists('idx_call_customer_phone')) {
        try { $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD KEY idx_call_customer_phone (customer_phone)"); }
        catch (Throwable $e) {}
    }
    if (!$indexExists('idx_call_related_message')) {
        try { $pdo->exec("ALTER TABLE whatsapp_customer_call_status ADD KEY idx_call_related_message (conversation_message_id)"); }
        catch (Throwable $e) {}
    }

    $pdo->exec("UPDATE whatsapp_customer_call_status SET call_status='not_called' WHERE call_status='uncalled'");
    $pdo->exec("UPDATE whatsapp_customer_call_status SET attempt_count=1 WHERE call_status IN ('called','rejected','try_again') AND attempt_count=0");
    $pdo->exec("ALTER TABLE whatsapp_customer_call_status MODIFY call_status ENUM('not_called','called','rejected','try_again') NOT NULL DEFAULT 'not_called'");

    // Back-fill legacy rows without a relation. Prefer lead/referral messages.
    $pdo->exec("\n        UPDATE whatsapp_customer_call_status cs
        INNER JOIN (\n            SELECT RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9) AS phone9,\n                   MAX(id) AS max_message_id\n            FROM whatsapp_conversation_messages\n            WHERE has_referral=1 AND customer_phone IS NOT NULL AND customer_phone<>''\n            GROUP BY RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n        ) lm ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)=lm.phone9\n        SET cs.conversation_message_id=lm.max_message_id\n        WHERE cs.conversation_message_id IS NULL\n    ");

    $pdo->exec("\n        UPDATE whatsapp_customer_call_status cs
        INNER JOIN (
            SELECT RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9) AS phone9,
                   MAX(id) AS max_message_id
            FROM whatsapp_conversation_messages
            WHERE customer_phone IS NOT NULL AND customer_phone<>''
            GROUP BY RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
        ) lm ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)=lm.phone9
        SET cs.conversation_message_id=lm.max_message_id
        WHERE cs.conversation_message_id IS NULL
    ");

    $attemptTableExists=(int)$pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='whatsapp_customer_call_attempts'")->fetchColumn()>0;
    if ($attemptTableExists) {
        $pdo->exec("\n            UPDATE whatsapp_customer_call_status cs
            INNER JOIN (SELECT customer_phone,COUNT(*) AS cnt FROM whatsapp_customer_call_attempts GROUP BY customer_phone) a
              ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)=RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(a.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
            SET cs.attempt_count=GREATEST(cs.attempt_count,a.cnt),
                cs.call_status=CASE WHEN cs.call_status='not_called' AND a.cnt>0 THEN 'called' ELSE cs.call_status END,
                cs.called_at=CASE WHEN cs.called_at IS NULL AND a.cnt>0 THEN CURRENT_TIMESTAMP ELSE cs.called_at END
        ");
    }
    $pdo->exec("DROP TABLE IF EXISTS whatsapp_customer_call_attempts");
}

/**
 * Return a conversation message id that is known to belong to the given phone.
 * When the UI does not provide a specific row/message id, the latest message
 * for that customer is used so every status update still has a relation.
 */
function resolveRelatedConversationMessageId(PDO $pdo, string $phone, ?int $candidateId = null): ?int
{
    $phone = trim($phone);
    if ($phone === '') {
        return null;
    }

    $phoneNorm = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)";
    $candidate = (int)($candidateId ?? 0);

    if ($candidate > 0) {
        $stmt = $pdo->prepare("\n            SELECT id\n            FROM whatsapp_conversation_messages\n            WHERE id = :id\n              AND $phoneNorm = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n            LIMIT 1\n        ");
        $stmt->execute([
            ':id' => $candidate,
            ':phone' => $phone,
        ]);
        $valid = $stmt->fetchColumn();
        if ($valid !== false) {
            return (int)$valid;
        }
    }

    $stmt = $pdo->prepare("\n        SELECT id\n        FROM whatsapp_conversation_messages\n        WHERE $phoneNorm = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n        ORDER BY id DESC\n        LIMIT 1\n    ");
    $stmt->execute([':phone' => $phone]);

    $id = $stmt->fetchColumn();
    return $id === false ? null : (int)$id;
}

function getCallStatusRows(PDO $pdo, array $filters = [], int $limit = 500): array
{
    $limit = min(500, max(10, $limit));
    $params = [];
    $where = buildConversationFilters($filters, $params);

    $sql = "
        SELECT
            m.customer_phone,
            m.customer_name,
            m.message_timestamp AS last_message_at,
            m.message_text AS last_message_text,
            m.direction AS last_message_direction,
            m.message_source AS last_message_source,
            (
                SELECT COUNT(*)
                FROM whatsapp_conversation_messages c2
                WHERE c2.customer_phone = m.customer_phone
            ) AS total_messages,
            COALESCE(cs.call_status, 'not_called') AS call_status,
            cs.called_at,
            cs.updated_at AS call_status_updated_at
        FROM whatsapp_conversation_messages m
        INNER JOIN (
            SELECT customer_phone, MAX(id) AS max_id
            FROM whatsapp_conversation_messages
            GROUP BY customer_phone
        ) latest
            ON latest.max_id = m.id
        LEFT JOIN whatsapp_customer_call_status cs
            ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
             = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
           AND cs.id = (
                SELECT cs2.id
                FROM whatsapp_customer_call_status cs2
                WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs2.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                    = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                ORDER BY cs2.updated_at DESC, cs2.id DESC
                LIMIT 1
           )
    ";

    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }

    $sql .= "
        ORDER BY
            CASE WHEN COALESCE(cs.call_status, 'not_called') = 'not_called' THEN 0 ELSE 1 END ASC,
            m.id DESC
        LIMIT $limit
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/* =========================================================================
   ACTION / SEND HELPERS
   ========================================================================= */
function requirePostCsrf(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        jsonOut(['error' => 'POST required'], 405);
    }

    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';

    if (
        $token === '' ||
        !hash_equals(
            (string)($_SESSION['wa_inbox_csrf'] ?? ''),
            $token
        )
    ) {
        jsonOut(['error' => 'Invalid CSRF token'], 403);
    }
}

function readJsonBody(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '', true);

    if (!is_array($data)) {
        jsonOut(['error' => 'Invalid JSON body'], 400);
    }

    return $data;
}

function normalizeWhatsAppPhone(string $phone): string
{
    $phone = trim($phone);
    $phone = preg_replace('/[^\d+]/', '', $phone) ?? '';

    if (str_starts_with($phone, '+')) {
        $phone = substr($phone, 1);
    }

    if (preg_match('/^0\d{8,11}$/', $phone)) {
        $phone = '94' . substr($phone, 1);
    }

    return preg_replace('/\D+/', '', $phone) ?? '';
}

function graphApiPost(
    string $url,
    string $accessToken,
    array $payload
): array {
    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS => json_encode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        ),
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT => 30,
    ]);

    $body = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    if ($body === false) {
        throw new RuntimeException(
            'Graph API connection failed: ' . $curlError
        );
    }

    $data = json_decode($body, true);

    if (!is_array($data)) {
        throw new RuntimeException(
            'Graph API returned invalid JSON. HTTP ' . $httpCode
        );
    }

    if (
        $httpCode < 200 ||
        $httpCode >= 300 ||
        isset($data['error'])
    ) {
        $message = $data['error']['message'] ?? 'Unknown Graph API error';
        $code = $data['error']['code'] ?? $httpCode;

        throw new RuntimeException(
            'WhatsApp API error [' . $code . ']: ' . $message
        );
    }

    return $data;
}

function sendWhatsAppText(
    PDO $pdo,
    string $to,
    string $text,
    ?string $customerName = null,
    string $messageSource = 'Manual Reply'
): array {
    global $accessToken, $phoneNumberId, $graphApiVersion;

    if (
        !isset($accessToken) ||
        trim((string)$accessToken) === ''
    ) {
        throw new RuntimeException(
            'WhatsApp access token is not configured.'
        );
    }

    if (
        !isset($phoneNumberId) ||
        trim((string)$phoneNumberId) === ''
    ) {
        throw new RuntimeException(
            'WhatsApp phone number ID is not configured.'
        );
    }

    $storedPhone = trim($to);
    $to = normalizeWhatsAppPhone($to);
    $text = trim($text);

    if ($to === '') {
        throw new RuntimeException('Invalid recipient phone number.');
    }

    if ($text === '') {
        throw new RuntimeException('Message text is empty.');
    }

    if (mb_strlen($text) > 4096) {
        throw new RuntimeException(
            'Text message is too long. Maximum is 4096 characters.'
        );
    }

    $version = trim((string)($graphApiVersion ?? 'v23.0'));

    if ($version === '') {
        $version = 'v23.0';
    }

    $url =
        'https://graph.facebook.com/' .
        rawurlencode($version) . '/' .
        rawurlencode((string)$phoneNumberId) .
        '/messages';

    $apiResponse = graphApiPost(
        $url,
        (string)$accessToken,
        [
            'messaging_product' => 'whatsapp',
            'recipient_type' => 'individual',
            'to' => $to,
            'type' => 'text',
            'text' => [
                'preview_url' => false,
                'body' => $text,
            ],
        ]
    );

    $messageId =
        $apiResponse['messages'][0]['id'] ?? null;

    if (!$messageId) {
        throw new RuntimeException(
            'WhatsApp API accepted the request but did not return a message ID.'
        );
    }

    $timestamp = date('Y-m-d H:i:s');

    $stmt = $pdo->prepare("
        INSERT INTO whatsapp_conversation_messages (
            whatsapp_message_id,
            customer_phone,
            customer_name,
            direction,
            message_type,
            message_text,
            message_source,
            has_referral,
            status,
            phone_number_id,
            message_timestamp,
            received_at,
            raw_payload
        )
        VALUES (
            :message_id,
            :customer_phone,
            :customer_name,
            'outgoing',
            'text',
            :message_text,
            :message_source,
            0,
            'sent',
            :phone_number_id,
            :message_timestamp,
            :received_at,
            :raw_payload
        )
        ON DUPLICATE KEY UPDATE
            customer_name =
                COALESCE(VALUES(customer_name), customer_name),
            message_text =
                VALUES(message_text),
            status =
                VALUES(status),
            updated_at =
                CURRENT_TIMESTAMP
    ");

    $stmt->execute([
        ':message_id' => $messageId,
        ':customer_phone' => $storedPhone,
        ':customer_name' => $customerName,
        ':message_text' => $text,
        ':message_source' => $messageSource,
        ':phone_number_id' => $phoneNumberId,
        ':message_timestamp' => $timestamp,
        ':received_at' => $timestamp,
        ':raw_payload' => json_encode(
            [
                'source' => 'whatsapp_inbox',
                'api_response' => $apiResponse,
            ],
            JSON_UNESCAPED_UNICODE |
            JSON_UNESCAPED_SLASHES
        ),
    ]);

    return [
        'to' => $to,
        'message_id' => $messageId,
        'status' => 'sent',
    ];
}


/**
 * Automatically reply to the first incoming message from a brand-new WhatsApp contact.
 *
 * This dashboard file is not the Meta webhook receiver, so the check runs from the
 * existing 8-second inbox auto-refresh. A small state table prevents historical
 * contacts from being treated as new when this feature is first enabled.
 */
function autoReplyNewContacts(PDO $pdo): array
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS whatsapp_auto_reply_state (
            id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
            initialized TINYINT(1) NOT NULL DEFAULT 0,
            last_message_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS whatsapp_auto_reply_log (
            incoming_message_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
            customer_phone VARCHAR(32) NOT NULL,
            status ENUM('sent','failed') NOT NULL DEFAULT 'sent',
            auto_reply_message_id VARCHAR(191) NULL,
            error_message TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                ON UPDATE CURRENT_TIMESTAMP,
            KEY idx_auto_reply_phone (customer_phone),
            KEY idx_auto_reply_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        INSERT INTO whatsapp_auto_reply_state (id, initialized, last_message_id)
        VALUES (1, 0, 0)
        ON DUPLICATE KEY UPDATE id = id
    ");

    // Prevent two open inbox tabs from replying to the same new contact at once.
    $lockStmt = $pdo->query("SELECT GET_LOCK('wa_inbox_auto_reply_new_contacts', 5)");
    $lockAcquired = (int)$lockStmt->fetchColumn() === 1;

    if (!$lockAcquired) {
        return [
            'ok' => false,
            'sent_count' => 0,
            'skipped_count' => 0,
            'error_count' => 0,
            'message' => 'Auto-reply lock is busy.',
        ];
    }

    try {
        $stateStmt = $pdo->query("
            SELECT initialized, last_message_id
            FROM whatsapp_auto_reply_state
            WHERE id = 1
            LIMIT 1
        ");
        $state = $stateStmt->fetch(PDO::FETCH_ASSOC) ?: [
            'initialized' => 0,
            'last_message_id' => 0,
        ];

        $maxId = (int)$pdo->query(
            "SELECT COALESCE(MAX(id), 0) FROM whatsapp_conversation_messages"
        )->fetchColumn();

        // First run: establish the current watermark so old contacts are never
        // treated as new. New messages after this point are processed normally.
        if ((int)$state['initialized'] !== 1) {
            $init = $pdo->prepare("
                UPDATE whatsapp_auto_reply_state
                SET initialized = 1,
                    last_message_id = :last_id,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = 1
            ");
            $init->execute([':last_id' => $maxId]);

            return [
                'ok' => true,
                'sent_count' => 0,
                'skipped_count' => 0,
                'error_count' => 0,
                'initialized' => true,
            ];
        }

        $lastId = (int)$state['last_message_id'];
        if ($maxId <= $lastId) {
            return [
                'ok' => true,
                'sent_count' => 0,
                'skipped_count' => 0,
                'error_count' => 0,
            ];
        }

        $stmt = $pdo->prepare("
            SELECT
                m.id,
                m.customer_phone,
                m.customer_name
            FROM whatsapp_conversation_messages m
            WHERE m.id > :last_id
              AND m.id <= :max_id
              AND m.direction = 'incoming'
              AND m.customer_phone IS NOT NULL
              AND m.customer_phone <> ''
            ORDER BY m.id ASC
            LIMIT 200
        ");
        $stmt->execute([
            ':last_id' => $lastId,
            ':max_id' => $maxId,
        ]);

        $incomingRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $sentCount = 0;
        $skippedCount = 0;
        $errorCount = 0;

        $firstIncomingStmt = $pdo->prepare("
            SELECT id
            FROM whatsapp_conversation_messages
            WHERE customer_phone = :phone
              AND direction = 'incoming'
            ORDER BY id ASC
            LIMIT 1
        ");

        $alreadySentStmt = $pdo->prepare("
            SELECT auto_reply_message_id
            FROM whatsapp_auto_reply_log
            WHERE incoming_message_id = :incoming_message_id
              AND status = 'sent'
            LIMIT 1
        ");

        foreach ($incomingRows as $row) {
            $incomingId = (int)$row['id'];
            $phone = trim((string)$row['customer_phone']);
            $customerName = $row['customer_name'] !== null
                ? trim((string)$row['customer_name'])
                : null;

            if ($phone === '') {
                $skippedCount++;
                continue;
            }

            $firstIncomingStmt->execute([':phone' => $phone]);
            $firstIncomingId = (int)($firstIncomingStmt->fetchColumn() ?: 0);

            // Only the first-ever incoming message of a phone number qualifies.
            if ($firstIncomingId !== $incomingId) {
                $skippedCount++;
                continue;
            }

            $alreadySentStmt->execute([':incoming_message_id' => $incomingId]);
            if ($alreadySentStmt->fetchColumn() !== false) {
                $skippedCount++;
                continue;
            }

            $autoReplyText = <<<TEXT
Hi Sir/Madam 👋

Thank you for contacting ONTECH IT SOLUTION.
Please share:
• Company Name
• A phone number for a normal call
• Preferred date & time for a call

We can explain the details over the call. Thank you.

ආයුබෝවන් මහත්මයා/මහත්මියනි 👋
ONTECH IT SOLUTION වෙත සම්බන්ධ වූවාට ස්තුතියි.
කරුණාකර:
• Company Name
• සාමාන්‍ය Call එකක් සඳහා දුරකථන අංකය
• Call එකකට පහසු දිනය සහ වේලාව
එවන්න.
විස්තර Call එකකින් පැහැදිලි කරගත හැක. ස්තුතියි.
TEXT;

            try {
                $result = sendWhatsAppText(
                    $pdo,
                    $phone,
                    $autoReplyText,
                    $customerName,
                    'Auto Reply'
                );

                $log = $pdo->prepare("
                    INSERT INTO whatsapp_auto_reply_log
                        (incoming_message_id, customer_phone, status, auto_reply_message_id, error_message)
                    VALUES
                        (:incoming_message_id, :customer_phone, 'sent', :auto_reply_message_id, NULL)
                    ON DUPLICATE KEY UPDATE
                        status = 'sent',
                        auto_reply_message_id = VALUES(auto_reply_message_id),
                        error_message = NULL,
                        updated_at = CURRENT_TIMESTAMP
                ");
                $log->execute([
                    ':incoming_message_id' => $incomingId,
                    ':customer_phone' => $phone,
                    ':auto_reply_message_id' => $result['message_id'] ?? null,
                ]);

                $sentCount++;
            } catch (Throwable $e) {
                $errorCount++;

                $log = $pdo->prepare("
                    INSERT INTO whatsapp_auto_reply_log
                        (incoming_message_id, customer_phone, status, auto_reply_message_id, error_message)
                    VALUES
                        (:incoming_message_id, :customer_phone, 'failed', NULL, :error_message)
                    ON DUPLICATE KEY UPDATE
                        status = 'failed',
                        error_message = VALUES(error_message),
                        updated_at = CURRENT_TIMESTAMP
                ");
                $log->execute([
                    ':incoming_message_id' => $incomingId,
                    ':customer_phone' => $phone,
                    ':error_message' => mb_substr($e->getMessage(), 0, 1000),
                ]);
            }
        }

        $updateState = $pdo->prepare("
            UPDATE whatsapp_auto_reply_state
            SET last_message_id = :last_id,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = 1
        ");
        $updateState->execute([':last_id' => $maxId]);

        return [
            'ok' => $errorCount === 0,
            'sent_count' => $sentCount,
            'skipped_count' => $skippedCount,
            'error_count' => $errorCount,
        ];
    } finally {
        $pdo->query("SELECT RELEASE_LOCK('wa_inbox_auto_reply_new_contacts')");
    }
}

function buildConversationFilters(array $p, array &$params): array
{
    $where = [];

    /* Search all messages + referral fields belonging to the conversation. */
    if (!empty($p['q'])) {
        $where[] = "(
            EXISTS (
                SELECT 1
                FROM whatsapp_conversation_messages s
                WHERE s.customer_phone = m.customer_phone
                  AND (
                      s.message_text LIKE :q1
                      OR s.customer_name LIKE :q2
                      OR s.customer_phone LIKE :q3
                      OR s.reference_code LIKE :q4
                      OR s.product_code LIKE :q5
                      OR s.content_title LIKE :q6
                      OR s.headline LIKE :q7
                      OR s.body LIKE :q8
                      OR s.ctwa_clid LIKE :q9
                  )
            )
        )";

        $like = '%' . $p['q'] . '%';

        for ($i = 1; $i <= 9; $i++) {
            $params[":q$i"] = $like;
        }
    }

    /* Message source anywhere in the conversation. */
    if (!empty($p['source'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.message_source = :source
        )";
        $params[':source'] = $p['source'];
    }

    /* Platform anywhere in referral messages of the conversation. */
    if (!empty($p['platform'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.source_platform = :platform
              AND s.has_referral = 1
        )";
        $params[':platform'] = $p['platform'];
    }

    if (!empty($p['source_type'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.source_type = :source_type
              AND s.has_referral = 1
        )";
        $params[':source_type'] = $p['source_type'];
    }

    if (!empty($p['product'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.product_code = :product
              AND s.has_referral = 1
        )";
        $params[':product'] = $p['product'];
    }

    if (!empty($p['reference'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.reference_code LIKE :reference
              AND s.has_referral = 1
        )";
        $params[':reference'] = '%' . $p['reference'] . '%';
    }

    if (($p['referral'] ?? '') === 'yes') {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.has_referral = 1
        )";
    } elseif (($p['referral'] ?? '') === 'no') {
        $where[] = "NOT EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.has_referral = 1
        )";
    }

    if (($p['ctwa'] ?? '') === 'yes') {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.ctwa_clid IS NOT NULL
              AND s.ctwa_clid <> ''
        )";
    }

    if (!empty($p['message_type'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.message_type = :message_type
        )";
        $params[':message_type'] = $p['message_type'];
    }

    if (!empty($p['date_from'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND DATE(s.message_timestamp) >= :date_from
        )";
        $params[':date_from'] = $p['date_from'];
    }

    if (!empty($p['date_to'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND DATE(s.message_timestamp) <= :date_to
        )";
        $params[':date_to'] = $p['date_to'];
    }

    return $where;
}

function buildLeadFilters(array $p, array &$params, string $messageAlias = 'm'): array
{
    $m = preg_replace('/[^a-zA-Z0-9_]/', '', $messageAlias) ?: 'm';

    $where = [
        "$m.has_referral = 1",
        "$m.customer_phone IS NOT NULL",
        "$m.customer_phone <> ''",
    ];

    if (!empty($p['q'])) {
        $searchFields = [
            "$m.customer_phone",
            "$m.customer_name",
            "$m.message_text",
            "$m.message_type",
            "$m.message_source",
            "$m.status",
            "$m.reference_code",
            "$m.product_code",
            "$m.source_type",
            "$m.source_platform",
            "$m.content_title",
            "$m.headline",
            "$m.body",
            "$m.ctwa_clid",
            "$m.campaign_name",
            "$m.ad_name",
            "$m.creative_name",
            "$m.source_id",
            "$m.source_url",
        ];

        $searchParts = [];
        $like = '%' . $p['q'] . '%';
        foreach ($searchFields as $i => $field) {
            $key = ':q' . ($i + 1);
            $searchParts[] = "$field LIKE $key";
            $params[$key] = $like;
        }

        $where[] = '(' . implode(' OR ', $searchParts) . ')';
    }

    if (!empty($p['platform'])) {
        $where[] = "$m.source_platform = :platform";
        $params[':platform'] = $p['platform'];
    }

    if (!empty($p['source_type'])) {
        $where[] = "$m.source_type = :source_type";
        $params[':source_type'] = $p['source_type'];
    }

    if (!empty($p['product'])) {
        $where[] = "$m.product_code = :product";
        $params[':product'] = $p['product'];
    }

    if (!empty($p['reference'])) {
        $where[] = "$m.reference_code LIKE :reference";
        $params[':reference'] = '%' . $p['reference'] . '%';
    }

    if (($p['ctwa'] ?? '') === 'yes') {
        $where[] = "$m.ctwa_clid IS NOT NULL AND $m.ctwa_clid <> ''";
    }

    /*
     * Lead call state is based on the exact conversation_message_id.
     * Missing status row = Not called.
     */
    $callState = (string)($p['call_status'] ?? '');
    if (in_array($callState, ['not_called','called','rejected','try_again','attempted'], true)) {
        if ($callState === 'not_called') {
            $where[] = "NOT EXISTS (\n                SELECT 1 FROM whatsapp_customer_call_status cs2\n                WHERE cs2.conversation_message_id = $m.id\n                  AND cs2.call_status IN ('called','rejected','try_again')\n            )";
        } elseif ($callState === 'attempted') {
            $where[] = "EXISTS (\n                SELECT 1 FROM whatsapp_customer_call_status cs2\n                WHERE cs2.conversation_message_id = $m.id\n                  AND cs2.call_status IN ('rejected','try_again')\n            )";
        } else {
            $where[] = "EXISTS (\n                SELECT 1 FROM whatsapp_customer_call_status cs2\n                WHERE cs2.conversation_message_id = $m.id\n                  AND cs2.call_status = :call_status_filter\n            )";
            $params[':call_status_filter'] = $callState;
        }
    }

    if (!empty($p['date_from'])) {
        $where[] = "DATE(COALESCE($m.received_at, $m.message_timestamp)) >= :date_from";
        $params[':date_from'] = $p['date_from'];
    }

    if (!empty($p['date_to'])) {
        $where[] = "DATE(COALESCE($m.received_at, $m.message_timestamp)) <= :date_to";
        $params[':date_to'] = $p['date_to'];
    }

    return $where;
}

$action = (string)($_GET['action'] ?? '');

if ($action !== '') {

    try {

        if (!isset($pdo) || !($pdo instanceof PDO)) {
            throw new RuntimeException(
                'PDO connection ($pdo) not found in config.php'
            );
        }

        ensureCallTrackingTable($pdo);

        $filters = [
            'q'            => cleanVal($_GET['q']            ?? null),
            'source'       => cleanVal($_GET['source']       ?? null),
            'platform'     => cleanVal($_GET['platform']     ?? null),
            'source_type'  => cleanVal($_GET['source_type']  ?? null),
            'product'      => cleanVal($_GET['product']      ?? null),
            'reference'    => cleanVal($_GET['reference']    ?? null),
            'referral'     => cleanVal($_GET['referral']     ?? null),
            'ctwa'         => cleanVal($_GET['ctwa']         ?? null),
            'call_status'  => cleanVal($_GET['call_status']  ?? null),
            'message_type' => cleanVal($_GET['message_type'] ?? null),
            'date_from'    => cleanVal($_GET['date_from']    ?? null),
            'date_to'      => cleanVal($_GET['date_to']      ?? null),
            'sort'         => cleanVal($_GET['sort']         ?? null),
        ];

        switch ($action) {

            /* ============================================================== 
               STATS
            ============================================================== */
            case 'stats':

                $normMsg = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cm.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)";
                $normStatus = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)";

                jsonOut([
                    'conversations' => (int)$pdo->query("\n                        SELECT COUNT(*)\n                        FROM (\n                            SELECT cm.customer_phone\n                            FROM whatsapp_conversation_messages cm\n                            LEFT JOIN whatsapp_customer_call_status cs\n                              ON $normStatus = $normMsg\n                            GROUP BY cm.customer_phone\n                            HAVING COALESCE(MAX(cs.chat_bucket), 'inbox') = 'inbox'\n                        ) x\n                    ")->fetchColumn(),

                    'old_conversations' => (int)$pdo->query("\n                        SELECT COUNT(*)\n                        FROM (\n                            SELECT cm.customer_phone\n                            FROM whatsapp_conversation_messages cm\n                            LEFT JOIN whatsapp_customer_call_status cs\n                              ON $normStatus = $normMsg\n                            GROUP BY cm.customer_phone\n                            HAVING MAX(cs.chat_bucket) = 'old'\n                        ) x\n                    ")->fetchColumn(),

                    'pending_conversations' => (int)$pdo->query("\n                        SELECT COUNT(*)\n                        FROM (\n                            SELECT cm.customer_phone\n                            FROM whatsapp_conversation_messages cm\n                            LEFT JOIN whatsapp_customer_call_status cs\n                              ON $normStatus = $normMsg\n                            GROUP BY cm.customer_phone\n                            HAVING MAX(cs.chat_bucket) = 'pending'\n                        ) x\n                    ")->fetchColumn(),

                    'messages' => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_conversation_messages")->fetchColumn(),

                    'leads' => (int)$pdo->query("\n                        SELECT COUNT(DISTINCT customer_phone)\n                        FROM whatsapp_conversation_messages\n                        WHERE has_referral = 1\n                          AND customer_phone IS NOT NULL\n                          AND customer_phone <> ''\n                    ")->fetchColumn(),

                    'not_called' => (int)$pdo->query("
                        SELECT COUNT(*)
                        FROM whatsapp_conversation_messages m
                        WHERE m.has_referral = 1
                          AND m.customer_phone IS NOT NULL
                          AND m.customer_phone <> ''
                          AND NOT EXISTS (
                              SELECT 1
                              FROM whatsapp_customer_call_status cs
                              WHERE cs.conversation_message_id = m.id
                                AND cs.call_status IN ('called','rejected','try_again')
                          )
                    ")->fetchColumn(),

                    'called' => (int)$pdo->query("
                        SELECT COUNT(*)
                        FROM whatsapp_conversation_messages m
                        INNER JOIN whatsapp_customer_call_status cs
                            ON cs.conversation_message_id = m.id
                           AND cs.call_status = 'called'
                        WHERE m.has_referral = 1
                          AND m.customer_phone IS NOT NULL
                          AND m.customer_phone <> ''
                    ")->fetchColumn(),

                    'rejected' => (int)$pdo->query("
                        SELECT COUNT(*)
                        FROM whatsapp_conversation_messages m
                        INNER JOIN whatsapp_customer_call_status cs
                            ON cs.conversation_message_id = m.id
                           AND cs.call_status = 'rejected'
                        WHERE m.has_referral = 1
                          AND m.customer_phone IS NOT NULL
                          AND m.customer_phone <> ''
                    ")->fetchColumn(),

                    'try_again' => (int)$pdo->query("
                        SELECT COUNT(*)
                        FROM whatsapp_conversation_messages m
                        INNER JOIN whatsapp_customer_call_status cs
                            ON cs.conversation_message_id = m.id
                           AND cs.call_status = 'try_again'
                        WHERE m.has_referral = 1
                          AND m.customer_phone IS NOT NULL
                          AND m.customer_phone <> ''
                    ")->fetchColumn(),

                    'lead_messages' => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_conversation_messages WHERE has_referral = 1")->fetchColumn(),

                    'today' => (int)$pdo->query("\n                        SELECT COUNT(*)\n                        FROM whatsapp_conversation_messages\n                        WHERE DATE(message_timestamp) = CURDATE()\n                    ")->fetchColumn(),
                ]);

            /* ============================================================== 
               FILTER OPTIONS
            ============================================================== */
            case 'filter_options':

                $opt = [
                    'sources' => $pdo->query(
                        "SELECT DISTINCT message_source
                         FROM whatsapp_conversation_messages
                         WHERE message_source IS NOT NULL
                           AND message_source <> ''
                         ORDER BY message_source"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'platforms' => $pdo->query(
                        "SELECT DISTINCT source_platform
                         FROM whatsapp_conversation_messages
                         WHERE has_referral = 1
                           AND source_platform IS NOT NULL
                           AND source_platform <> ''
                         ORDER BY source_platform"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'source_types' => $pdo->query(
                        "SELECT DISTINCT source_type
                         FROM whatsapp_conversation_messages
                         WHERE has_referral = 1
                           AND source_type IS NOT NULL
                           AND source_type <> ''
                         ORDER BY source_type"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'products' => $pdo->query(
                        "SELECT DISTINCT product_code
                         FROM whatsapp_conversation_messages
                         WHERE has_referral = 1
                           AND product_code IS NOT NULL
                           AND product_code <> ''
                         ORDER BY product_code"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'message_types' => $pdo->query(
                        "SELECT DISTINCT message_type
                         FROM whatsapp_conversation_messages
                         WHERE message_type IS NOT NULL
                           AND message_type <> ''
                         ORDER BY message_type"
                    )->fetchAll(PDO::FETCH_COLUMN),
                ];

                jsonOut(['data' => $opt]);

            /* ============================================================== 
               CONVERSATION LIST
            ============================================================== */
            case 'conversations':

                $limit = min(
                    500,
                    max(10, (int)($_GET['limit'] ?? 300))
                );

                $params = [];
                $where = buildConversationFilters($filters, $params);

                $box = strtolower(trim((string)($_GET['box'] ?? 'inbox')));
                if (!in_array($box, ['inbox', 'pending', 'old'], true)) {
                    $box = 'inbox';
                }
                $where[] = "COALESCE(cs.chat_bucket, 'inbox') = '$box'";

                switch ($filters['sort']) {
                    case 'oldest':
                        $order = 'm.id ASC';
                        break;

                    case 'name':
                        $order = 'COALESCE(m.customer_name, m.customer_phone) ASC';
                        break;

                    case 'messages':
                        $order = 'total_messages DESC';
                        break;

                    default:
                        $order = 'm.id DESC';
                        break;
                }

                /*
                 * m = latest message for each customer.
                 * lr = latest referral-bearing message for the same customer.
                 * Both come from the SAME table.
                 */
                $sql = "
                    SELECT
                        m.id,
                        m.customer_phone,
                        m.customer_name,
                        m.message_text,
                        m.message_type,
                        m.message_source,
                        m.direction,
                        m.status,
                        m.message_timestamp,
                        COALESCE(cs.call_status, 'not_called') AS call_status,
                        cs.called_at,
                        cs.updated_at AS call_status_updated_at,

                        (
                            SELECT COUNT(*)
                            FROM whatsapp_conversation_messages c2
                            WHERE c2.customer_phone = m.customer_phone
                        ) AS total_messages,

                        lr.reference_code,
                        lr.product_code,
                        lr.source_platform,
                        lr.source_type,
                        lr.content_title,
                        lr.ctwa_clid,
                        lr.id AS referral_message_id

                    FROM whatsapp_conversation_messages m

                    INNER JOIN (
                        SELECT customer_phone, MAX(id) AS max_id
                        FROM whatsapp_conversation_messages
                        GROUP BY customer_phone
                    ) latest
                        ON latest.max_id = m.id

                    LEFT JOIN (
                        SELECT
                            customer_phone,
                            MAX(id) AS max_ref_id
                        FROM whatsapp_conversation_messages
                        WHERE has_referral = 1
                        GROUP BY customer_phone
                    ) latest_ref
                        ON latest_ref.customer_phone = m.customer_phone

                    LEFT JOIN whatsapp_conversation_messages lr
                        ON lr.id = latest_ref.max_ref_id
                    LEFT JOIN whatsapp_customer_call_status cs
                        ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                         = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                       AND cs.id = (
                            SELECT cs2.id
                            FROM whatsapp_customer_call_status cs2
                            WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs2.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                                = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                            ORDER BY cs2.updated_at DESC, cs2.id DESC
                            LIMIT 1
                       )
                       AND cs.id = (
                            SELECT cs2.id
                            FROM whatsapp_customer_call_status cs2
                            WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs2.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                                = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                            ORDER BY cs2.updated_at DESC, cs2.id DESC
                            LIMIT 1
                       )
                ";

                if ($where) {
                    $sql .= ' WHERE ' . implode(' AND ', $where);
                }

                $sql .= " ORDER BY $order LIMIT $limit";

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                jsonOut([
                    'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
                ]);

            /* ============================================================== 
               MESSAGES OF ONE CONVERSATION
            ============================================================== */
            case 'messages':

                $phone = trim((string)($_GET['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $stmt = $pdo->prepare(
                    "SELECT
                        c.id,
                        c.whatsapp_message_id,
                        c.customer_phone,
                        c.customer_name,
                        c.direction,
                        c.message_type,
                        c.message_text,
                        c.message_source,
                        c.status,
                        c.phone_number_id,
                        c.message_timestamp,
                        c.raw_payload,

                        c.has_referral,
                        c.reference_code,
                        c.product_code,
                        c.source_type,
                        c.source_platform,
                        c.content_title,
                        c.headline,
                        c.body AS ad_body,
                        c.media_type AS ref_media_type,
                        c.image_url,
                        c.video_url,
                        c.thumbnail_url,
                        c.source_id,
                        c.source_url,
                        c.ctwa_clid,
                        c.campaign_name,
                        c.ad_name,
                        c.creative_name

                    FROM whatsapp_conversation_messages c

                    WHERE c.customer_phone = :phone

                    ORDER BY c.message_timestamp ASC, c.id ASC
                    LIMIT 500"
                );

                $stmt->execute([':phone' => $phone]);

                jsonOut([
                    'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
                ]);

            /* ============================================================== 
               LATEST REFERRAL OF A CONVERSATION
            ============================================================== */
            case 'referral':

                $phone = trim((string)($_GET['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $stmt = $pdo->prepare(
                    "SELECT *
                     FROM whatsapp_conversation_messages
                     WHERE customer_phone = :phone
                       AND has_referral = 1
                     ORDER BY id DESC
                     LIMIT 1"
                );

                $stmt->execute([':phone' => $phone]);

                jsonOut([
                    'data' => $stmt->fetch(PDO::FETCH_ASSOC) ?: null
                ]);

            /* ==============================================================
               LEADS TABLE

               For call-status filtering the same storage rule is used here:
               - All       => lead/referral messages, with called status attached
               - Called    => whatsapp_customer_call_status is the source of truth
               - Not called=> lead/referral messages, excluding called customers
            ============================================================== */
            case 'leads':

                $limit = min(1000, max(10, (int)($_GET['limit'] ?? 500)));

                $params = [];
                $where = buildLeadFilters($filters, $params, 'm');

                switch ($filters['sort']) {
                    case 'oldest':
                        $order = 'COALESCE(m.received_at, m.message_timestamp) ASC, m.id ASC';
                        break;
                    case 'name':
                        $order = 'COALESCE(m.customer_name, m.customer_phone) ASC, m.id DESC';
                        break;
                    default:
                        $order = 'COALESCE(m.received_at, m.message_timestamp) DESC, m.id DESC';
                        break;
                }

                $sql = "\n                    SELECT\n                        m.id AS message_id,\n                        m.whatsapp_message_id,\n                        m.customer_phone,\n                        m.customer_name,\n                        m.direction,\n                        m.message_type,\n                        m.message_text,\n                        m.message_source,\n                        m.status AS message_status,\n                        m.phone_number_id,\n                        m.received_at,\n                        m.message_timestamp,\n                        m.reference_code,\n                        m.product_code,\n                        m.source_type,\n                        m.source_platform,\n                        m.content_title,\n                        m.headline,\n                        m.body,\n                        m.media_type,\n                        m.image_url,\n                        m.video_url,\n                        m.thumbnail_url,\n                        m.source_id,\n                        m.source_url,\n                        m.ctwa_clid,\n                        m.campaign_name,\n                        m.ad_name,\n                        m.creative_name,\n                        COALESCE(cs.call_status, 'not_called') AS call_status,\n                        cs.conversation_message_id,\n                        cs.called_at,\n                        COALESCE(cs.attempt_count, 0) AS attempt_count\n                    FROM whatsapp_conversation_messages m\n                    LEFT JOIN whatsapp_customer_call_status cs\n                        ON cs.conversation_message_id = m.id\n                ";

                if ($where) {
                    $sql .= ' WHERE ' . implode(' AND ', $where);
                }

                $sql .= " ORDER BY $order LIMIT $limit";

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($rows as &$row) {
                    $row['message_id'] = (int)($row['message_id'] ?? 0);
                    $row['conversation_message_id'] = $row['conversation_message_id'] !== null
                        ? (int)$row['conversation_message_id']
                        : null;
                    $row['attempt_count'] = (int)($row['attempt_count'] ?? 0);
                }
                unset($row);

                jsonOut(['data' => $rows]);

            /* ==============================================================
               REFERENCE ANALYSIS
            ============================================================== */
            case 'reference_analysis':

                $params = [];
                $where = buildLeadFilters($filters, $params);
                $where[] = "m.reference_code IS NOT NULL";
                $where[] = "m.reference_code <> ''";

                $whereSql = implode(' AND ', $where);

                $summaryStmt = $pdo->prepare("
                    SELECT
                        COUNT(*) AS referral_messages,
                        COUNT(DISTINCT m.customer_phone) AS unique_customers,
                        COUNT(DISTINCT m.reference_code) AS unique_references
                    FROM whatsapp_conversation_messages m
                    WHERE $whereSql
                ");

                $summaryStmt->execute($params);

                $summary = $summaryStmt->fetch(PDO::FETCH_ASSOC) ?: [
                    'referral_messages' => 0,
                    'unique_customers' => 0,
                    'unique_references' => 0,
                ];

                $refStmt = $pdo->prepare("
                    SELECT
                        m.reference_code,
                        COUNT(*) AS message_count,
                        COUNT(DISTINCT m.customer_phone) AS customer_count,
                        MAX(
                            COALESCE(m.received_at, m.message_timestamp)
                        ) AS last_seen,
                        GROUP_CONCAT(
                            DISTINCT NULLIF(m.product_code, '')
                            ORDER BY m.product_code
                            SEPARATOR ', '
                        ) AS products,
                        GROUP_CONCAT(
                            DISTINCT NULLIF(m.source_type, '')
                            ORDER BY m.source_type
                            SEPARATOR ', '
                        ) AS source_types,
                        GROUP_CONCAT(
                            DISTINCT NULLIF(m.source_platform, '')
                            ORDER BY m.source_platform
                            SEPARATOR ', '
                        ) AS platforms
                    FROM whatsapp_conversation_messages m
                    WHERE $whereSql
                    GROUP BY m.reference_code
                    ORDER BY message_count DESC, last_seen DESC
                    LIMIT 100
                ");

                $refStmt->execute($params);

                jsonOut([
                    'summary' => $summary,
                    'data' => $refStmt->fetchAll(PDO::FETCH_ASSOC),
                ]);

            /* ==============================================================
               CUSTOMER CALL TRACKING

               Data model:
               - whatsapp_conversation_messages = all WhatsApp customers/messages
               - whatsapp_customer_call_status  = called customers only
               - All       => every conversation customer + called status when available
               - Called    => read directly from whatsapp_customer_call_status
               - Not called=> read from conversations, excluding customers marked called
            ============================================================== */
            case 'call_tracking':

                $limit = min(500, max(10, (int)($_GET['limit'] ?? 500)));

                $params = [];
                $where = buildConversationFilters($filters, $params);
                $where[] = "COALESCE(cs.chat_bucket, 'inbox') = 'inbox'";

                $callState = $filters['call_status'] ?? '';
                if (in_array($callState, ['not_called', 'called', 'rejected', 'try_again'], true)) {
                    $where[] = "COALESCE(cs.call_status, 'not_called') = :tracking_call_state";
                    $params[':tracking_call_state'] = $callState;
                }

                $sql = "\n                    SELECT\n                        m.customer_phone,\n                        m.customer_name,\n                        m.message_timestamp AS last_message_at,\n                        m.message_text AS last_message_text,\n                        COALESCE(cs.call_status, 'not_called') AS call_status,\n                        COALESCE(cs.attempt_count, 0) AS attempt_count,\n                        cs.called_at,\n                        cs.updated_at AS call_status_updated_at,\n                        (\n                            SELECT COUNT(*)\n                            FROM whatsapp_conversation_messages c2\n                            WHERE c2.customer_phone = m.customer_phone\n                        ) AS total_messages\n                    FROM whatsapp_conversation_messages m\n                    INNER JOIN (\n                        SELECT customer_phone, MAX(id) AS max_id\n                        FROM whatsapp_conversation_messages\n                        WHERE customer_phone IS NOT NULL\n                          AND customer_phone <> ''\n                        GROUP BY customer_phone\n                    ) latest\n                        ON latest.max_id = m.id\n                    LEFT JOIN whatsapp_customer_call_status cs\n                        ON RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                         = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                       AND cs.id = (\n                            SELECT cs2.id\n                            FROM whatsapp_customer_call_status cs2\n                            WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs2.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                                = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(m.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                            ORDER BY cs2.updated_at DESC, cs2.id DESC\n                            LIMIT 1\n                       )
                ";

                if ($where) {
                    $sql .= ' WHERE ' . implode(' AND ', $where);
                }

                $sql .= ' ORDER BY m.id DESC LIMIT ' . $limit;

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                jsonOut(['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);

            /* ==============================================================
               READ CUSTOMER NORMAL-CALL STATUS
            ============================================================== */
            case 'call_status_read':

                $phone = trim((string)($_GET['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $stmt = $pdo->prepare("\n                    SELECT cs.customer_phone, cs.customer_name, cs.call_status, cs.attempt_count,\n                           cs.called_at, cs.chat_bucket, cs.conversation_message_id, cs.updated_at\n                    FROM whatsapp_customer_call_status cs\n                    INNER JOIN whatsapp_conversation_messages m ON m.id = cs.conversation_message_id\n                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(cs.customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                    ORDER BY m.id DESC, cs.updated_at DESC, cs.id DESC\n                    LIMIT 1\n                ");
                $stmt->execute([':phone' => $phone]);

                $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [
                    'customer_phone' => $phone,
                    'customer_name' => null,
                    'call_status' => 'not_called',
                    'attempt_count' => 0,
                    'called_at' => null,
                    'chat_bucket' => 'inbox',
                    'conversation_message_id' => null,
                    'updated_at' => null,
                ];

                $row['attempt_count'] = (int)($row['attempt_count'] ?? 0);
                jsonOut(['data' => $row]);

            /* ==============================================================\n               UPDATE CUSTOMER CALL STATE\n            ============================================================== */
            case 'call_status':

                requirePostCsrf();
                $payload = readJsonBody();

                $phone = trim((string)($payload['phone'] ?? ''));
                $status = trim((string)($payload['status'] ?? ''));
                $candidateMessageId = isset($payload['conversation_message_id'])
                    ? (int)$payload['conversation_message_id']
                    : 0;

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                if (!in_array($status, ['not_called', 'called', 'rejected', 'try_again'], true)) {
                    jsonOut(['error' => 'Invalid call state'], 400);
                }

                $normalizedPhone = normalizeWhatsAppPhone($phone);
                if ($normalizedPhone === '') {
                    jsonOut(['error' => 'Invalid phone number'], 400);
                }

                $nameStmt = $pdo->prepare("\n                    SELECT customer_name\n                    FROM whatsapp_conversation_messages\n                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                      AND customer_name IS NOT NULL\n                      AND customer_name <> ''\n                    ORDER BY id DESC\n                    LIMIT 1\n                ");
                $nameStmt->execute([':phone' => $normalizedPhone]);
                $customerName = $nameStmt->fetchColumn() ?: null;

                $relatedMessageId = resolveRelatedConversationMessageId(
                    $pdo,
                    $normalizedPhone,
                    $candidateMessageId > 0 ? $candidateMessageId : null
                );
                if ($relatedMessageId === null) {
                    jsonOut(['error' => 'No related conversation message found for this customer.'], 400);
                }

                $tz = new DateTimeZone('Asia/Colombo');
                $now = (new DateTimeImmutable('now', $tz))->format('Y-m-d H:i:s');
                $pdo->beginTransaction();
                try {
                    $find = $pdo->prepare("SELECT id FROM whatsapp_customer_call_status WHERE conversation_message_id=:message_id LIMIT 1 FOR UPDATE");
                    $find->execute([':message_id' => $relatedMessageId]);
                    $existingId = $find->fetchColumn();

                    if ($existingId !== false) {
                        $up = $pdo->prepare("UPDATE whatsapp_customer_call_status
                            SET customer_phone = :upd_phone,
                                customer_name = COALESCE(:upd_name, customer_name),
                                call_status = :upd_status,
                                attempt_count = GREATEST(attempt_count, :upd_min_attempts),
                                called_at = CASE
                                    WHEN :upd_status_case = 'not_called' THEN called_at
                                    WHEN called_at IS NULL THEN :upd_called_at
                                    ELSE called_at
                                END,
                                updated_at = CURRENT_TIMESTAMP
                            WHERE id = :upd_id");
                        $up->execute([
                            ':upd_phone' => $normalizedPhone,
                            ':upd_name' => $customerName,
                            ':upd_status' => $status,
                            ':upd_min_attempts' => ($status === 'not_called' ? 0 : 1),
                            ':upd_status_case' => $status,
                            ':upd_called_at' => $now,
                            ':upd_id' => (int)$existingId,
                        ]);
                    } else {
                        $ins = $pdo->prepare("INSERT INTO whatsapp_customer_call_status
                            (customer_phone,customer_name,conversation_message_id,call_status,attempt_count,called_at,chat_bucket)
                            VALUES(:phone,:name,:message_id,:status,:attempt_count,:called_at,'inbox')");
                        $ins->execute([
                            ':phone'=>$normalizedPhone,
                            ':name'=>$customerName,
                            ':message_id'=>$relatedMessageId,
                            ':status'=>$status,
                            ':attempt_count'=>$status==='not_called'?0:1,
                            ':called_at'=>$status==='not_called'?null:$now,
                        ]);
                    }
                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    throw $e;
                }

                $readStmt = $pdo->prepare("SELECT customer_phone,customer_name,call_status,attempt_count,called_at,chat_bucket,conversation_message_id,updated_at
                    FROM whatsapp_customer_call_status
                    WHERE conversation_message_id=:message_id
                    ORDER BY id DESC LIMIT 1");
                $readStmt->execute([':message_id'=>$relatedMessageId]);
                $result = $readStmt->fetch(PDO::FETCH_ASSOC);
                if (!$result) jsonOut(['error'=>'Call status could not be read after update.'],500);
                $result['attempt_count']=(int)($result['attempt_count']??0);
                $result['conversation_message_id']=$result['conversation_message_id']!==null?(int)$result['conversation_message_id']:null;
                jsonOut(['ok'=>true,'data'=>$result]);

            case 'call_attempt':

                requirePostCsrf();
                $payload = readJsonBody();

                $phone = trim((string)($payload['phone'] ?? ''));
                $candidateMessageId = isset($payload['conversation_message_id'])
                    ? (int)$payload['conversation_message_id']
                    : 0;

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $normalizedPhone = normalizeWhatsAppPhone($phone);
                if ($normalizedPhone === '') {
                    jsonOut(['error' => 'Invalid phone number'], 400);
                }

                $nameStmt = $pdo->prepare("\n                    SELECT customer_name\n                    FROM whatsapp_conversation_messages\n                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)\n                      AND customer_name IS NOT NULL\n                      AND customer_name <> ''\n                    ORDER BY id DESC\n                    LIMIT 1\n                ");
                $nameStmt->execute([':phone' => $normalizedPhone]);
                $customerName = $nameStmt->fetchColumn() ?: null;

                $relatedMessageId = resolveRelatedConversationMessageId(
                    $pdo,
                    $normalizedPhone,
                    $candidateMessageId > 0 ? $candidateMessageId : null
                );
                if ($relatedMessageId === null) {
                    jsonOut(['error' => 'No related conversation message found for this customer.'], 400);
                }

                $tz = new DateTimeZone('Asia/Colombo');
                $now = (new DateTimeImmutable('now', $tz))->format('Y-m-d H:i:s');
                $pdo->beginTransaction();
                try {
                    $find = $pdo->prepare("SELECT id FROM whatsapp_customer_call_status WHERE conversation_message_id=:message_id LIMIT 1 FOR UPDATE");
                    $find->execute([':message_id'=>$relatedMessageId]);
                    $existingId = $find->fetchColumn();

                    if ($existingId !== false) {
                        $up = $pdo->prepare("UPDATE whatsapp_customer_call_status
                            SET customer_phone=:phone,
                                customer_name=COALESCE(:name,customer_name),
                                attempt_count=attempt_count+1,
                                call_status=CASE WHEN call_status='not_called' THEN 'called' ELSE call_status END,
                                called_at=:called_at,
                                updated_at=CURRENT_TIMESTAMP
                            WHERE id=:id");
                        $up->execute([
                            ':phone'=>$normalizedPhone,
                            ':name'=>$customerName,
                            ':called_at'=>$now,
                            ':id'=>(int)$existingId,
                        ]);
                    } else {
                        $ins = $pdo->prepare("INSERT INTO whatsapp_customer_call_status
                            (customer_phone,customer_name,conversation_message_id,call_status,attempt_count,called_at,chat_bucket)
                            VALUES(:phone,:name,:message_id,'called',1,:called_at,'inbox')");
                        $ins->execute([
                            ':phone'=>$normalizedPhone,
                            ':name'=>$customerName,
                            ':message_id'=>$relatedMessageId,
                            ':called_at'=>$now,
                        ]);
                    }
                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    throw $e;
                }

                $readStmt = $pdo->prepare("SELECT customer_phone,customer_name,call_status,attempt_count,called_at,chat_bucket,conversation_message_id,updated_at
                    FROM whatsapp_customer_call_status
                    WHERE conversation_message_id=:message_id
                    ORDER BY id DESC LIMIT 1");
                $readStmt->execute([':message_id'=>$relatedMessageId]);
                $result = $readStmt->fetch(PDO::FETCH_ASSOC);
                if (!$result) jsonOut(['error'=>'Attempt could not be read after update.'],500);
                $result['attempt_count']=(int)($result['attempt_count']??0);
                $result['conversation_message_id']=$result['conversation_message_id']!==null?(int)$result['conversation_message_id']:null;
                jsonOut(['ok'=>true,'data'=>$result]);

            case 'move_chats':

                requirePostCsrf();
                $payload = readJsonBody();
                $phones = $payload['phones'] ?? [];
                $bucket = trim((string)($payload['bucket'] ?? ''));

                if (!is_array($phones) || !$phones) {
                    jsonOut(['error' => 'No chats selected'], 400);
                }

                if (!in_array($bucket, ['inbox', 'pending', 'old'], true)) {
                    jsonOut(['error' => 'Invalid destination'], 400);
                }

                $phones = array_values(array_unique(array_filter(
                    array_map(static fn($v) => normalizeWhatsAppPhone((string)$v), $phones),
                    static fn($v) => $v !== ''
                )));

                if (!$phones) {
                    jsonOut(['error' => 'No valid phone numbers'], 400);
                }

                if (count($phones) > 200) {
                    jsonOut(['error' => 'You can move up to 200 chats at once.'], 400);
                }

                $nameStmt = $pdo->prepare(<<<'SQL'
                    SELECT customer_name
                    FROM whatsapp_conversation_messages
                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                      AND customer_name IS NOT NULL
                      AND customer_name <> ''
                    ORDER BY id DESC
                    LIMIT 1
                SQL);

                $updateBucket = $pdo->prepare(<<<'SQL'
                    UPDATE whatsapp_customer_call_status
                    SET chat_bucket = :bucket,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                SQL);

                $insertBucket = $pdo->prepare(<<<'SQL'
                    INSERT INTO whatsapp_customer_call_status
                        (customer_phone, customer_name, conversation_message_id, call_status, attempt_count, chat_bucket)
                    VALUES
                        (:phone, :name, :message_id, 'not_called', 0, :bucket)
                SQL);

                $pdo->beginTransaction();
                try {
                    foreach ($phones as $phone) {
                        $nameStmt->execute([':phone' => $phone]);
                        $name = $nameStmt->fetchColumn() ?: null;

                        $updateBucket->execute([
                            ':bucket' => $bucket,
                            ':phone' => $phone,
                        ]);

                        if ($updateBucket->rowCount() === 0) {
                            $messageId = resolveRelatedConversationMessageId($pdo, $phone);
                            if ($messageId !== null) {
                                $insertBucket->execute([
                                    ':phone' => normalizeWhatsAppPhone($phone),
                                    ':name' => $name,
                                    ':message_id' => $messageId,
                                    ':bucket' => $bucket,
                                ]);
                            }
                        }
                    }
                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    throw $e;
                }

                jsonOut([
                    'ok' => true,
                    'bucket' => $bucket,
                    'moved' => count($phones),
                ]);

            /* ==============================================================
               DELETE ONE CHAT
            ============================================================== */

                requirePostCsrf();
                $payload = readJsonBody();

                $phone = trim((string)($payload['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(
                        ['error' => 'phone is required'],
                        400
                    );
                }

                $stmt = $pdo->prepare("
                    DELETE FROM whatsapp_conversation_messages
                    WHERE customer_phone = :phone
                ");

                $stmt->execute([
                    ':phone' => $phone,
                ]);

                $statusStmt = $pdo->prepare("
                    DELETE FROM whatsapp_customer_call_status
                    WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                        = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                ");
                $statusStmt->execute([':phone' => $phone]);

                jsonOut([
                    'ok' => true,
                    'phone' => $phone,
                    'deleted_rows' => $stmt->rowCount(),
                ]);

            /* ==============================================================
               DELETE SINGLE CHAT
            ============================================================== */
            case 'delete_chat':

                requirePostCsrf();
                $payload = readJsonBody();

                $phone = trim((string)($payload['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $stmt = $pdo->prepare(
                    "DELETE FROM whatsapp_conversation_messages
                     WHERE customer_phone = :phone"
                );
                $stmt->execute([':phone' => $phone]);

                $statusStmt = $pdo->prepare(
                    "DELETE FROM whatsapp_customer_call_status
                     WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)
                     = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)"
                );
                $statusStmt->execute([':phone' => $phone]);

                jsonOut([
                    'ok' => true,
                    'phone' => $phone,
                    'deleted_rows' => $stmt->rowCount(),
                ]);

            /* ==============================================================
               DELETE MULTIPLE CHATS
            ============================================================== */
            case 'delete_chats':

                requirePostCsrf();
                $payload = readJsonBody();

                $phones = $payload['phones'] ?? [];

                if (!is_array($phones)) {
                    jsonOut(
                        ['error' => 'phones must be an array'],
                        400
                    );
                }

                $phones = array_values(array_unique(array_filter(
                    array_map(
                        static fn($v) => trim((string)$v),
                        $phones
                    ),
                    static fn($v) => $v !== ''
                )));

                if (!$phones) {
                    jsonOut(
                        ['error' => 'No chats selected'],
                        400
                    );
                }

                if (count($phones) > 100) {
                    jsonOut(
                        ['error' => 'You can delete up to 100 chats at once.'],
                        400
                    );
                }

                $placeholders = [];
                $params = [];

                foreach ($phones as $i => $phone) {
                    $key = ':p' . $i;
                    $placeholders[] = $key;
                    $params[$key] = $phone;
                }

                $stmt = $pdo->prepare(
                    "DELETE FROM whatsapp_conversation_messages
                     WHERE customer_phone IN (" .
                    implode(',', $placeholders) .
                    ")"
                );

                $stmt->execute($params);

                $statusConditions = [];
                $statusParams = [];
                foreach ($phones as $i => $phone) {
                    $key = ':sp' . $i;
                    $statusConditions[] = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(customer_phone, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9) = RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE($key, '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 9)";
                    $statusParams[$key] = $phone;
                }

                $statusStmt = $pdo->prepare(
                    "DELETE FROM whatsapp_customer_call_status WHERE " . implode(' OR ', $statusConditions)
                );
                $statusStmt->execute($statusParams);

                jsonOut([
                    'ok' => true,
                    'requested_chats' => count($phones),
                    'deleted_rows' => $stmt->rowCount(),
                ]);

            /* ==============================================================
               AUTO REPLY TO NEW CONTACTS
            ============================================================== */
            case 'auto_reply_new_contacts':

                requirePostCsrf();
                jsonOut(autoReplyNewContacts($pdo));

            /* ==============================================================
               SEND ONE TEXT MESSAGE
            ============================================================== */
            case 'send_text':

                requirePostCsrf();
                $payload = readJsonBody();

                $phone = trim((string)($payload['phone'] ?? ''));
                $text = trim((string)($payload['message'] ?? ''));

                if ($phone === '') {
                    jsonOut(
                        ['error' => 'phone is required'],
                        400
                    );
                }

                if ($text === '') {
                    jsonOut(
                        ['error' => 'message is required'],
                        400
                    );
                }

                $nameStmt = $pdo->prepare("
                    SELECT customer_name
                    FROM whatsapp_conversation_messages
                    WHERE customer_phone = :phone
                      AND customer_name IS NOT NULL
                      AND customer_name <> ''
                    ORDER BY id DESC
                    LIMIT 1
                ");

                $nameStmt->execute([
                    ':phone' => $phone,
                ]);

                $customerName =
                    $nameStmt->fetchColumn() ?: null;

                $result = sendWhatsAppText(
                    $pdo,
                    $phone,
                    $text,
                    $customerName
                );

                jsonOut([
                    'ok' => true,
                    'data' => $result,
                ]);

            /* ==============================================================
               SEND SAME TEXT TO MULTIPLE CHATS
            ============================================================== */
            case 'bulk_send_text':

                requirePostCsrf();
                $payload = readJsonBody();

                $phones = $payload['phones'] ?? [];
                $text = trim((string)($payload['message'] ?? ''));

                if (!is_array($phones)) {
                    jsonOut(
                        ['error' => 'phones must be an array'],
                        400
                    );
                }

                $phones = array_values(array_unique(array_filter(
                    array_map(
                        static fn($v) => trim((string)$v),
                        $phones
                    ),
                    static fn($v) => $v !== ''
                )));

                if (!$phones) {
                    jsonOut(
                        ['error' => 'No chats selected'],
                        400
                    );
                }

                if (count($phones) > 50) {
                    jsonOut(
                        ['error' => 'Bulk send is limited to 50 chats per action.'],
                        400
                    );
                }

                if ($text === '') {
                    jsonOut(
                        ['error' => 'message is required'],
                        400
                    );
                }

                $success = [];
                $failed = [];

                foreach ($phones as $phone) {

                    try {

                        $nameStmt = $pdo->prepare("
                            SELECT customer_name
                            FROM whatsapp_conversation_messages
                            WHERE customer_phone = :phone
                              AND customer_name IS NOT NULL
                              AND customer_name <> ''
                            ORDER BY id DESC
                            LIMIT 1
                        ");

                        $nameStmt->execute([
                            ':phone' => $phone,
                        ]);

                        $customerName =
                            $nameStmt->fetchColumn() ?: null;

                        $result = sendWhatsAppText(
                            $pdo,
                            $phone,
                            $text,
                            $customerName
                        );

                        $success[] = $result;

                        usleep(150000);

                    } catch (Throwable $e) {

                        $failed[] = [
                            'phone' => $phone,
                            'error' => $e->getMessage(),
                        ];
                    }
                }

                jsonOut([
                    'ok' => count($failed) === 0,
                    'sent_count' => count($success),
                    'failed_count' => count($failed),
                    'sent' => $success,
                    'failed' => $failed,
                ]);

            default:
                jsonOut(['error' => 'Unknown action'], 404);
        }

    } catch (Throwable $e) {
        jsonOut(['error' => $e->getMessage()], 500);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WhatsApp Inbox</title>
<meta name="theme-color" content="#25d366">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="manifest" href="?action=manifest">

<style>
:root{
    --bg:#eef2f6;
    --panel:#ffffff;
    --border:#e2e8f0;
    --text:#0f172a;
    --muted:#64748b;
    --green:#25d366;
    --green-dark:#128c7e;
    --green-soft:#dcf8c6;
    --blue:#2563eb;
    --amber:#d97706;
    --purple:#7c3aed;
    --red:#dc2626;
    --shadow:0 1px 2px rgba(15,23,42,.06),0 8px 24px -12px rgba(15,23,42,.18);
    --radius:14px;
}

*{box-sizing:border-box;}
html,body{height:100%;}

body{
    margin:0;
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
    background:var(--bg);
    color:var(--text);
    font-size:14px;
    -webkit-font-smoothing:antialiased;
}

button,input,select{font-family:inherit;font-size:inherit;}

.topbar{
    display:flex;
    align-items:center;
    gap:16px;
    flex-wrap:wrap;
    padding:12px 20px;
    background:var(--panel);
    border-bottom:1px solid var(--border);
    position:sticky;
    top:0;
    z-index:20;
}

.brand{
    display:flex;
    align-items:center;
    gap:10px;
    font-weight:700;
    font-size:16px;
    white-space:nowrap;
}

.brand .dot{
    width:32px;
    height:32px;
    border-radius:10px;
    background:linear-gradient(135deg,var(--green),var(--green-dark));
    display:grid;
    place-items:center;
    color:#fff;
    font-size:16px;
}

.tabs{
    display:flex;
    gap:4px;
    background:#f1f5f9;
    padding:4px;
    border-radius:10px;
}

.tab{
    border:0;
    background:transparent;
    color:var(--muted);
    padding:7px 16px;
    border-radius:7px;
    cursor:pointer;
    font-weight:600;
    transition:.15s;
}

.tab:hover{color:var(--text);}
.tab.active{background:#fff;color:var(--text);box-shadow:0 1px 3px rgba(15,23,42,.1);}

.stats{display:flex;gap:8px;margin-left:auto;flex-wrap:wrap;}

.stat{
    background:#f8fafc;
    border:1px solid var(--border);
    border-radius:10px;
    padding:6px 12px;
    line-height:1.2;
    min-width:78px;
}

.stat b{display:block;font-size:16px;}
.stat span{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;}

.toolbar{display:flex;gap:8px;align-items:center;}

.auto-btn{
    border:1px solid var(--border);
    background:#fff;
    border-radius:10px;
    padding:7px 12px;
    cursor:pointer;
    font-weight:600;
    color:var(--muted);
    display:flex;
    align-items:center;
    gap:7px;
    transition:.15s;
}

.auto-btn.on{color:var(--green-dark);border-color:#a7f3d0;background:#ecfdf5;}
.auto-btn .pulse{width:8px;height:8px;border-radius:50%;background:#cbd5e1;}
.auto-btn.on .pulse{background:var(--green);animation:pulse 1.6s infinite;}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.25}}

.wrap{padding:16px;height:calc(100vh - 63px);}

.grid{
    display:grid;
    grid-template-columns:340px minmax(0,1fr) 350px;
    gap:16px;
    height:100%;
}

.panel{
    background:var(--panel);
    border:1px solid var(--border);
    border-radius:var(--radius);
    box-shadow:var(--shadow);
    display:flex;
    flex-direction:column;
    overflow:hidden;
    min-height:0;
}

.panel-head{
    padding:12px 14px;
    border-bottom:1px solid var(--border);
    display:flex;
    align-items:center;
    gap:10px;
    flex-shrink:0;
}

.panel-head h2{
    margin:0;
    font-size:13px;
    text-transform:uppercase;
    letter-spacing:.6px;
    color:var(--muted);
}

.panel-body{overflow-y:auto;flex:1;min-height:0;}
.panel-body::-webkit-scrollbar{width:8px;}
.panel-body::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:8px;}
.panel-body::-webkit-scrollbar-track{background:transparent;}

.filters{
    padding:10px 12px;
    border-bottom:1px solid var(--border);
    display:flex;
    flex-direction:column;
    gap:8px;
    flex-shrink:0;
    background:#fbfcfd;
}

.filter-row{display:flex;gap:8px;}
.filter-row > *{flex:1;min-width:0;}

.input,.select{
    width:100%;
    padding:8px 10px;
    border:1px solid var(--border);
    border-radius:9px;
    background:#fff;
    outline:none;
    transition:.15s;
    font-size:13px;
}

.input:focus,.select:focus{
    border-color:var(--green);
    box-shadow:0 0 0 3px rgba(37,211,102,.15);
}

.input[type="date"]{padding:7px 10px;}
.select{cursor:pointer;}

.filter-toggle{
    display:flex;
    align-items:center;
    gap:7px;
    border:1px dashed #cbd5e1;
    background:#fff;
    color:var(--muted);
    border-radius:9px;
    padding:7px 10px;
    cursor:pointer;
    font-weight:600;
    font-size:12px;
    transition:.15s;
    justify-content:center;
}

.filter-toggle:hover{border-color:var(--green);color:var(--green-dark);}
.filter-toggle.active{border-style:solid;border-color:var(--green);background:#ecfdf5;color:var(--green-dark);}

.filter-toggle .cnt{
    background:var(--green);
    color:#fff;
    font-size:10px;
    padding:1px 6px;
    border-radius:10px;
    font-weight:700;
    min-width:16px;
    text-align:center;
}

.adv-filters{
    display:flex;
    flex-direction:column;
    gap:8px;
    padding-top:8px;
    border-top:1px dashed var(--border);
    animation:slideDown .18s ease-out;
}

@keyframes slideDown{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}

.adv-label{
    font-size:10.5px;
    color:var(--muted);
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.5px;
    margin-bottom:-3px;
}

.chips{display:flex;flex-wrap:wrap;gap:5px;padding-top:4px;}

.chip{
    display:inline-flex;
    align-items:center;
    gap:5px;
    background:#e0f2fe;
    color:#0369a1;
    font-size:11px;
    padding:3px 8px;
    border-radius:20px;
    font-weight:600;
}

.chip button{
    border:0;
    background:transparent;
    color:inherit;
    cursor:pointer;
    font-weight:900;
    padding:0;
    line-height:1;
    font-size:13px;
}

.chip.clear-all{background:#fee2e2;color:#b91c1c;cursor:pointer;}

.conv{
    display:flex;
    gap:11px;
    padding:12px 14px;
    border-bottom:1px solid #f1f5f9;
    cursor:pointer;
    transition:.12s;
}

.conv:hover{background:#f8fafc;}
.conv.active{background:#ecfdf5;box-shadow:inset 3px 0 0 var(--green);}

.avatar{
    width:42px;
    height:42px;
    border-radius:50%;
    flex-shrink:0;
    display:grid;
    place-items:center;
    font-weight:700;
    color:#fff;
    font-size:15px;
    background:linear-gradient(135deg,#94a3b8,#64748b);
}

.avatar.a1{background:linear-gradient(135deg,#34d399,#059669);}
.avatar.a2{background:linear-gradient(135deg,#60a5fa,#2563eb);}
.avatar.a3{background:linear-gradient(135deg,#fbbf24,#d97706);}
.avatar.a4{background:linear-gradient(135deg,#a78bfa,#7c3aed);}
.avatar.a5{background:linear-gradient(135deg,#f472b6,#db2777);}

.conv-main{flex:1;min-width:0;}
.conv-top{display:flex;justify-content:space-between;gap:8px;align-items:baseline;}
.conv-name{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.conv-time{font-size:11px;color:var(--muted);white-space:nowrap;flex-shrink:0;}
.conv-preview{font-size:12.5px;color:var(--muted);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.conv-badges{display:flex;gap:6px;margin-top:7px;flex-wrap:wrap;align-items:center;}

.badge{font-size:10.5px;font-weight:700;padding:2.5px 8px;border-radius:20px;letter-spacing:.3px;white-space:nowrap;}
.badge.gray{background:#f1f5f9;color:#475569;}
.badge.green{background:#dcfce7;color:#15803d;}
.badge.blue{background:#dbeafe;color:#1d4ed8;}
.badge.amber{background:#fef3c7;color:#b45309;}
.badge.purple{background:#ede9fe;color:#6d28d9;}
.badge.red{background:#fee2e2;color:#b91c1c;}
.badge.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10px;}

.count-pill{font-size:10.5px;background:#f1f5f9;color:#64748b;padding:2px 7px;border-radius:20px;font-weight:600;}

.chat-head{
    padding:12px 18px;
    border-bottom:1px solid var(--border);
    display:flex;
    align-items:center;
    gap:12px;
    flex-shrink:0;
    background:#fff;
}

.chat-head .name{font-weight:700;font-size:15px;}
.chat-head .sub{font-size:12px;color:var(--muted);margin-top:1px;}

.thread{
    flex:1;
    overflow-y:auto;
    min-height:0;
    padding:22px 24px;
    background:radial-gradient(circle at 1px 1px,#e2e8f0 1px,transparent 0) 0 0/22px 22px,#f7f9fb;
    display:flex;
    flex-direction:column;
    gap:12px;
}

.msg{display:flex;max-width:100%;}
.msg.incoming{justify-content:flex-start;}
.msg.outgoing{justify-content:flex-end;}

.bubble{
    max-width:min(560px,78%);
    border-radius:14px;
    padding:9px 12px 7px;
    box-shadow:0 1px 1px rgba(15,23,42,.08);
    word-wrap:break-word;
    overflow-wrap:anywhere;
}

.msg.incoming .bubble{background:#fff;border-top-left-radius:4px;}
.msg.outgoing .bubble{background:var(--green-soft);border-top-right-radius:4px;}
.bubble .txt{font-size:14px;line-height:1.45;white-space:pre-wrap;}
.bubble .meta{display:flex;justify-content:flex-end;gap:6px;align-items:center;font-size:10.5px;color:#64748b;margin-top:4px;}
.tick{font-size:11px;}
.tick.read{color:var(--blue);}

.ad-card{
    margin-top:9px;
    border:1px solid #cbd5e1;
    border-radius:11px;
    overflow:hidden;
    background:#f8fafc;
    max-width:330px;
}

.ad-card .ad-top{
    padding:7px 11px;
    font-size:10.5px;
    font-weight:700;
    letter-spacing:.6px;
    text-transform:uppercase;
    color:#475569;
    background:#e2e8f0;
    display:flex;
    align-items:center;
    gap:6px;
}

.ad-card .ad-img{width:100%;display:block;max-height:190px;object-fit:cover;background:#e2e8f0;}
.ad-card .ad-body{padding:10px 12px;font-size:12.5px;color:#334155;line-height:1.5;}
.ad-card .ad-title{font-weight:700;color:var(--text);margin-bottom:3px;}

.ad-card .ref-chip{
    display:inline-block;
    margin-top:7px;
    font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
    font-size:11px;
    background:#0f172a;
    color:#a7f3d0;
    padding:3px 9px;
    border-radius:6px;
    letter-spacing:.4px;
}

.section{padding:14px 16px;border-bottom:1px solid #f1f5f9;}
.section:last-child{border-bottom:0;}
.section h3{margin:0 0 10px;font-size:11px;text-transform:uppercase;letter-spacing:.7px;color:var(--muted);font-weight:700;}

.kv{display:flex;justify-content:space-between;gap:12px;padding:6px 0;font-size:12.5px;}
.kv .k{color:var(--muted);flex-shrink:0;}
.kv .v{font-weight:600;text-align:right;word-break:break-word;}
.kv .v.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;font-weight:500;}
.kv .v a{color:var(--blue);text-decoration:none;}
.kv .v a:hover{text-decoration:underline;}

.empty{padding:44px 24px;text-align:center;color:var(--muted);font-size:13px;}
.empty .big{font-size:34px;margin-bottom:10px;opacity:.35;}

.panel-sub{color:var(--muted);font-size:11px;margin-top:3px;line-height:1.35;}
.chat-call-controls{
    display:flex;
    align-items:center;
    justify-content:flex-end;
    gap:7px;
    margin-left:auto;
    padding:4px 0;
    flex-wrap:wrap;
    min-width:0;
}

.chat-call-controls > *{
    flex:0 0 auto;
}

.call-attempt-btn{
    border:1px solid #cbd5e1;
    background:#fff;
    color:#334155;
    border-radius:8px;
    padding:6px 10px;
    cursor:pointer;
    font-size:11.5px;
    font-weight:800;
    white-space:nowrap;
    transition:background .15s,border-color .15s,box-shadow .15s,transform .15s;
}

.call-attempt-btn:hover:not(:disabled){
    background:#f8fafc;
    border-color:#94a3b8;
    box-shadow:0 1px 2px rgba(15,23,42,.06);
}

.call-attempt-btn:active:not(:disabled){
    transform:translateY(1px);
}

.call-attempt-btn:disabled{
    opacity:.45;
    cursor:not-allowed;
}

.call-status-select{
    min-width:136px;
    border:1px solid var(--border);
    background:#fff;
    color:#334155;
    border-radius:8px;
    padding:6px 9px;
    cursor:pointer;
    outline:none;
    font-size:11.5px;
    font-weight:800;
    transition:border-color .15s,box-shadow .15s,background .15s,color .15s;
}

.call-status-select:focus{
    border-color:var(--green);
    box-shadow:0 0 0 3px rgba(37,211,102,.15);
}

.call-status-select:disabled{
    opacity:.5;
    cursor:not-allowed;
}

.call-status-select.called{
    border-color:#86efac;
    background:#ecfdf5;
    color:#15803d;
}

.call-status-select.rejected{
    border-color:#fecaca;
    background:#fef2f2;
    color:#b91c1c;
}

.call-status-select.try_again{
    border-color:#bfdbfe;
    background:#eff6ff;
    color:#1d4ed8;
}

.call-last{
    display:inline-flex;
    align-items:center;
    min-height:28px;
    padding:0 7px;
    border:1px solid #e2e8f0;
    border-radius:7px;
    background:#f8fafc;
    color:var(--muted);
    font-size:10.5px;
    line-height:1.2;
    white-space:nowrap;
}
.call-status-badge{font-size:10.5px;font-weight:800;padding:2.5px 8px;border-radius:20px;white-space:nowrap;}
.call-status-badge.not-called{background:#fef3c7;color:#b45309;}
.call-status-badge.called{background:#dcfce7;color:#15803d;}
.call-status-badge.rejected{background:#fee2e2;color:#b91c1c;}
.call-status-badge.try-again{background:#dbeafe;color:#1d4ed8;}
.call-tracking-panel{margin-top:16px;min-height:260px;max-height:520px;}
.call-tracking-head{justify-content:space-between;}
.call-tracking-body{overflow:auto;}
.call-tracking-table{width:100%;border-collapse:collapse;font-size:12px;}
.call-tracking-table th{position:sticky;top:0;z-index:2;background:#f8fafc;color:var(--muted);text-align:left;padding:10px 12px;font-size:10.5px;text-transform:uppercase;letter-spacing:.45px;border-bottom:1px solid var(--border);white-space:nowrap;}
.call-tracking-table td{padding:10px 12px;border-bottom:1px solid #f1f5f9;vertical-align:middle;}
.call-tracking-table tr:hover td{background:#f8fafc;}
.call-customer{display:flex;align-items:center;gap:9px;min-width:190px;}
.call-customer .avatar{width:32px;height:32px;font-size:11px;}
.call-customer-name{font-weight:700;max-width:230px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.call-customer-phone{color:var(--muted);font-size:10.5px;margin-top:2px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;}
.call-message{max-width:320px;color:#475569;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.call-actions{display:flex;align-items:center;gap:6px;flex-wrap:wrap;}
.call-action-btn{border:1px solid var(--border);background:#fff;color:#475569;border-radius:8px;padding:5px 9px;cursor:pointer;font-size:11px;font-weight:800;white-space:nowrap;text-decoration:none;display:inline-flex;align-items:center;}
.call-action-btn:hover:not(:disabled){border-color:#94a3b8;background:#f8fafc;}
.call-action-btn.active-called{border-color:#86efac;background:#ecfdf5;color:#15803d;}
.call-action-btn.active-uncalled{border-color:#fde68a;background:#fffbeb;color:#b45309;}
.call-action-btn:disabled{opacity:.5;cursor:not-allowed;}

.attempt-btn{
    gap:5px;
}
.attempt-count-mini{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    min-width:17px;
    height:17px;
    padding:0 4px;
    border-radius:999px;
    background:#eff6ff;
    color:#1d4ed8;
    font-size:10px;
    font-weight:900;
    line-height:1;
    border:1px solid #bfdbfe;
}
.lead-attempt-cell{
    display:flex;
    align-items:center;
    gap:6px;
    white-space:nowrap;
}
.lead-attempt-badge{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    min-width:25px;
    height:25px;
    padding:0 7px;
    border-radius:999px;
    background:#eff6ff;
    color:#1d4ed8;
    border:1px solid #bfdbfe;
    font-size:11px;
    font-weight:900;
}
.call-stats-row{display:flex;flex-wrap:wrap;gap:7px;padding:10px 12px;border-bottom:1px solid var(--border);background:#fbfcfd;}
.call-mini-stat{border:1px solid var(--border);border-radius:9px;padding:7px 10px;background:#fff;}
.call-mini-stat b{font-size:15px;}
.call-mini-stat span{margin-left:5px;font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:.35px;}

details.raw{margin-top:8px;}
details.raw summary{cursor:pointer;font-size:11.5px;color:var(--muted);font-weight:600;list-style:none;}
details.raw summary::-webkit-details-marker{display:none;}
details.raw summary::before{content:"▸ ";}
details.raw[open] summary::before{content:"▾ ";}

pre.rawbox{
    background:#0f172a;
    color:#a7f3d0;
    padding:12px;
    border-radius:10px;
    font-size:11px;
    overflow-x:auto;
    margin-top:8px;
    max-height:280px;
    font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
    line-height:1.5;
}

.leads-wrap{padding:0;height:100%;overflow:auto;}
table.leads{width:100%;border-collapse:collapse;font-size:12.5px;}

table.leads th{
    position:sticky;
    top:0;
    background:#f8fafc;
    text-align:left;
    padding:11px 14px;
    font-size:11px;
    text-transform:uppercase;
    letter-spacing:.5px;
    color:var(--muted);
    border-bottom:1px solid var(--border);
    z-index:2;
    white-space:nowrap;
}

table.leads td{padding:10px 14px;border-bottom:1px solid #f1f5f9;vertical-align:top;}
table.leads tr:hover td{background:#f8fafc;}

.leads-filters{
    padding:12px 16px;
    background:#fbfcfd;
    border-bottom:1px solid var(--border);
    display:flex;
    flex-direction:column;
    gap:8px;
    position:sticky;
    top:0;
    z-index:3;
}

.leads-filter-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px;}
.hidden{display:none !important;}
.spinner{display:inline-block;width:14px;height:14px;border:2px solid #cbd5e1;border-top-color:var(--green);border-radius:50%;animation:spin .7s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}

/* ===================== ACTIONS / COMPOSER ===================== */
.head-actions{
    margin-left:auto;
    display:flex;
    align-items:center;
    gap:6px;
    flex-wrap:wrap;
}

.mini-btn{
    border:1px solid var(--border);
    background:#fff;
    color:#475569;
    border-radius:8px;
    padding:5px 9px;
    cursor:pointer;
    font-size:11.5px;
    font-weight:700;
    transition:.15s;
    white-space:nowrap;
}

.mini-btn:hover:not(:disabled){
    border-color:#94a3b8;
    color:var(--text);
    background:#f8fafc;
}

.mini-btn.danger{
    color:#b91c1c;
}

.mini-btn.danger:hover:not(:disabled){
    border-color:#fecaca;
    background:#fef2f2;
}

.mini-btn:disabled{
    opacity:.45;
    cursor:not-allowed;
}

.conv-select{
    width:20px;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
}

.conv-check{
    width:15px;
    height:15px;
    accent-color:var(--green-dark);
    cursor:pointer;
}

.chat-head-main{
    flex:1;
    min-width:0;
}

.chat-actions{
    margin-left:auto;
    display:flex;
    align-items:center;
    gap:6px;
}

.composer{
    border-top:1px solid var(--border);
    background:#fff;
    padding:10px 14px;
    flex-shrink:0;
}

.composer-top{
    display:flex;
    justify-content:space-between;
    gap:8px;
    margin-bottom:6px;
    align-items:center;
}

.composer-label{
    font-size:11px;
    text-transform:uppercase;
    letter-spacing:.5px;
    font-weight:800;
    color:var(--muted);
}

.composer-target{
    font-size:11px;
    color:var(--muted);
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
    max-width:55%;
}

.quick-reply-row{
    display:flex;
    align-items:center;
    gap:7px;
    margin:7px 0 8px;
}

.quick-reply-select{
    flex:1;
    min-width:0;
    padding:7px 9px;
    border:1px solid var(--border);
    border-radius:9px;
    background:#fff;
    color:#334155;
    outline:none;
    font-size:12px;
    cursor:pointer;
}

.quick-reply-select:focus{
    border-color:var(--green);
    box-shadow:0 0 0 3px rgba(37,211,102,.15);
}

.quick-reply-btn{
    border:1px solid var(--border);
    background:#f8fafc;
    color:#475569;
    border-radius:8px;
    padding:7px 9px;
    cursor:pointer;
    font-size:11.5px;
    font-weight:800;
    white-space:nowrap;
}

.quick-reply-btn:hover:not(:disabled){
    background:#fff;
    border-color:#94a3b8;
    color:var(--text);
}

.quick-reply-btn.primary{
    background:#ecfdf5;
    color:var(--green-dark);
    border-color:#a7f3d0;
}

.quick-reply-btn.primary:hover:not(:disabled){
    background:#d1fae5;
    border-color:#6ee7b7;
}

.quick-reply-btn:disabled{
    opacity:.45;
    cursor:not-allowed;
}

.quick-reply-hint{
    margin-top:-2px;
    margin-bottom:6px;
    color:#94a3b8;
    font-size:10.5px;
}

@media (max-width:820px){
    .quick-reply-row{
        flex-wrap:wrap;
    }

    .quick-reply-select{
        width:100%;
        flex-basis:100%;
    }
}

.composer-input{
    width:100%;
    resize:vertical;
    min-height:66px;
    max-height:180px;
    border:1px solid var(--border);
    border-radius:10px;
    padding:9px 10px;
    outline:none;
    line-height:1.45;
}

.composer-input:focus{
    border-color:var(--green);
    box-shadow:0 0 0 3px rgba(37,211,102,.15);
}

.composer-actions{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:10px;
    margin-top:7px;
}

.composer-hint{
    color:var(--muted);
    font-size:11px;
}

.composer-buttons{
    display:flex;
    gap:6px;
}

.send-btn{
    border:0;
    background:var(--green-dark);
    color:#fff;
    border-radius:8px;
    padding:7px 11px;
    cursor:pointer;
    font-size:11.5px;
    font-weight:800;
}

.send-btn.bulk{
    background:#2563eb;
}

.send-btn:disabled{
    opacity:.45;
    cursor:not-allowed;
}

.composer-note{
    margin-top:6px;
    color:#94a3b8;
    font-size:10.5px;
    line-height:1.4;
}

.modal{
    position:fixed;
    inset:0;
    z-index:100;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:20px;
}

.modal.hidden{
    display:none !important;
}

.modal-backdrop{
    position:absolute;
    inset:0;
    background:rgba(15,23,42,.48);
    backdrop-filter:blur(2px);
}

.modal-card{
    position:relative;
    width:min(1100px,96vw);
    max-height:min(780px,90vh);
    background:#fff;
    border-radius:16px;
    box-shadow:0 30px 80px rgba(15,23,42,.28);
    overflow:hidden;
    display:flex;
    flex-direction:column;
}

.modal-head{
    padding:14px 16px;
    border-bottom:1px solid var(--border);
    display:flex;
    justify-content:space-between;
    gap:12px;
    align-items:flex-start;
}

.modal-title{
    font-size:16px;
    font-weight:800;
}

.modal-sub{
    color:var(--muted);
    font-size:11.5px;
    margin-top:2px;
}

.modal-close{
    border:0;
    background:#f1f5f9;
    color:#475569;
    width:30px;
    height:30px;
    border-radius:8px;
    font-size:20px;
    cursor:pointer;
    line-height:1;
}

.analysis-stats{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:10px;
    padding:12px 14px;
    border-bottom:1px solid var(--border);
}

.analysis-stat{
    border:1px solid var(--border);
    border-radius:10px;
    padding:10px 12px;
    background:#f8fafc;
}

.analysis-stat b{
    display:block;
    font-size:19px;
}

.analysis-stat span{
    color:var(--muted);
    font-size:11px;
}

.analysis-table-wrap{
    overflow:auto;
}

.analysis-table{
    width:100%;
    border-collapse:collapse;
    font-size:12px;
}

.analysis-table th{
    position:sticky;
    top:0;
    background:#f8fafc;
    padding:10px 12px;
    text-align:left;
    color:var(--muted);
    font-size:10.5px;
    text-transform:uppercase;
    letter-spacing:.4px;
    border-bottom:1px solid var(--border);
}

.analysis-table td{
    padding:10px 12px;
    border-bottom:1px solid #f1f5f9;
    vertical-align:top;
}

.analysis-table tr:hover td{
    background:#f8fafc;
}

.ref-code{
    font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
    font-weight:800;
    font-size:11px;
}

@media (max-width:820px){
    .chat-head{
        align-items:flex-start;
        flex-wrap:wrap;
    }

    .chat-call-controls{
        width:100%;
        margin-left:0;
        justify-content:flex-start;
        padding-left:44px;
    }

    .chat-actions{
        width:100%;
        flex-wrap:wrap;
        justify-content:flex-start;
        margin-left:44px;
    }

    .call-status-select{
        min-width:145px;
        flex:1 1 145px;
    }

    .call-last{
        flex:1 1 100%;
        width:max-content;
    }

    .composer-actions{
        align-items:flex-start;
        flex-direction:column;
    }

    .composer-buttons{
        width:100%;
    }

    .composer-buttons .send-btn,
    .composer-buttons .mini-btn{
        flex:1;
    }

    .analysis-stats{
        grid-template-columns:1fr;
    }

    .modal{
        padding:8px;
    }
}

@media (max-width:1180px){
    .grid{grid-template-columns:290px minmax(0,1fr);}
    .panel.details{display:none;}
}

@media (max-width:820px){
    .wrap{height:auto;padding:10px;}
    .grid{grid-template-columns:1fr;height:auto;}
    .panel{height:auto;max-height:none;}
    .panel-body{max-height:340px;}
    .thread{max-height:60vh;}
    .stats{width:100%;margin-left:0;}
}


/* ========================================================================
   MOVE CHAT MODAL
   ======================================================================== */
.move-modal-card{
    width:min(460px,calc(100vw - 28px));
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:18px;
    box-shadow:0 24px 70px rgba(15,23,42,.22);
    overflow:hidden;
    position:relative;
    z-index:2;
}
.move-modal-card .modal-head{
    display:flex;
    align-items:flex-start;
    justify-content:space-between;
    gap:12px;
    padding:18px 18px 14px;
    border-bottom:1px solid #eef1f5;
}
.move-modal-card .modal-head h3{
    margin:0;
    font-size:18px;
    color:#111827;
}
.move-modal-card .modal-sub{
    margin-top:4px;
    color:#6b7280;
    font-size:12px;
}
.move-modal-card .modal-close{
    border:0;
    background:#f3f4f6;
    width:34px;
    height:34px;
    border-radius:10px;
    font-size:22px;
    line-height:1;
    cursor:pointer;
    color:#4b5563;
}
.move-options{
    display:grid;
    gap:10px;
    padding:16px;
}
.move-option{
    width:100%;
    border:1px solid #e5e7eb;
    background:#fff;
    border-radius:14px;
    padding:13px 14px;
    display:flex;
    align-items:center;
    gap:12px;
    text-align:left;
    cursor:pointer;
    transition:.16s ease;
}
.move-option:hover{
    border-color:#c7d2fe;
    background:#f8fafc;
    transform:translateY(-1px);
}
.move-option-icon{
    width:40px;
    height:40px;
    border-radius:11px;
    display:grid;
    place-items:center;
    background:#f3f4f6;
    flex:0 0 auto;
    font-size:20px;
}
.move-option span:last-child{
    display:flex;
    flex-direction:column;
    gap:2px;
}
.move-option b{
    font-size:14px;
    color:#111827;
}
.move-option small{
    font-size:12px;
    color:#6b7280;
}
.modal-backdrop{
    position:absolute;
    inset:0;
    background:rgba(15,23,42,.38);
}
.modal.hidden{display:none !important;}
</style>
</head>
<body>

<div class="topbar">
    <div class="brand">
        <div class="dot">💬</div>
        <span>WhatsApp Inbox</span>
    </div>

    <div class="tabs">
        <button class="tab active" data-view="inbox">Inbox</button>
        <button class="tab" data-view="pending">⏳ Pending</button>
        <button class="tab" data-view="old">Old</button>
        <button class="tab" data-view="leads">Leads</button>
    </div>

    <div class="stats">
        <div class="stat"><b id="s-conv">–</b><span>Chats</span></div>
        <div class="stat"><b id="s-msg">–</b><span>Messages</span></div>
        <div class="stat"><b id="s-old">–</b><span>Old</span></div>
        <div class="stat"><b id="s-pending">–</b><span>Pending</span></div>
        <div class="stat"><b id="s-leads">–</b><span>Leads</span></div>
        <div class="stat call-stat"><b id="s-not-called">–</b><span>Not called</span></div>
        <div class="stat call-stat"><b id="s-called">–</b><span>Called</span></div>
        <div class="stat call-stat"><b id="s-rejected">–</b><span>Rejected</span></div>
        <div class="stat call-stat"><b id="s-try-again">–</b><span>Try again</span></div>
        <div class="stat"><b id="s-today">–</b><span>Today</span></div>
    </div>

    <div class="toolbar">
        <button class="auto-btn on" id="autoBtn">
            <span class="pulse"></span> Live
        </button>
        <button class="auto-btn" id="installAppBtn" style="display:none">⤓ Install</button>
    </div>
</div>

<div class="wrap">

<div class="grid" id="inboxView">

    <div class="panel">
        <div class="filters">
            <input class="input" id="searchInput" type="search" placeholder="Search name, phone, message, ref…">

            <div class="filter-row">
                <select class="select" id="sourceFilter">
                    <option value="">All sources</option>
                </select>
                <select class="select" id="platformFilter">
                    <option value="">All platforms</option>
                </select>
            </div>

            <button class="filter-toggle" id="toggleAdv">
                ⚙️ More filters <span class="cnt hidden" id="advCount">0</span>
            </button>

            <div class="adv-filters hidden" id="advFilters">
                <div class="filter-row">
                    <select class="select" id="sourceTypeFilter">
                        <option value="">Any type</option>
                    </select>
                    <select class="select" id="productFilter">
                        <option value="">Any product</option>
                    </select>
                </div>

                <input class="input" id="referenceFilter" placeholder="Reference code (contains)">

                <div class="filter-row">
                    <select class="select" id="referralFilter">
                        <option value="">All chats</option>
                        <option value="yes">Only with referral</option>
                        <option value="no">Only without referral</option>
                    </select>
                    <select class="select" id="ctwaFilter">
                        <option value="">Any CLID</option>
                        <option value="yes">Has CTWA CLID</option>
                    </select>
                </div>

                <div class="filter-row">
                    <select class="select" id="messageTypeFilter">
                        <option value="">Any msg type</option>
                    </select>
                    <select class="select" id="sortFilter">
                        <option value="latest">Latest first</option>
                        <option value="oldest">Oldest first</option>
                        <option value="name">Name A–Z</option>
                        <option value="messages">Most messages</option>
                    </select>
                </div>

                <div class="adv-label">Date range</div>

                <div class="filter-row">
                    <input class="input" type="date" id="dateFrom" placeholder="From">
                    <input class="input" type="date" id="dateTo" placeholder="To">
                </div>

                <div class="chips">
                    <button class="chip" data-range="today">Today</button>
                    <button class="chip" data-range="7">Last 7 days</button>
                    <button class="chip" data-range="30">Last 30 days</button>
                    <button class="chip" data-range="month">This month</button>
                </div>
            </div>

            <div class="chips" id="filterChips"></div>
        </div>
 <h2 id="conversationsTitle"></h2>
        <div class="panel-head">
     
           
        
            <div class="head-actions">
                <button class="mini-btn" id="selectAllVisible" title="Select all visible chats">☑ Select all</button>
                <button class="mini-btn" id="moveSelected" title="Move selected chats to Inbox, Pending or Old">📦 Move to…</button>
                <button class="mini-btn danger" id="deleteSelected" title="Delete selected chats from database" disabled>🗑 Delete</button>
                <span class="count-pill" id="convCount">0</span>
            </div>
        </div>

        <div class="panel-body" id="convList">
            <div class="empty"><div class="big">⏳</div>Loading…</div>
        </div>
    </div>

    <div class="panel">
        <div class="chat-head" id="chatHead">
            <div class="avatar" id="chatAvatar">–</div>
            <div class="chat-head-main">
                <div class="name" id="chatName">Select a conversation</div>
                <div class="sub" id="chatSub">Pick a chat from the list to view messages</div>
              
            </div>
            <div>
            </div>
        <div class="chat-call-controls">
                <button class="mini-btn call-attempt-btn" id="addCallAttemptBtn" type="button" disabled>＋ Attempt</button>
                <select class="call-status-select" id="chatCallStatus" disabled aria-label="Call state">
                    <option value="not_called">📞 Not called</option>
                    <option value="called">✅ Called</option>
                    <option value="rejected">🚫 Rejected</option>
                    <option value="try_again">🔄 Try again</option>
                </select>
                <span class="call-last" id="chatCallLast">0 attempts · Last call: —</span>
            </div>
            <div class="chat-actions">
                <button class="mini-btn" id="openWhatsAppWeb" title="Open this chat in WhatsApp Web">🌐 WhatsApp Web</button>
                <button class="mini-btn" id="moveChatBtn" title="Move this chat to Inbox, Pending or Old">📦 Move to…</button>
                <button class="mini-btn danger" id="deleteChat" title="Delete this chat from the database" disabled>🗑 Delete chat</button>
            </div>
        </div>

        <div class="thread" id="thread">
            <div class="empty" style="margin:auto">
                <div class="big">💬</div>No conversation selected
            </div>
        </div>

        <div class="composer">
            <div class="composer-top">
                <span class="composer-label">Send message</span>
                <span class="composer-target" id="composerTarget">No chat selected</span>
            </div>

            <div class="quick-reply-row">
                <select id="quickReplySelect" class="quick-reply-select" aria-label="Quick reply">
                    <option value="">⚡ Quick reply — choose a ready message</option>
                </select>
                <button class="quick-reply-btn" id="useQuickReplyBtn" type="button" disabled>Use</button>
                <button class="quick-reply-btn primary" id="sendQuickReplyBtn" type="button" disabled>⚡ Send quick</button>
            </div>
            <div class="quick-reply-hint">Use a ready-made professional reply, edit it when needed, then send normally.</div>

            <textarea id="messageComposer" class="composer-input" rows="3"
                placeholder="Type a WhatsApp message…"></textarea>

            <div class="composer-actions">
                <div class="composer-hint">
                    <span id="selectedCountText">0 chats selected</span>
                </div>
                <div class="composer-buttons">
                    <button class="mini-btn" id="openWhatsAppWebFromComposer" disabled>🌐 Web</button>
                    <button class="send-btn" id="sendOneBtn" disabled>➤ Send</button>
                    <button class="send-btn bulk" id="sendSelectedBtn" disabled>➤ Send to selected</button>
                </div>
            </div>

            <div class="composer-note">
                Cloud API sends through the configured WhatsApp number (bulk: up to 50 selected chats per action). WhatsApp Web opens the official Web chat with the message prefilled; sending there is manual.
            </div>
        </div>
    </div>

    <div class="panel details">
        <div class="panel-head"><h2>Lead / Referral Details</h2></div>
        <div class="panel-body" id="detailsPanel">
            <div class="empty"><div class="big">📋</div>No lead data</div>
        </div>
    </div>
</div>

<div class="panel call-tracking-panel" id="callTrackingPanel">
    <div class="panel-head call-tracking-head">
        <div>
            <h2>Customer Call Tracking</h2>
            <div class="panel-sub">Track call state and attempt count. Use “＋ Attempt” after each phone-call attempt. No call-result history is stored.</div>
        </div>
        <div class="head-actions">
            <span class="count-pill" id="callTrackingCount">0</span>
            <button class="mini-btn" id="refreshCallTracking" type="button">↻ Refresh</button>
        </div>
    </div>
    <div class="panel-body call-tracking-body" id="callTrackingBody">
        <div class="empty"><div class="big">📞</div>Loading…</div>
    </div>
</div>

<div class="panel hidden" id="leadsView" style="height:100%">

    <div class="leads-filters">
        <div class="filter-row">
            <input class="input" id="leadSearch" placeholder="Search leads…" style="max-width:340px">
            <select class="select" id="leadSort" style="max-width:200px">
                <option value="latest">Latest first</option>
                <option value="oldest">Oldest first</option>
                <option value="name">Name A–Z</option>
            </select>
        </div>

        <div class="leads-filter-grid">
            <select class="select" id="leadPlatform">
                <option value="">All platforms</option>
            </select>
            <select class="select" id="leadSourceType">
                <option value="">Any source type</option>
            </select>
            <select class="select" id="leadProduct">
                <option value="">Any product</option>
            </select>
            <input class="input" id="leadReference" placeholder="Reference code">
            <select class="select" id="leadCtwa">
                <option value="">Any CLID</option>
                <option value="yes">Has CTWA CLID</option>
            </select>
            <select class="select" id="leadCallStatus">
                <option value="">Any call state</option>
                <option value="not_called">📞 Not called</option>
                <option value="called">✅ Called</option>
                <option value="rejected">🚫 Rejected</option>
                <option value="try_again">🔄 Try again</option>
                <option value="attempted">🔄🚫 Attempted (Try again + Rejected)</option>
            </select>
            <input class="input" type="date" id="leadDateFrom">
            <input class="input" type="date" id="leadDateTo">
        </div>

        <div class="chips" id="leadChips"></div>
    </div>

    <div class="panel-head">
        <h2>Captured Leads</h2>
        <div class="head-actions">
            <button class="mini-btn" id="referenceAnalysisBtn">📊 Reference Analysis</button>
            <span class="count-pill" id="leadCount">0</span>
        </div>
    </div>

    <div class="panel-body leads-wrap" id="leadsBody">
        <div class="empty"><div class="big">📥</div>Loading…</div>
    </div>
</div>

</div>

<div class="modal hidden" id="referenceModal">
    <div class="modal-backdrop" id="referenceModalBackdrop"></div>

    <div class="modal-card">
        <div class="modal-head">
            <div>
                <div class="modal-title">Reference Analysis</div>
                <div class="modal-sub">Reference performance for the current lead filters</div>
            </div>
            <button class="modal-close" id="closeReferenceModal">×</button>
        </div>

        <div class="analysis-stats">
            <div class="analysis-stat">
                <b id="raMessages">0</b>
                <span>Referral messages</span>
            </div>
            <div class="analysis-stat">
                <b id="raCustomers">0</b>
                <span>Unique customers</span>
            </div>
            <div class="analysis-stat">
                <b id="raReferences">0</b>
                <span>Unique references</span>
            </div>
        </div>

        <div class="analysis-table-wrap" id="referenceAnalysisBody">
            <div class="empty"><span class="spinner"></span></div>
        </div>
    </div>
</div>

<!-- MOVE CHAT MODAL -->
<div class="modal hidden" id="moveChatModal" aria-hidden="true">
    <div class="modal-backdrop" id="moveChatModalBackdrop"></div>
    <div class="modal-card move-modal-card" role="dialog" aria-modal="true" aria-labelledby="moveChatModalTitle">
        <div class="modal-head">
            <div>
                <h3 id="moveChatModalTitle">Move chat</h3>
                <div class="modal-sub" id="moveChatModalSub">Choose a destination</div>
            </div>
            <button type="button" class="modal-close" id="closeMoveChatModal" aria-label="Close">×</button>
        </div>
        <div class="move-options">
            <button type="button" class="move-option inbox" data-move-target="inbox">
                <span class="move-option-icon">📥</span>
                <span><b>Inbox</b><small>Move back to the main inbox</small></span>
            </button>
            <button type="button" class="move-option pending" data-move-target="pending">
                <span class="move-option-icon">⏳</span>
                <span><b>Pending</b><small>Keep this chat for follow-up</small></span>
            </button>
            <button type="button" class="move-option old" data-move-target="old">
                <span class="move-option-icon">📦</span>
                <span><b>Old</b><small>Move this chat out of the active list</small></span>
            </button>
        </div>
    </div>
</div>

<script>
/* =========================================================================
   HELPERS
   ========================================================================= */
const $ = (id) => document.getElementById(id);
const $$ = (sel) => document.querySelectorAll(sel);

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => (
    {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]
));

function safeUrl(value) {
    try {
        const url = new URL(String(value || ''), window.location.origin);
        if (url.protocol === 'https:' || url.protocol === 'http:') {
            return url.href;
        }
    } catch (e) {}
    return null;
}

function api(action, params = {}) {
    const url = new URL(window.location.href);
    url.search = '';
    url.searchParams.set('action', action);

    Object.entries(params).forEach(([k, v]) => {
        if (v !== '' && v !== null && v !== undefined) {
            url.searchParams.set(k, v);
        }
    });

    return fetch(url.toString(), {
        headers: { 'Accept':'application/json' }
    }).then(async r => {
        const text = await r.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error(text || ('HTTP ' + r.status));
        }
        if (!r.ok && !data.error) {
            throw new Error('HTTP ' + r.status);
        }
        return data;
    });
}

async function apiPost(action, payload = {}) {
    const url = new URL(window.location.href);
    url.search = '';
    url.searchParams.set('action', action);

    const response = await fetch(url.toString(), {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-CSRF-Token': CSRF_TOKEN
        },
        body: JSON.stringify(payload)
    });

    const text = await response.text();
    let data;

    try {
        data = JSON.parse(text);
    } catch (e) {
        throw new Error(text || ('HTTP ' + response.status));
    }

    if (!response.ok) {
        throw new Error(data.error || ('HTTP ' + response.status));
    }

    return data;
}

function fmtDateTime(s) {
    if (!s) return '—';

    const d = new Date(String(s).replace(' ', 'T'));
    if (isNaN(d)) return String(s);

    const now = new Date();
    const same = d.toDateString() === now.toDateString();

    if (same) {
        return d.toLocaleTimeString([], {
            hour:'2-digit',
            minute:'2-digit'
        });
    }

    return d.toLocaleDateString([], {
        day:'2-digit',
        month:'short'
    }) + ' ' + d.toLocaleTimeString([], {
        hour:'2-digit',
        minute:'2-digit'
    });
}

function fmtFull(s) {
    if (!s) return '—';

    const d = new Date(String(s).replace(' ', 'T'));
    return isNaN(d) ? String(s) : d.toLocaleString();
}

function initials(name, phone) {
    if (name) {
        return name
            .trim()
            .split(/\s+/)
            .slice(0,2)
            .map(w => w[0])
            .join('')
            .toUpperCase();
    }

    return String(phone || '?').slice(-2);
}

function colorClass(key) {
    let h = 0;
    for (const ch of String(key || '')) {
        h = (h * 31 + ch.charCodeAt(0)) % 5;
    }
    return 'a' + (h + 1);
}

function sourceBadge(source) {
    const s = String(source || 'Unknown');
    let cls = 'gray';

    if (s === 'Normal Chat') cls = 'gray';
    else if (/video/i.test(s)) cls = 'purple';
    else if (/flyer|image/i.test(s)) cls = 'amber';
    else if (/^Ad/i.test(s)) cls = 'blue';
    else cls = 'green';

    return `<span class="badge ${cls}">${esc(s)}</span>`;
}

function tickMark(status) {
    const s = String(status || '').toLowerCase();

    if (!s) return '';
    if (s === 'read') return '<span class="tick read">✓✓</span>';
    if (s === 'delivered') return '<span class="tick">✓✓</span>';
    if (s === 'sent') return '<span class="tick">✓</span>';
    if (s === 'failed') return '<span class="tick" style="color:#dc2626">✕</span>';

    return `<span class="tick">${esc(s)}</span>`;
}

/* =========================================================================
   PWA INSTALL
   ========================================================================= */
let deferredInstallPrompt = null;

window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    deferredInstallPrompt = event;

    const btn = $('installAppBtn');
    if (btn) {
        btn.style.display = '';
    }
});

window.addEventListener('appinstalled', () => {
    deferredInstallPrompt = null;
    const btn = $('installAppBtn');
    if (btn) {
        btn.style.display = 'none';
    }
});

async function promptInstallApp() {
    const btn = $('installAppBtn');

    if (!deferredInstallPrompt) {
        if (btn) {
            btn.style.display = 'none';
        }
        window.alert('Install is not available in this browser yet. Open the page in Chrome, Edge, or Safari and try again.');
        return;
    }

    deferredInstallPrompt.prompt();
    const choice = await deferredInstallPrompt.userChoice;

    if (choice && choice.outcome === 'accepted') {
        deferredInstallPrompt = null;
        if (btn) {
            btn.style.display = 'none';
        }
    }
}

/* =========================================================================
   QUICK REPLIES
   ========================================================================= */
const QUICK_REPLIES = [
    {
        id: 'thanks',
        label: 'Thank you for contacting us',
        message: 'Thank you for contacting Ontech IT Solutions. We have received your message and will get back to you shortly.'
    },
    {
        id: 'contact-soon',
        label: 'We will contact you soon',
        message: 'Thank you for your interest. Our team will contact you soon to discuss your requirement.'
    },
    {
        id: 'send-details',
        label: 'Please send your details',
        message: 'Please send us your name, company name, contact number, and a brief description of your requirement. Our team will review the details and contact you shortly.'
    },
    {
        id: 'more-details',
        label: 'Please share more details',
        message: 'Could you please share a few more details about your requirement so we can assist you better?'
    },
    {
        id: 'call-time',
        label: 'Ask for a convenient call time',
        message: 'We can arrange a quick call to discuss this. Please let us know a convenient time for our team to contact you.'
    },
    {
        id: 'demo',
        label: 'Arrange a system demo',
        message: 'We would be happy to arrange a demo. Please share your preferred day and a contact number, and our team will coordinate with you.'
    },
    {
        id: 'pricing',
        label: 'Pricing / quotation',
        message: 'Thank you for your interest. Please share the modules or features you require, and our team will discuss the suitable solution and pricing with you.'
    },
    {
        id: 'follow-up',
        label: 'Follow up on an inquiry',
        message: 'Just following up on your inquiry. Please let us know if you would like us to contact you and discuss the requirement further.'
    },
    {
        id: 'noted',
        label: 'Requirement received',
        message: 'Thank you. We have noted your requirement. Our team will review it and get back to you shortly.'
    },
    {
        id: 'si-contact',
        label: 'Sinhala — contact soon',
        message: 'ඔබගේ පණිවිඩයට ස්තූතියි. ඔබගේ අවශ්‍යතාවය අපට ලැබී ඇත. අපගේ කණ්ඩායම ඉක්මනින් ඔබව සම්බන්ධ කරගෙන වැඩි විස්තර සාකච්ඡා කරනු ඇත.'
    },
    {
        id: 'si-details',
        label: 'Sinhala — send your details',
        message: 'කරුණාකර ඔබගේ නම, ආයතනයේ නම, දුරකථන අංකය සහ ඔබට අවශ්‍ය software / system එක පිළිබඳ කෙටි විස්තරයක් එවන්න. අපගේ කණ්ඩායම එය පරීක්ෂා කර ඉක්මනින් ඔබව සම්බන්ධ කරගනු ඇත.'
    },
    {
        id: 'si-call',
        label: 'Sinhala — ask for call time',
        message: 'ඔබට පහසු call වේලාවක් දැනුම් දෙන්න. අපගේ කණ්ඩායම එම වේලාවට ඔබව සම්බන්ධ කරගනු ඇත.'
    }
];

function populateQuickReplies() {
    const select = $('quickReplySelect');
    if (!select) return;

    select.innerHTML =
        '<option value="">⚡ Quick reply — choose a ready message</option>' +
        QUICK_REPLIES.map(item =>
            `<option value="${esc(item.id)}">${esc(item.label)}</option>`
        ).join('');
}

function getQuickReplyById(id) {
    return QUICK_REPLIES.find(item => item.id === id) || null;
}

function getSelectedQuickReplyText() {
    const select = $('quickReplySelect');
    if (!select || !select.value) return '';

    const item = getQuickReplyById(select.value);
    return item ? item.message : '';
}

function updateQuickReplyUI() {
    const select = $('quickReplySelect');
    const useBtn = $('useQuickReplyBtn');
    const sendBtn = $('sendQuickReplyBtn');

    if (!select) return;

    const hasReply = !!select.value && !!getSelectedQuickReplyText();
    const hasTarget = !!state.phone || state.selectedPhones.size > 0;

    if (useBtn) {
        useBtn.disabled = !hasReply;
    }

    if (sendBtn) {
        sendBtn.disabled = !hasReply || !hasTarget;
    }
}

function useQuickReply() {
    const text = getSelectedQuickReplyText();
    if (!text) return;

    const textarea = $('messageComposer');
    if (!textarea) return;

    textarea.value = text;
    textarea.focus();
    textarea.setSelectionRange(textarea.value.length, textarea.value.length);
    updateComposerState();
    updateQuickReplyUI();
}

function sendQuickReply() {
    const text = getSelectedQuickReplyText();
    if (!text) return;

    const textarea = $('messageComposer');
    if (!textarea) return;

    textarea.value = text;
    updateComposerState();

    /* Selected checkboxes take priority for bulk quick-send.
       Otherwise the currently opened chat receives the quick reply. */
    if (state.selectedPhones.size > 0) {
        sendSelectedMessage();
    } else if (state.phone) {
        sendCurrentMessage();
    }
}

/* =========================================================================
   STATE
   ========================================================================= */
const CSRF_TOKEN = <?= json_encode($waInboxCsrf) ?>;

const state = {
    phone: null,
    selectedPhones: new Set(),
    callStatus: 'not_called',
    callCalledAt: null,
    callAttemptCount: 0,
    callLastAt: null,
    currentMessageId: null,
    chatBox: 'inbox',
    auto: true,
    timer: null,
    view: 'inbox',

    filters: {
        q: '',
        source: '',
        platform: '',
        source_type: '',
        product: '',
        reference: '',
        referral: '',
        ctwa: '',
        message_type: '',
        date_from: '',
        date_to: '',
        sort: 'latest',
    },

    leadFilters: {
        q: '',
        platform: '',
        source_type: '',
        product: '',
        reference: '',
        ctwa: '',
        call_status: '',
        date_from: '',
        date_to: '',
        sort: 'latest',
    },
};

/* =========================================================================
   FILTER OPTIONS
   ========================================================================= */
async function loadFilterOptions() {
    try {
        const res = await api('filter_options');
        if (!res.data) return;

        const o = res.data;

        fillSelect('sourceFilter',      o.sources,       'All sources');
        fillSelect('platformFilter',    o.platforms,     'All platforms');
        fillSelect('sourceTypeFilter',  o.source_types,  'Any type');
        fillSelect('productFilter',     o.products,      'Any product');
        fillSelect('messageTypeFilter', o.message_types, 'Any msg type');

        fillSelect('leadPlatform',   o.platforms,     'All platforms');
        fillSelect('leadSourceType', o.source_types,  'Any source type');
        fillSelect('leadProduct',    o.products,      'Any product');
    } catch (e) {
        console.error('filter_options:', e);
    }
}

function fillSelect(id, values, placeholder) {
    const el = $(id);
    if (!el) return;

    const keep = el.value;

    el.innerHTML =
        `<option value="">${esc(placeholder)}</option>` +
        (values || [])
            .map(v => `<option value="${esc(v)}">${esc(v)}</option>`)
            .join('');

    if (keep) el.value = keep;
}

/* =========================================================================
   STATS
   ========================================================================= */
async function loadStats() {
    try {
        const s = await api('stats');
        if (s.error) return;

        $('s-conv').textContent     = s.conversations ?? 0;
        $('s-msg').textContent      = s.messages ?? 0;
        $('s-old').textContent      = s.old_conversations ?? 0;
        $('s-pending').textContent  = s.pending_conversations ?? 0;
        $('s-leads').textContent    = s.leads ?? 0;
        $('s-not-called').textContent = s.not_called ?? 0;
        $('s-called').textContent   = s.called ?? 0;
        $('s-rejected').textContent = s.rejected ?? 0;
        $('s-try-again').textContent = s.try_again ?? 0;
        $('s-today').textContent    = s.today ?? 0;
    } catch (e) {
        console.error('stats:', e);
    }
}

/* =========================================================================
   INBOX FILTERS UI
   ========================================================================= */
const filterInputMap = {
    searchInput:        'q',
    sourceFilter:       'source',
    platformFilter:     'platform',
    sourceTypeFilter:   'source_type',
    productFilter:      'product',
    referenceFilter:    'reference',
    referralFilter:     'referral',
    ctwaFilter:         'ctwa',
    messageTypeFilter:  'message_type',
    dateFrom:           'date_from',
    dateTo:             'date_to',
    sortFilter:         'sort',
};

function bindInboxFilters() {
    let timer = null;

    const apply = (debounce = true) => {
        clearTimeout(timer);

        const run = () => {
            loadConversations();
            renderFilterChips();
            updateAdvCount();
        };

        debounce ? timer = setTimeout(run, 250) : run();
    };

    Object.entries(filterInputMap).forEach(([id, key]) => {
        const el = $(id);
        if (!el) return;

        const evt =
            (el.tagName === 'INPUT' && el.type !== 'date')
                ? 'input'
                : 'change';

        el.addEventListener(evt, () => {
            state.filters[key] = el.value;
            apply(evt === 'input');
        });
    });

    $('toggleAdv').addEventListener('click', () => {
        $('advFilters').classList.toggle('hidden');
        $('toggleAdv').classList.toggle('active');
    });

    $$('.chip[data-range]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const r = btn.dataset.range;
            const from = new Date();
            const to   = new Date();

            if (r === 'today') {
                // Same day.
            } else if (r === '7') {
                from.setDate(from.getDate() - 6);
            } else if (r === '30') {
                from.setDate(from.getDate() - 29);
            } else if (r === 'month') {
                from.setDate(1);
            }

            const iso = d => {
                const local = new Date(
                    d.getTime() - d.getTimezoneOffset() * 60000
                );
                return local.toISOString().slice(0,10);
            };

            $('dateFrom').value = iso(from);
            $('dateTo').value   = iso(to);

            state.filters.date_from = iso(from);
            state.filters.date_to   = iso(to);

            loadConversations();
            renderFilterChips();
            updateAdvCount();
        });
    });

    $('filterChips').addEventListener('click', (e) => {
        if (e.target.closest('.chip.clear-all')) {
            clearAllInboxFilters();
        } else if (e.target.dataset.clear) {
            const key = e.target.dataset.clear;
            state.filters[key] = '';

            const id = Object.keys(filterInputMap)
                .find(k => filterInputMap[k] === key);

            if (id && $(id)) {
                $(id).value = '';
            }

            loadConversations();
            renderFilterChips();
            updateAdvCount();
        }
    });
}

function clearAllInboxFilters() {
    Object.keys(state.filters).forEach(k => {
        state.filters[k] = k === 'sort' ? 'latest' : '';
    });

    $('searchInput').value = '';
    $('sourceFilter').value = '';
    $('platformFilter').value = '';
    $('sourceTypeFilter').value = '';
    $('productFilter').value = '';
    $('referenceFilter').value = '';
    $('referralFilter').value = '';
    $('ctwaFilter').value = '';
    $('messageTypeFilter').value = '';
    $('dateFrom').value = '';
    $('dateTo').value = '';
    $('sortFilter').value = 'latest';

    loadConversations();
    renderFilterChips();
    updateAdvCount();
}

const filterLabels = {
    q: 'Search',
    source: 'Source',
    platform: 'Platform',
    source_type: 'Type',
    product: 'Product',
    reference: 'Ref',
    referral: 'Referral',
    ctwa: 'CTWA',
    message_type: 'Msg type',
    date_from: 'From',
    date_to: 'To',
};

function renderFilterChips() {
    const chips = [];

    Object.entries(state.filters).forEach(([k, v]) => {
        if (!v || k === 'sort') return;

        const label = filterLabels[k] || k;
        const val =
            k === 'referral'
                ? (v === 'yes' ? 'With referral' : 'No referral')
                : k === 'ctwa'
                    ? 'Has CLID'
                    : v;

        chips.push(
            `<span class="chip">${esc(label)}: ${esc(val)}
                <button data-clear="${esc(k)}" title="Remove">×</button>
             </span>`
        );
    });

    if (chips.length > 1) {
        chips.push(`<span class="chip clear-all">Clear all ×</span>`);
    }

    $('filterChips').innerHTML = chips.join('');
}

function countActiveInboxFilters() {
    let n = 0;

    [
        'source_type',
        'product',
        'reference',
        'referral',
        'ctwa',
        'message_type',
        'date_from',
        'date_to'
    ].forEach(k => {
        if (state.filters[k]) n++;
    });

    return n;
}

function updateAdvCount() {
    const n = countActiveInboxFilters();
    const badge = $('advCount');

    if (n > 0) {
        badge.textContent = n;
        badge.classList.remove('hidden');
        $('toggleAdv').classList.add('active');
        $('advFilters').classList.remove('hidden');
    } else {
        badge.classList.add('hidden');
    }
}

/* =========================================================================
   CONVERSATIONS
   ========================================================================= */
async function loadConversations() {
    try {
        const res = await api('conversations', { ...state.filters, box: state.chatBox });

        if (res.error) {
            $('convList').innerHTML =
                `<div class="empty"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        $('convCount').textContent = rows.length;

        const visiblePhones = new Set(
            rows.map(r => String(r.customer_phone || '')).filter(Boolean)
        );

        state.selectedPhones.forEach(phone => {
            if (!visiblePhones.has(phone)) {
                state.selectedPhones.delete(phone);
            }
        });

        if (!rows.length) {
            $('convList').innerHTML =
                '<div class="empty"><div class="big">🔍</div>No conversations match filters</div>';
            return;
        }

        $('convList').innerHTML = rows.map(r => {
            const name = r.customer_name || r.customer_phone || 'Unknown';
            const active =
                r.customer_phone === state.phone ? ' active' : '';

            const preview =
                r.direction === 'outgoing'
                    ? 'You: ' + (r.message_text || '')
                    : (r.message_text || '');

            const badges = [sourceBadge(r.message_source)];

            if (r.source_platform) {
                badges.push(
                    `<span class="badge blue">${esc(r.source_platform)}</span>`
                );
            }

            if (r.reference_code) {
                badges.push(
                    `<span class="badge green mono">${esc(r.reference_code)}</span>`
                );
            }

            const callStatus = normalizeCallState(r.call_status);
            badges.push(
                `<span class="call-status-badge ${callStatusCssClass(callStatus)}">${esc(callStatusLabel(callStatus))}</span>`
            );

            return `
                <div class="conv${active}" data-phone="${esc(r.customer_phone)}">
                    <div class="conv-select">
                        <input
                            type="checkbox"
                            class="conv-check"
                            data-phone="${esc(r.customer_phone)}"
                            ${state.selectedPhones.has(r.customer_phone) ? 'checked' : ''}
                            aria-label="Select ${esc(name)}"
                        >
                    </div>
                    <div class="avatar ${colorClass(r.customer_phone)}">
                        ${esc(initials(r.customer_name, r.customer_phone))}
                    </div>

                    <div class="conv-main">
                        <div class="conv-top">
                            <div class="conv-name">${esc(name)}</div>
                            <div class="conv-time">
                                ${esc(fmtDateTime(r.message_timestamp))}
                            </div>
                        </div>

                        <div class="conv-preview">
                            ${esc(preview).slice(0, 90)}
                        </div>

                        <div class="conv-badges">
                            ${badges.join('')}
                            <span class="count-pill">
                                ${esc(r.total_messages)} msgs
                            </span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        $$('.conv').forEach(el => {
            el.addEventListener('click', (event) => {
                if (event.target.closest('.conv-check')) {
                    return;
                }

                selectConversation(el.dataset.phone);
            });
        });

        $$('.conv-check').forEach(check => {
            check.addEventListener('click', (event) => {
                event.stopPropagation();

                const phone = check.dataset.phone || '';

                if (check.checked) {
                    state.selectedPhones.add(phone);
                } else {
                    state.selectedPhones.delete(phone);
                }

                updateSelectionUI();
            });
        });

        updateSelectionUI();
        await loadCallTracking();

    } catch (e) {
        $('convList').innerHTML =
            `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

/* =========================================================================
   SELECTION / BULK ACTIONS
   ========================================================================= */
function updateSelectionUI() {
    const count = state.selectedPhones.size;
    const deleteBtn = $('deleteSelected');
    const moveBtn = $('moveSelected');
    const sendSelectedBtn = $('sendSelectedBtn');
    const selectedCountText = $('selectedCountText');

    if (moveBtn) {
        moveBtn.disabled = count === 0;
        moveBtn.textContent = '📦 Move to…';
    }

    if (deleteBtn) {
        deleteBtn.disabled = count === 0;
        deleteBtn.textContent = count
            ? `🗑 Delete (${count})`
            : '🗑 Delete';
    }

    if (selectedCountText) {
        selectedCountText.textContent =
            count === 1
                ? '1 chat selected'
                : `${count} chats selected`;
    }

    if (sendSelectedBtn) {
        sendSelectedBtn.disabled =
            count === 0 ||
            !String($('messageComposer')?.value || '').trim();
    }

    $$('.conv-check').forEach(check => {
        check.checked = state.selectedPhones.has(
            check.dataset.phone || ''
        );
    });

    const selectAllBtn = $('selectAllVisible');
    const visibleChecks = Array.from(
        document.querySelectorAll('.conv-check')
    );

    if (selectAllBtn) {
        const allVisibleSelected =
            visibleChecks.length > 0 &&
            visibleChecks.every(check =>
                state.selectedPhones.has(
                    check.dataset.phone || ''
                )
            );

        selectAllBtn.textContent =
            allVisibleSelected
                ? '☐ Clear visible'
                : '☑ Select all';
    }

    updateQuickReplyUI();
}

function selectAllVisibleChats() {
    const checks = Array.from(
        document.querySelectorAll('.conv-check')
    );

    if (!checks.length) {
        return;
    }

    const allSelected = checks.every(check =>
        state.selectedPhones.has(check.dataset.phone || '')
    );

    checks.forEach(check => {
        const phone = check.dataset.phone || '';

        if (allSelected) {
            state.selectedPhones.delete(phone);
        } else {
            state.selectedPhones.add(phone);
        }
    });

    const btn = $('selectAllVisible');

    if (btn) {
        btn.textContent = allSelected
            ? '☑ Select all'
            : '☐ Clear visible';
    }

    updateSelectionUI();
}

function resetSelectedChatUI() {
    $('chatAvatar').textContent = '–';
    $('chatAvatar').className = 'avatar';
    $('chatName').textContent = 'Select a conversation';
    $('chatSub').textContent = state.chatBox === 'old'
        ? 'Pick an old chat from the list to view messages'
        : state.chatBox === 'pending'
            ? 'Pick a pending chat from the list to view messages'
            : 'Pick a chat from the Inbox list to view messages';

    state.callStatus = 'not_called';
    state.callCalledAt = null;
    state.callAttemptCount = 0;
    state.callLastAt = null;
    state.currentMessageId = null;
    updateCallStatusUI();

    $('thread').innerHTML =
        '<div class="empty" style="margin:auto">' +
        '<div class="big">💬</div>' +
        'No conversation selected</div>';

    $('detailsPanel').innerHTML =
        '<div class="empty">' +
        '<div class="big">📋</div>' +
        'No lead data</div>';

    updateComposerState();
}

function normalizeCallState(status) {
    const s = String(status || '').toLowerCase();
    return ['not_called', 'called', 'rejected', 'try_again'].includes(s)
        ? s
        : 'not_called';
}

function callStatusLabel(status) {
    const labels = {
        not_called: 'Not called',
        called: 'Called',
        rejected: 'Rejected',
        try_again: 'Try again',
    };
    return labels[normalizeCallState(status)] || 'Not called';
}

function callStatusCssClass(status) {
    return normalizeCallState(status).replace('_', '-');
}

function setCallStatusControls(data = {}) {
    state.callStatus = normalizeCallState(data.call_status);
    state.callCalledAt = data.called_at || null;
    state.callAttemptCount = Number(data.attempt_count || 0);
    state.callLastAt = data.called_at || null;
    const bucket = String(data.chat_bucket || state.chatBox || 'inbox');
    state.chatBox = ['inbox', 'pending', 'old'].includes(bucket)
        ? bucket
        : 'inbox';
    updateCallStatusUI();
}

function updateCallStatusUI() {
    const select = $('chatCallStatus');
    const last = $('chatCallLast');
    const addAttemptBtn = $('addCallAttemptBtn');
    const moveBtn = $('moveChatBtn');

    if (select) {
        select.disabled = !state.phone;
        select.value = normalizeCallState(state.callStatus);
        select.classList.remove('called', 'rejected', 'try_again');
        if (state.callStatus !== 'not_called') {
            select.classList.add(state.callStatus);
        }
    }

    if (last) {
        const count = Number(state.callAttemptCount || 0);
        last.textContent =
            `${count} attempt${count === 1 ? '' : 's'} · Last call: ` +
            (state.callLastAt ? fmtFull(state.callLastAt) : '—');
    }

    if (addAttemptBtn) {
        addAttemptBtn.disabled = !state.phone;
    }

    if (moveBtn) {
        moveBtn.disabled = !state.phone;
        moveBtn.textContent = '📦 Move to…';
    }
}

async function loadCallStatus(phone) {
    if (!phone) {
        setCallStatusControls({
            call_status: 'not_called',
            called_at: null,
            attempt_count: 0,
            chat_bucket: state.chatBox
        });
        return null;
    }

    try {
        const res = await api('call_status_read', { phone });
        if (res && res.data) {
            setCallStatusControls(res.data);
            if (res.data.conversation_message_id) {
                state.currentMessageId = Number(res.data.conversation_message_id);
            }
            return res.data;
        }
    } catch (e) {
        console.warn('call status:', e);
    }

    setCallStatusControls({
        call_status: 'not_called',
        called_at: null,
        attempt_count: 0,
        chat_bucket: state.chatBox
    });
    return null;
}

async function saveCallStatus(phone, status, conversationMessageId = null) {
    if (!phone) return null;

    const select = $('chatCallStatus');
    const isCurrentChat = state.phone === phone;
    const previousStatus = state.callStatus;
    const previousCalledAt = state.callCalledAt;
    const previousAttempts = state.callAttemptCount;

    try {
        if (isCurrentChat && select) select.disabled = true;

        const res = await apiPost('call_status', {
            phone,
            status,
            conversation_message_id: conversationMessageId ? Number(conversationMessageId) : null
        });

        if (res.error) throw new Error(res.error);

        if (isCurrentChat) {
            if (res.data?.conversation_message_id) {
                state.currentMessageId = Number(res.data.conversation_message_id);
            }
            setCallStatusControls(res.data || {
                call_status: status,
                called_at: previousCalledAt,
                attempt_count: previousAttempts,
                conversation_message_id: conversationMessageId || state.currentMessageId || null,
                chat_bucket: state.chatBox
            });
        }

        await Promise.all([
            loadStats(),
            loadConversations(),
            loadCallTracking(),
            state.view === 'leads' ? loadLeads() : Promise.resolve()
        ]);

        if (isCurrentChat && state.phone === phone) {
            await loadDetails(phone);
        }

        return res.data;
    } catch (e) {
        if (isCurrentChat) {
            state.callStatus = previousStatus;
            state.callCalledAt = previousCalledAt;
            state.callAttemptCount = previousAttempts;
            updateCallStatusUI();
        }
        window.alert('Call state update failed: ' + e.message);
        return null;
    } finally {
        if (isCurrentChat && select) select.disabled = !state.phone;
    }
}

async function addCallAttempt(phone, conversationMessageId = null) {
    if (!phone) return null;

    const isCurrentChat = state.phone === phone;
    const addBtn = $('addCallAttemptBtn');

    try {
        if (isCurrentChat && addBtn) addBtn.disabled = true;

        const res = await apiPost('call_attempt', {
            phone,
            conversation_message_id: conversationMessageId ? Number(conversationMessageId) : null
        });
        if (res.error) throw new Error(res.error);

        if (isCurrentChat) {
            if (res.data?.conversation_message_id) {
                state.currentMessageId = Number(res.data.conversation_message_id);
            }
            setCallStatusControls(res.data || {
                call_status: 'called',
                called_at: null,
                attempt_count: state.callAttemptCount + 1,
                conversation_message_id: conversationMessageId || state.currentMessageId || null,
                chat_bucket: state.chatBox
            });
        }

        await Promise.all([
            loadStats(),
            loadConversations(),
            loadCallTracking(),
            state.view === 'leads' ? loadLeads() : Promise.resolve()
        ]);

        if (isCurrentChat && state.phone === phone) {
            await loadDetails(phone);
        }

        return res.data;
    } catch (e) {
        window.alert('Attempt save failed: ' + e.message);
        return null;
    } finally {
        if (isCurrentChat) updateCallStatusUI();
    }
}

async function moveChats(phones, bucket) {
    const cleanPhones = Array.from(new Set(
        (phones || []).map(v => String(v || '').trim()).filter(Boolean)
    ));
    if (!cleanPhones.length) return null;

    try {
        const res = await apiPost('move_chats', {
            phones: cleanPhones,
            bucket
        });

        if (res.error) throw new Error(res.error);

        const movedCurrent = state.phone && cleanPhones.includes(state.phone);
        cleanPhones.forEach(phone => state.selectedPhones.delete(phone));

        if (movedCurrent) {
            state.phone = null;
            resetSelectedChatUI();
        }

        await Promise.all([
            loadStats(),
            loadConversations(),
            state.view === 'inbox' ? loadCallTracking() : Promise.resolve()
        ]);

        updateSelectionUI();
        return res.data;
    } catch (e) {
        window.alert('Move failed: ' + e.message);
        return null;
    }
}

let moveModalPhones = [];

function closeMoveChatModal() {
    const modal = $('moveChatModal');
    if (!modal) return;
    modal.classList.add('hidden');
    modal.setAttribute('aria-hidden', 'true');
    moveModalPhones = [];
}

function openMoveChatModal(phones, mode = 'selected') {
    const cleanPhones = Array.from(new Set(
        (phones || []).map(v => String(v || '').trim()).filter(Boolean)
    ));
    if (!cleanPhones.length) return;

    const modal = $('moveChatModal');
    const title = $('moveChatModalTitle');
    const sub = $('moveChatModalSub');
    if (!modal) return;

    moveModalPhones = cleanPhones;

    const count = cleanPhones.length;
    if (title) {
        title.textContent = mode === 'current' ? 'Move this chat' : 'Move selected chats';
    }
    if (sub) {
        sub.textContent = mode === 'current'
            ? 'Choose Inbox, Pending or Old.'
            : `Choose a destination for ${count} selected chat${count === 1 ? '' : 's'}.`;
    }

    modal.classList.remove('hidden');
    modal.setAttribute('aria-hidden', 'false');
}

async function moveSelectedChats() {
    const phones = Array.from(state.selectedPhones);
    if (!phones.length) return;
    openMoveChatModal(phones, 'selected');
}

async function moveCurrentChat() {
    if (!state.phone) return;
    openMoveChatModal([state.phone], 'current');
}

async function loadCallTracking() {
    const body = $('callTrackingBody');
    const count = $('callTrackingCount');
    if (!body || state.chatBox !== 'inbox') return;

    try {
        const res = await api('call_tracking', {
            ...state.filters,
            call_status: '',
            box: 'inbox'
        });

        if (res.error) {
            body.innerHTML = `<div class="empty"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        if (count) count.textContent = rows.length;

        if (!rows.length) {
            body.innerHTML = '<div class="empty"><div class="big">📞</div>No customers in the current Inbox</div>';
            return;
        }

        const counts = {
            not_called: rows.filter(r => normalizeCallState(r.call_status) === 'not_called').length,
            called: rows.filter(r => normalizeCallState(r.call_status) === 'called').length,
            rejected: rows.filter(r => normalizeCallState(r.call_status) === 'rejected').length,
            try_again: rows.filter(r => normalizeCallState(r.call_status) === 'try_again').length,
        };

        body.innerHTML = `
            <div class="call-stats-row">
                <div class="call-mini-stat"><b>${counts.not_called}</b><span>Not called</span></div>
                <div class="call-mini-stat"><b>${counts.called}</b><span>Called</span></div>
                <div class="call-mini-stat"><b>${counts.rejected}</b><span>Rejected</span></div>
                <div class="call-mini-stat"><b>${counts.try_again}</b><span>Try again</span></div>
                <div class="call-mini-stat"><b>${rows.length}</b><span>Total customers</span></div>
            </div>

            <table class="call-tracking-table">
                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Last WhatsApp</th>
                        <th>Messages</th>
                        <th>State</th>
                        <th>Attempts</th>
                        <th>Last called</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(r => {
                        const status = normalizeCallState(r.call_status);
                        const phone = String(r.customer_phone || '');
                        const normalized = normalizeWebPhone(phone);
                        const name = r.customer_name || phone || 'Unknown';
                        const preview = r.last_message_text || '—';

                        return `
                            <tr data-call-phone="${esc(phone)}">
                                <td>
                                    <div class="call-customer">
                                        <div class="avatar ${colorClass(phone)}">${esc(initials(r.customer_name, phone))}</div>
                                        <div>
                                            <div class="call-customer-name">${esc(name)}</div>
                                            <div class="call-customer-phone">${esc(phone)}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="call-message" title="${esc(preview)}">${esc(preview)}</div>
                                    <div class="conv-time" style="margin-top:3px">${esc(fmtFull(r.last_message_at))}</div>
                                </td>
                                <td>${esc(r.total_messages || 0)}</td>
                                <td>
                                    <span class="call-status-badge ${callStatusCssClass(status)}">${esc(callStatusLabel(status))}</span>
                                </td>
                                <td><b>${esc(r.attempt_count || 0)}</b></td>
                                <td>${esc(r.called_at ? fmtFull(r.called_at) : '—')}</td>
                                <td>
                                    <div class="call-actions">
                                        ${normalized ? `<a class="call-action-btn" href="tel:+${esc(normalized)}">📞 Call</a>` : ''}
                                        <button type="button" class="call-action-btn attempt-btn" data-row-attempt="${esc(phone)}" title="Add one call attempt">
                                            ＋ Attempt <span class="attempt-count-mini">${esc(Number(r.attempt_count || 0))}</span>
                                        </button>
                                        <select class="call-status-select" data-row-call-state="${esc(phone)}" aria-label="Call state">
                                            <option value="not_called" ${status === 'not_called' ? 'selected' : ''}>📞 Not called</option>
                                            <option value="called" ${status === 'called' ? 'selected' : ''}>✅ Called</option>
                                            <option value="rejected" ${status === 'rejected' ? 'selected' : ''}>🚫 Rejected</option>
                                            <option value="try_again" ${status === 'try_again' ? 'selected' : ''}>🔄 Try again</option>
                                        </select>
                                        <button type="button" class="call-action-btn" data-open-chat="${esc(phone)}">💬 Chat</button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;

        body.querySelectorAll('[data-row-attempt]').forEach(btn => {
            btn.addEventListener('click', async (event) => {
                event.stopPropagation();
                await addCallAttempt(btn.dataset.rowAttempt || '');
            });
        });

        body.querySelectorAll('[data-row-call-state]').forEach(select => {
            select.addEventListener('change', async (event) => {
                event.stopPropagation();
                await saveCallStatus(
                    select.dataset.rowCallState || '',
                    select.value || 'not_called'
                );
            });
        });

        body.querySelectorAll('[data-open-chat]').forEach(btn => {
            btn.addEventListener('click', (event) => {
                event.stopPropagation();
                const phone = btn.dataset.openChat || '';
                if (phone) selectConversation(phone);
            });
        });

    } catch (e) {
        body.innerHTML = `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

async function deleteCurrentChat() {
    if (!state.phone) {
        return;
    }

    const name =
        $('chatName').textContent || state.phone;

    const ok = window.confirm(
        `Delete this chat from the database?\n\n` +
        `${name}\n${state.phone}\n\n` +
        `This deletes local database records only. ` +
        `It does not delete the conversation from WhatsApp.`
    );

    if (!ok) {
        return;
    }

    const deletedPhone = state.phone;
    const deleteBtn = $('deleteChat');

    try {
        if (deleteBtn) {
            deleteBtn.disabled = true;
        }

        const res = await apiPost('delete_chats', {
            phones: [deletedPhone]
        });

        if (res.error) {
            throw new Error(res.error);
        }

        state.selectedPhones.delete(deletedPhone);
        state.phone = null;

        resetSelectedChatUI();

        await Promise.all([
            loadStats(),
            loadConversations(),
            loadCallTracking()
        ]);

        window.alert(
            `Deleted ${res.deleted_rows || 0} database rows.`
        );

    } catch (e) {

        window.alert('Delete failed: ' + e.message);
        if (deleteBtn) {
            deleteBtn.disabled = !state.phone;
        }
    }
}

async function deleteSelectedChats() {
    const phones =
        Array.from(state.selectedPhones);

    if (!phones.length) {
        return;
    }

    const ok = window.confirm(
        `Delete ${phones.length} selected chat` +
        `${phones.length === 1 ? '' : 's'} from the database?\n\n` +
        `This deletes local database records only. ` +
        `It does not delete conversations from WhatsApp.`
    );

    if (!ok) {
        return;
    }

    try {
        $('deleteSelected').disabled = true;

        const res = await apiPost('delete_chats', {
            phones
        });

        if (res.error) {
            throw new Error(res.error);
        }

        if (
            state.phone &&
            phones.includes(state.phone)
        ) {
            state.phone = null;
            resetSelectedChatUI();
        }

        state.selectedPhones.clear();

        await Promise.all([
            loadStats(),
            loadConversations()
        ]);

        updateComposerState();

        window.alert(
            `Deleted ${res.deleted_rows || 0} database rows.`
        );

    } catch (e) {

        window.alert('Delete failed: ' + e.message);
        updateSelectionUI();
    }
}

function normalizeWebPhone(phone) {
    let value = String(phone || '').trim();

    value = value.replace(/[^\d+]/g, '');

    if (value.startsWith('+')) {
        value = value.slice(1);
    }

    if (/^0\d{8,11}$/.test(value)) {
        value = '94' + value.slice(1);
    }

    return value.replace(/\D/g, '');
}

function openWhatsAppWeb(
    phone,
    message = ''
) {
    const normalized =
        normalizeWebPhone(phone);

    if (!normalized) {
        window.alert('Invalid phone number.');
        return;
    }

    const url =
        'https://web.whatsapp.com/send?phone=' +
        encodeURIComponent(normalized) +
        (
            message
                ? '&text=' + encodeURIComponent(message)
                : ''
        );

    window.open(
        url,
        '_blank',
        'noopener,noreferrer'
    );
}

function updateComposerState() {
    const composer = $('messageComposer');
    const oneBtn = $('sendOneBtn');
    const bulkBtn = $('sendSelectedBtn');
    const webBtn =
        $('openWhatsAppWebFromComposer');
    const webHeaderBtn =
        $('openWhatsAppWeb');
    const target = $('composerTarget');
    const deleteBtn = $('deleteChat');

    const text =
        String(composer?.value || '').trim();

    if (target) {
        target.textContent =
            state.phone || 'No chat selected';
    }

    if (oneBtn) {
        oneBtn.disabled =
            !state.phone || !text;
    }

    if (bulkBtn) {
        bulkBtn.disabled =
            state.selectedPhones.size === 0 ||
            !text;
    }

    if (webBtn) {
        webBtn.disabled = !state.phone;
    }

    if (webHeaderBtn) {
        webHeaderBtn.disabled = !state.phone;
    }

    if (deleteBtn) {
        deleteBtn.disabled = !state.phone;
    }

    updateSelectionUI();
    updateQuickReplyUI();
}

async function sendCurrentMessage() {
    if (!state.phone) {
        return;
    }

    const textarea = $('messageComposer');
    const message =
        String(textarea.value || '').trim();

    if (!message) {
        return;
    }

    const button = $('sendOneBtn');
    const original = button.textContent;

    try {

        button.disabled = true;
        button.textContent = 'Sending…';

        const res = await apiPost(
            'send_text',
            {
                phone: state.phone,
                message
            }
        );

        if (res.error) {
            throw new Error(res.error);
        }

        textarea.value = '';

        await Promise.all([
            loadMessages(state.phone),
            loadDetails(state.phone),
            loadConversations(),
            loadStats()
        ]);

        updateComposerState();

    } catch (e) {

        window.alert(
            'Message was not sent: ' +
            e.message +
            '\n\nIf the customer service window has expired, ' +
            'Meta may require an approved template instead of free-form text.'
        );

    } finally {

        button.textContent = original;
        updateComposerState();
    }
}

async function sendSelectedMessage() {
    const phones =
        Array.from(state.selectedPhones);

    const textarea = $('messageComposer');

    const message =
        String(textarea.value || '').trim();

    if (!phones.length || !message) {
        return;
    }

    const button = $('sendSelectedBtn');
    const original = button.textContent;

    const ok = window.confirm(
        `Send the same message to ${phones.length} ` +
        `selected chat${phones.length === 1 ? '' : 's'}?\n\n` +
        `Message:\n${message}`
    );

    if (!ok) {
        return;
    }

    try {

        button.disabled = true;
        button.textContent = 'Sending…';

        const res = await apiPost(
            'bulk_send_text',
            {
                phones,
                message
            }
        );

        if (res.error) {
            throw new Error(res.error);
        }

        const failedText = (res.failed || [])
            .map(item =>
                `${item.phone}: ${item.error}`
            )
            .join('\n');

        let summary =
            `Sent: ${res.sent_count || 0}\n` +
            `Failed: ${res.failed_count || 0}`;

        if (failedText) {
            summary +=
                '\n\nFailed details:\n' +
                failedText;
        }

        window.alert(summary);

        await Promise.all([
            loadConversations(),
            loadStats()
        ]);

        if (state.phone) {
            await loadMessages(state.phone);
        }

        textarea.value = '';
        updateComposerState();

    } catch (e) {

        window.alert(
            'Bulk send failed: ' +
            e.message +
            '\n\nFree-form Cloud API messages may require ' +
            'an active customer service window.'
        );

    } finally {

        button.textContent = original;
        updateComposerState();
    }
}

/* =========================================================================
   SELECT CONVERSATION
   ========================================================================= */
async function selectConversation(phone) {
    state.phone = phone;

    updateComposerState();

    $$('.conv').forEach(el => {
        el.classList.toggle('active', el.dataset.phone === phone);
    });

    await loadCallStatus(phone);

    await Promise.all([
        loadMessages(phone),
        loadDetails(phone)
    ]);
}

/* =========================================================================
   REFERRAL CARD
   ========================================================================= */
function referralCard(m) {
    if (!Number(m.has_referral) && !m.reference_code && !m.source_id && !m.ctwa_clid) {
        return '';
    }

    const title =
        m.content_title ||
        m.headline ||
        m.ad_body ||
        m.reference_code ||
        'Ad referral';

    const img = m.image_url || m.thumbnail_url;
    const imgUrl = safeUrl(img);

    return `
        <div class="ad-card">
            <div class="ad-top">📣 Ad Referral</div>
            ${imgUrl ? `
                <img class="ad-img"
                     src="${esc(imgUrl)}"
                     alt=""
                     loading="lazy"
                     onerror="this.style.display='none'">
            ` : ''}

            <div class="ad-body">
                <div class="ad-title">
                    ${esc(String(title).slice(0, 120))}
                </div>

                ${m.ad_body && m.ad_body !== title
                    ? `<div>${esc(String(m.ad_body).slice(0, 180))}</div>`
                    : ''}

                ${m.ref_media_type
                    ? `<div style="margin-top:6px;color:#64748b">Media: ${esc(m.ref_media_type)}</div>`
                    : ''}

                ${m.reference_code
                    ? `<div class="ref-chip">${esc(m.reference_code)}</div>`
                    : ''}
            </div>
        </div>
    `;
}

/* =========================================================================
   MESSAGES
   ========================================================================= */
async function loadMessages(phone) {
    const thread = $('thread');

    thread.innerHTML =
        '<div class="empty" style="margin:auto"><span class="spinner"></span></div>';

    try {
        const res = await api('messages', { phone });

        if (res.error) {
            thread.innerHTML =
                `<div class="empty" style="margin:auto"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        const head = rows[rows.length - 1] || {};
        state.currentMessageId = Number(head.id || 0) || null;

        $('chatAvatar').textContent =
            initials(head.customer_name, phone);

        $('chatAvatar').className =
            'avatar ' + colorClass(phone);

        $('chatName').textContent =
            head.customer_name || phone;

        $('chatSub').textContent =
            phone + ' · ' + rows.length + ' messages';

        if (head.call_status) {
            setCallStatusControls(head);
        }

        if (!rows.length) {
            thread.innerHTML =
                '<div class="empty" style="margin:auto"><div class="big">💬</div>No messages</div>';
            return;
        }

        thread.innerHTML = rows.map(m => {
            const dir =
                m.direction === 'outgoing'
                    ? 'outgoing'
                    : 'incoming';

            return `
                <div class="msg ${dir}">
                    <div class="bubble">
                        <div class="txt">${esc(m.message_text || '')}</div>

                        ${referralCard(m)}

                        <div class="meta">
                            <span>${esc(fmtDateTime(m.message_timestamp))}</span>
                            ${dir === 'outgoing' ? tickMark(m.status) : ''}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        thread.scrollTop = thread.scrollHeight;

    } catch (e) {
        thread.innerHTML =
            `<div class="empty" style="margin:auto"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

/* =========================================================================
   DETAILS
   ========================================================================= */
function kv(k, v, mono = false, link = false) {
    if (v === null || v === undefined || v === '') return '';

    if (link) {
        const url = safeUrl(v);

        if (!url) {
            return `<div class="kv"><span class="k">${esc(k)}</span>
                    <span class="v ${mono ? 'mono' : ''}">${esc(v)}</span></div>`;
        }

        return `<div class="kv">
                    <span class="k">${esc(k)}</span>
                    <span class="v ${mono ? 'mono' : ''}">
                        <a href="${esc(url)}" target="_blank" rel="noopener noreferrer">
                            ${esc(String(v).slice(0, 46))}${String(v).length > 46 ? '…' : ''}
                        </a>
                    </span>
                </div>`;
    }

    return `<div class="kv">
                <span class="k">${esc(k)}</span>
                <span class="v${mono ? ' mono' : ''}">${esc(v)}</span>
            </div>`;
}

async function loadDetails(phone) {
    const panel = $('detailsPanel');

    panel.innerHTML =
        '<div class="empty"><span class="spinner"></span></div>';

    try {
        const res = await api('referral', { phone });
        const r = res.data;

        if (!r) {
            panel.innerHTML =
                '<div class="empty"><div class="big">📋</div>No referral data for this chat</div>';
            return;
        }

        const raw = (() => {
            try {
                return JSON.stringify(
                    JSON.parse(r.raw_payload || '{}'),
                    null,
                    2
                );
            } catch {
                return r.raw_payload || '';
            }
        })();

        panel.innerHTML = `
            <div class="section">
                <h3>Contact</h3>
                ${kv('Name', r.customer_name)}
                ${kv('Phone', r.customer_phone, true)}
                ${kv('Message time', fmtFull(r.message_timestamp))}
                ${kv('Received', fmtFull(r.received_at))}
            </div>

            <div class="section">
                <h3>Normal Call</h3>
                ${kv('State', callStatusLabel(state.callStatus))}
                ${kv('Attempts', String(state.callAttemptCount || 0))}
                ${kv('Last called', state.callCalledAt ? fmtFull(state.callCalledAt) : 'Not called yet')}
                ${kv('Folder', state.chatBox === 'old' ? 'Old' : state.chatBox === 'pending' ? 'Pending' : 'Inbox')}
                ${kv('Action', 'Use “＋ Attempt” after each phone-call attempt. Use the state selector to keep the current call state.')}
            </div>

            <div class="section">
                <h3>Attribution</h3>
                ${kv('Reference', r.reference_code, true)}
                ${kv('Product', r.product_code)}
                ${kv('Source type', r.source_type)}
                ${kv('Platform', r.source_platform)}
                ${kv('Content title', r.content_title)}
            </div>

            <div class="section">
                <h3>Campaign</h3>
                ${kv('Campaign', r.campaign_name)}
                ${kv('Ad', r.ad_name)}
                ${kv('Creative', r.creative_name)}
                ${kv('Source ID', r.source_id, true)}
                ${kv('Source URL', r.source_url, false, true)}
            </div>

            <div class="section">
                <h3>Creative Content</h3>
                ${kv('Headline', r.headline)}
                ${kv('Body', r.body)}
                ${kv('Media type', r.media_type)}
                ${kv('Image', r.image_url, false, true)}
                ${kv('Video', r.video_url, false, true)}
                ${kv('Thumbnail', r.thumbnail_url, false, true)}
            </div>

            <div class="section">
                <h3>Click Tracking</h3>
                ${kv('CTWA CLID', r.ctwa_clid, true)}
                ${kv('Phone Number ID', r.phone_number_id, true)}
            </div>

            <div class="section">
                <details class="raw">
                    <summary>Raw webhook payload</summary>
                    <pre class="rawbox">${esc(raw)}</pre>
                </details>
            </div>
        `;

    } catch (e) {
        panel.innerHTML =
            `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

/* =========================================================================
   LEADS FILTERS + TABLE
   ========================================================================= */
const leadInputMap = {
    leadSearch:     'q',
    leadPlatform:   'platform',
    leadSourceType: 'source_type',
    leadProduct:    'product',
    leadReference:  'reference',
    leadCtwa:       'ctwa',
    leadCallStatus: 'call_status',
    leadDateFrom:   'date_from',
    leadDateTo:     'date_to',
    leadSort:       'sort',
};

function bindLeadFilters() {
    let timer = null;

    Object.entries(leadInputMap).forEach(([id, key]) => {
        const el = $(id);
        if (!el) return;

        const evt =
            (el.tagName === 'INPUT' && el.type !== 'date')
                ? 'input'
                : 'change';

        el.addEventListener(evt, () => {
            state.leadFilters[key] = el.value;

            clearTimeout(timer);

            timer = setTimeout(() => {
                loadLeads();
                renderLeadChips();
            }, evt === 'input' ? 250 : 0);
        });
    });

    $('leadChips').addEventListener('click', (e) => {
        if (e.target.closest('.chip.clear-all')) {
            clearAllLeadFilters();
        } else if (e.target.dataset.lclear) {
            const key = e.target.dataset.lclear;
            state.leadFilters[key] = '';

            const id = Object.keys(leadInputMap)
                .find(k => leadInputMap[k] === key);

            if (id && $(id)) {
                $(id).value = '';
            }

            loadLeads();
            renderLeadChips();
        }
    });
}

function clearAllLeadFilters() {
    Object.keys(state.leadFilters).forEach(k => {
        state.leadFilters[k] = k === 'sort' ? 'latest' : '';
    });

    Object.entries(leadInputMap).forEach(([id, key]) => {
        if ($(id)) {
            $(id).value = state.leadFilters[key] ?? '';
        }
    });

    loadLeads();
    renderLeadChips();
}

function renderLeadChips() {
    const labels = {
        q: 'Search',
        platform: 'Platform',
        source_type: 'Type',
        product: 'Product',
        reference: 'Ref',
        ctwa: 'CTWA',
        call_status: 'Call state',
        date_from: 'From',
        date_to: 'To',
    };

    const chips = [];

    Object.entries(state.leadFilters).forEach(([k, v]) => {
        if (!v || k === 'sort') return;

        const label = labels[k] || k;
        const val =
            k === 'ctwa'
                ? 'Has CLID'
                : k === 'call_status'
                    ? (v === 'attempted'
                        ? 'Attempted (Try again + Rejected)'
                        : callStatusLabel(v))
                    : v;

        chips.push(
            `<span class="chip">${esc(label)}: ${esc(val)}
                <button data-lclear="${esc(k)}" title="Remove">×</button>
             </span>`
        );
    });

    if (chips.length > 1) {
        chips.push(`<span class="chip clear-all">Clear all ×</span>`);
    }

    $('leadChips').innerHTML = chips.join('');
}

async function loadLeads() {
    const body = $('leadsBody');
    body.innerHTML =
        '<div class="empty"><span class="spinner"></span></div>';

    try {
        const res = await api('leads', state.leadFilters);

        if (res.error) {
            body.innerHTML =
                `<div class="empty"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        $('leadCount').textContent = rows.length;

        if (!rows.length) {
            body.innerHTML =
                '<div class="empty"><div class="big">🔍</div>No leads match filters</div>';
            return;
        }

        body.innerHTML = `
            <table class="leads">
                <thead>
                    <tr>
                        <th>Received</th>
                        <th>Customer</th>
                        <th>Message</th>
                        <th>Type / Source</th>
                        <th>Reference</th>
                        <th>Message ID</th>
                        <th>Product</th>
                        <th>Source</th>
                        <th>Platform</th>
                        <th>Content</th>
                        <th>Call status</th>
                        <th>Attempts</th>
                        <th>Last called</th>
                        <th>CTWA CLID</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(r => {
                        const phone = String(r.customer_phone || '');
                        const normalized = normalizeWebPhone(phone);
                        const status = normalizeCallState(r.call_status);
                        const attemptCount = Number(r.attempt_count || 0);

                        return `
                            <tr data-lead-phone="${esc(phone)}">
                                <td style="white-space:nowrap">
                                    ${esc(fmtDateTime(r.received_at || r.message_timestamp))}
                                </td>

                                <td>
                                    <div style="font-weight:600">
                                        ${esc(r.customer_name || '—')}
                                    </div>
                                    <div style="color:#64748b;font-size:11.5px">
                                        ${esc(phone)}
                                    </div>
                                </td>

                                <td style="max-width:260px">
                                    <div style="font-size:12px;color:#334155;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${esc(r.message_text || '')}">
                                        ${esc(String(r.message_text || '—').slice(0, 90))}
                                    </div>
                                    <div style="font-size:10.5px;color:#94a3b8;margin-top:3px">
                                        ${esc(r.direction === 'outgoing' ? 'Outgoing' : 'Incoming')}
                                    </div>
                                </td>

                                <td>
                                    <div>${esc(r.message_type || '—')}</div>
                                    <div style="font-size:10.5px;color:#64748b;margin-top:3px">${esc(r.message_source || '—')}</div>
                                </td>

                                <td>
                                    <code style="font-size:11.5px">
                                        ${esc(r.reference_code || '—')}
                                    </code>
                                </td>

                                <td><code style="font-size:10.5px;color:#64748b">${esc(r.message_id || '—')}</code></td>
                                <td>${esc(r.product_code || '—')}</td>
                                <td>${esc(r.source_type || '—')}</td>
                                <td>${esc(r.source_platform || '—')}</td>

                                <td style="max-width:260px">
                                    ${esc(String(r.content_title || r.headline || '—').slice(0, 70))}
                                </td>

                                <td>
                                    <span class="call-status-badge ${callStatusCssClass(status)}" title="Related message ID: ${esc(r.conversation_message_id ?? r.message_id ?? '—')}">
                                        ${esc(callStatusLabel(status))}
                                    </span>
                                </td>

                                <td>
                                    <div class="lead-attempt-cell" title="${esc(`Total call attempts: ${attemptCount}`)}">
                                        <span class="lead-attempt-badge">${esc(attemptCount)}</span>
                                        <span class="lead-attempt-label">
                                            ${attemptCount === 1 ? 'attempt' : 'attempts'}
                                        </span>
                                    </div>
                                </td>

                                <td style="white-space:nowrap">
                                    <div style="font-size:11px;color:#64748b">
                                        ${esc(r.called_at ? fmtDateTime(r.called_at) : '—')}
                                    </div>
                                </td>

                                <td>
                                    <code style="font-size:10.5px;color:#64748b">
                                        ${esc(String(r.ctwa_clid || '—').slice(0, 18))}
                                    </code>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;

    } catch (e) {
        body.innerHTML =
            `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}

/* =========================================================================
   REFERENCE ANALYSIS
   ========================================================================= */
async function openReferenceAnalysis() {
    $('referenceModal').classList.remove('hidden');

    $('referenceAnalysisBody').innerHTML =
        '<div class="empty"><span class="spinner"></span></div>';

    try {

        const res = await api(
            'reference_analysis',
            state.leadFilters
        );

        if (res.error) {
            throw new Error(res.error);
        }

        const summary = res.summary || {};

        $('raMessages').textContent =
            summary.referral_messages ?? 0;

        $('raCustomers').textContent =
            summary.unique_customers ?? 0;

        $('raReferences').textContent =
            summary.unique_references ?? 0;

        const rows = res.data || [];

        if (!rows.length) {
            $('referenceAnalysisBody').innerHTML =
                '<div class="empty">' +
                '<div class="big">🔍</div>' +
                'No reference data matches the current filters.' +
                '</div>';
            return;
        }

        $('referenceAnalysisBody').innerHTML = `
            <table class="analysis-table">
                <thead>
                    <tr>
                        <th>Reference</th>
                        <th>Messages</th>
                        <th>Customers</th>
                        <th>Product</th>
                        <th>Type</th>
                        <th>Platform</th>
                        <th>Last seen</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(r => `
                        <tr>
                            <td>
                                <span class="ref-code">
                                    ${esc(r.reference_code || '—')}
                                </span>
                            </td>
                            <td>${esc(r.message_count || 0)}</td>
                            <td>${esc(r.customer_count || 0)}</td>
                            <td>${esc(r.products || '—')}</td>
                            <td>${esc(r.source_types || '—')}</td>
                            <td>${esc(r.platforms || '—')}</td>
                            <td style="white-space:nowrap">
                                ${esc(fmtDateTime(r.last_seen))}
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;

    } catch (e) {

        $('referenceAnalysisBody').innerHTML =
            `<div class="empty">
                <div class="big">⚠️</div>
                ${esc(e.message)}
             </div>`;
    }
}

function closeReferenceAnalysis() {
    $('referenceModal')
        .classList.add('hidden');
}

/* =========================================================================
   NEW ACTION BINDINGS
   ========================================================================= */
$('messageComposer').addEventListener(
    'input',
    updateComposerState
);

$('quickReplySelect').addEventListener(
    'change',
    updateQuickReplyUI
);

$('useQuickReplyBtn').addEventListener(
    'click',
    useQuickReply
);

$('sendQuickReplyBtn').addEventListener(
    'click',
    sendQuickReply
);

$('sendOneBtn').addEventListener(
    'click',
    sendCurrentMessage
);

$('sendSelectedBtn').addEventListener(
    'click',
    sendSelectedMessage
);

$('messageComposer').addEventListener(
    'keydown',
    (event) => {
        if (
            (event.ctrlKey || event.metaKey) &&
            event.key === 'Enter'
        ) {
            event.preventDefault();

            if (state.selectedPhones.size > 1) {
                sendSelectedMessage();
            } else {
                sendCurrentMessage();
            }
        }
    }
);

$('openWhatsAppWeb').addEventListener(
    'click',
    () => {
        openWhatsAppWeb(
            state.phone,
            $('messageComposer').value || ''
        );
    }
);

$('openWhatsAppWebFromComposer').addEventListener(
    'click',
    () => {
        openWhatsAppWeb(
            state.phone,
            $('messageComposer').value || ''
        );
    }
);

$('deleteChat').addEventListener(
    'click',
    deleteCurrentChat
);

$('deleteSelected').addEventListener(
    'click',
    deleteSelectedChats
);

$('selectAllVisible').addEventListener(
    'click',
    selectAllVisibleChats
);

$('referenceAnalysisBtn').addEventListener(
    'click',
    openReferenceAnalysis
);

$('closeReferenceModal').addEventListener(
    'click',
    closeReferenceAnalysis
);

$('referenceModalBackdrop').addEventListener(
    'click',
    closeReferenceAnalysis
);

$('chatCallStatus').addEventListener(
    'change',
    () => {
        if (!state.phone) return;
        saveCallStatus(
            state.phone,
            $('chatCallStatus').value || 'not_called',
            state.currentMessageId
        );
    }
);

$('addCallAttemptBtn').addEventListener(
    'click',
    () => {
        if (state.phone) addCallAttempt(state.phone, state.currentMessageId);
    }
);

$('moveSelected').addEventListener(
    'click',
    () => moveSelectedChats()
);

$('moveChatBtn').addEventListener(
    'click',
    () => moveCurrentChat()
);

$('closeMoveChatModal').addEventListener(
    'click',
    closeMoveChatModal
);

$('moveChatModalBackdrop').addEventListener(
    'click',
    closeMoveChatModal
);

$$('[data-move-target]').forEach(btn => {
    btn.addEventListener('click', async () => {
        const target = btn.dataset.moveTarget || '';
        if (!['inbox', 'pending', 'old'].includes(target)) return;
        if (!moveModalPhones.length) return;

        const labels = {
            inbox: 'Inbox',
            pending: 'Pending',
            old: 'Old'
        };

        const phones = [...moveModalPhones];
        const ok = window.confirm(
            `Move ${phones.length} selected chat${phones.length === 1 ? '' : 's'} to ${labels[target]}?\n\n` +
            `All WhatsApp messages and contact details will remain in the database.`
        );
        if (!ok) return;

        closeMoveChatModal();
        await moveChats(phones, target);
    });
});

const installAppBtn = $('installAppBtn');
if (installAppBtn) {
    installAppBtn.addEventListener('click', promptInstallApp);
}

$('refreshCallTracking').addEventListener(
    'click',
    () => loadCallTracking()
);

/* =========================================================================
   VIEW SWITCH
   ========================================================================= */
$$('.tab').forEach(tab => {
    tab.addEventListener('click', async () => {
        $$('.tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        state.view = tab.dataset.view;

        if (state.view === 'leads') {
            $('inboxView').classList.add('hidden');
            $('leadsView').classList.remove('hidden');
            $('callTrackingPanel').classList.add('hidden');
            return loadLeads();
        }

        $('inboxView').classList.remove('hidden');
        $('leadsView').classList.add('hidden');
        $('callTrackingPanel').classList.toggle('hidden', state.view !== 'inbox');

        state.chatBox = ['inbox', 'pending', 'old'].includes(state.view)
            ? state.view
            : 'inbox';
        $('conversationsTitle').textContent = state.chatBox === 'old'
            ? 'Old Conversations'
            : state.chatBox === 'pending'
                ? 'Pending Conversations'
                : 'Inbox Conversations';

        state.selectedPhones.clear();
        state.phone = null;
        resetSelectedChatUI();
        await loadConversations();
        updateSelectionUI();
    });
});

async function autoReplyNewContactsInBackground() {
    try {
        await apiPost('auto_reply_new_contacts');
    } catch (e) {
        console.warn('New-contact auto-reply failed:', e);
    }
}

/* =========================================================================
   AUTO REFRESH
   ========================================================================= */
$('autoBtn').addEventListener('click', () => {
    state.auto = !state.auto;
    $('autoBtn').classList.toggle('on', state.auto);
    setupAutoRefresh();
});

function setupAutoRefresh() {
    clearInterval(state.timer);

    if (!state.auto) return;

    state.timer = setInterval(() => {
        autoReplyNewContactsInBackground();
        loadStats();

        if (state.view === 'leads') {
            loadLeads();
        } else {
            loadConversations();
            if (state.view === 'inbox') loadCallTracking();

            if (state.phone) {
                loadMessages(state.phone);
            }
        }
    }, 8000);
}

/* =========================================================================
   BOOT
   ========================================================================= */
async function boot() {
    bindInboxFilters();
    bindLeadFilters();

    if ('serviceWorker' in navigator) {
        try {
            await navigator.serviceWorker.register('?action=sw.js', { scope: './' });
        } catch (e) {
            console.warn('service worker registration failed', e);
        }
    }

    await loadStats();
    await loadFilterOptions();
    state.chatBox = 'inbox';
    $('conversationsTitle').textContent = 'Inbox Conversations';
    await loadConversations();

    populateQuickReplies();
    autoReplyNewContactsInBackground();
    renderFilterChips();
    renderLeadChips();
    updateComposerState();
    setupAutoRefresh();
}

boot();
</script>

</body>
</html>

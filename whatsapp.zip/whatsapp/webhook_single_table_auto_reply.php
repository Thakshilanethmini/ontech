<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';


/*
|--------------------------------------------------------------------------
| HELPER: WRITE WEBHOOK LOG
|--------------------------------------------------------------------------
*/
function writeWebhookLog(string $title, $data): void
{
    $logFile = __DIR__ . '/webhook_log.txt';

    $content =
        "\n" .
        date('Y-m-d H:i:s') . PHP_EOL .
        $title . PHP_EOL .
        json_encode(
            $data,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        ) .
        PHP_EOL .
        "==============================" .
        PHP_EOL;

    file_put_contents(
        $logFile,
        $content,
        FILE_APPEND | LOCK_EX
    );
}


/*
|--------------------------------------------------------------------------
| HELPER: CLEAN NULLABLE STRING
|--------------------------------------------------------------------------
*/
function cleanNullableString($value): ?string
{
    if ($value === null) {
        return null;
    }

    $value = trim((string)$value);

    return $value === '' ? null : $value;
}


/*
|--------------------------------------------------------------------------
| AUTO REPLY: DUPLICATE-PROTECTION LOG TABLE
|--------------------------------------------------------------------------
| One first-contact auto reply is allowed per incoming WhatsApp message ID.
| This prevents duplicate webhook deliveries from sending the reply twice.
|--------------------------------------------------------------------------
*/
function ensureAutoReplyLogTable(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS whatsapp_auto_reply_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            trigger_message_id VARCHAR(191) NOT NULL,
            customer_phone VARCHAR(32) NOT NULL,
            status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
            sent_message_id VARCHAR(191) NULL,
            error_message TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_auto_reply_trigger (trigger_message_id),
            KEY idx_auto_reply_phone (customer_phone),
            KEY idx_auto_reply_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
}


/*
|--------------------------------------------------------------------------
| AUTO REPLY: LANGUAGE DETECTION
|--------------------------------------------------------------------------
| Sinhala-script messages receive the Sinhala reply. Other messages receive
| the English reply. Singlish written with Latin characters is treated as
| English here.
|--------------------------------------------------------------------------
*/
function detectAutoReplyLanguage(?string $messageText): string
{
    if ($messageText && preg_match('/[\x{0D80}-\x{0DFF}]/u', $messageText)) {
        return 'si';
    }

    return 'en';
}


/*
|--------------------------------------------------------------------------
| AUTO REPLY: SEND TEXT THROUGH WHATSAPP CLOUD API
|--------------------------------------------------------------------------
*/
function sendAutoReplyText(
    PDO $pdo,
    string $to,
    string $text,
    ?string $customerName,
    ?string $sendPhoneNumberId = null
): array {
    global $accessToken, $phoneNumberId, $graphApiVersion;

    if (!isset($accessToken) || trim((string)$accessToken) === '') {
        throw new RuntimeException('WhatsApp access token is not configured.');
    }

    $sendPhoneNumberId = trim((string)($sendPhoneNumberId ?: ($phoneNumberId ?? '')));
    if ($sendPhoneNumberId === '') {
        throw new RuntimeException('WhatsApp phone number ID is not configured.');
    }

    $to = preg_replace('/\D+/', '', $to) ?? '';
    $text = trim($text);

    if ($to === '') {
        throw new RuntimeException('Invalid auto-reply recipient phone number.');
    }

    if ($text === '') {
        throw new RuntimeException('Auto-reply message is empty.');
    }

    $version = trim((string)($graphApiVersion ?? 'v23.0')) ?: 'v23.0';

    $url =
        'https://graph.facebook.com/' .
        rawurlencode($version) . '/' .
        rawurlencode($sendPhoneNumberId) .
        '/messages';

    $payload = [
        'messaging_product' => 'whatsapp',
        'recipient_type'    => 'individual',
        'to'                => $to,
        'type'              => 'text',
        'text'              => [
            'preview_url' => false,
            'body'        => $text,
        ],
    ];

    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER  => true,
        CURLOPT_HTTPHEADER      => [
            'Authorization: Bearer ' . (string)$accessToken,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS      => json_encode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        ),
        CURLOPT_CONNECTTIMEOUT  => 15,
        CURLOPT_TIMEOUT         => 30,
    ]);

    $body = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    if ($body === false) {
        throw new RuntimeException('Auto-reply Graph API connection failed: ' . $curlError);
    }

    $data = json_decode($body, true);

    if (!is_array($data)) {
        throw new RuntimeException('Auto-reply Graph API returned invalid JSON. HTTP ' . $httpCode);
    }

    if ($httpCode < 200 || $httpCode >= 300 || isset($data['error'])) {
        $message = $data['error']['message'] ?? 'Unknown Graph API error';
        $code = $data['error']['code'] ?? $httpCode;
        throw new RuntimeException('Auto-reply WhatsApp API error [' . $code . ']: ' . $message);
    }

    $messageId = $data['messages'][0]['id'] ?? null;
    if (!$messageId) {
        throw new RuntimeException('Auto-reply API response did not contain a message ID.');
    }

    $timestamp = date('Y-m-d H:i:s');

    $stmt = $pdo->prepare("\n        INSERT INTO whatsapp_conversation_messages (\n            whatsapp_message_id,\n            customer_phone,\n            customer_name,\n            direction,\n            message_type,\n            message_text,\n            message_source,\n            has_referral,\n            status,\n            phone_number_id,\n            message_timestamp,\n            received_at,\n            raw_payload\n        )\n        VALUES (\n            :message_id,\n            :customer_phone,\n            :customer_name,\n            'outgoing',\n            'text',\n            :message_text,\n            'Auto Reply',\n            0,\n            'sent',\n            :phone_number_id,\n            :message_timestamp,\n            :received_at,\n            :raw_payload\n        )\n        ON DUPLICATE KEY UPDATE\n            customer_name = COALESCE(VALUES(customer_name), customer_name),\n            message_text = VALUES(message_text),\n            status = VALUES(status),\n            updated_at = CURRENT_TIMESTAMP\n    ");

    $stmt->execute([
        ':message_id'        => $messageId,
        ':customer_phone'    => $to,
        ':customer_name'     => $customerName,
        ':message_text'      => $text,
        ':phone_number_id'   => $sendPhoneNumberId,
        ':message_timestamp' => $timestamp,
        ':received_at'       => $timestamp,
        ':raw_payload'       => json_encode([
            'source' => 'auto_reply',
            'api_response' => $data,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ]);

    return [
        'to' => $to,
        'message_id' => $messageId,
        'status' => 'sent',
    ];
}


/*
|--------------------------------------------------------------------------
| HELPER: EXTRACT REF FROM MESSAGE
|--------------------------------------------------------------------------
|
| Example:
| Hi, I need ERP Demo Details.
| [REF:ERP-VIDEO-01]
|
| Returns:
| reference_code = ERP-VIDEO-01
| product_code   = ERP
| source_type    = Video
|
|--------------------------------------------------------------------------
*/
function extractReferenceData(?string $messageText): array
{
    $result = [
        'reference_code' => null,
        'product_code'   => null,
        'source_type'    => null,
    ];

    if (!$messageText) {
        return $result;
    }

    if (preg_match('/\[REF\s*:\s*([A-Z0-9_-]+)\]/i', $messageText, $matches)) {
        $referenceCode = strtoupper(trim($matches[1]));

        $result['reference_code'] = $referenceCode;

        $parts = explode('-', $referenceCode);

        if (!empty($parts[0])) {
            $result['product_code'] = strtoupper(trim($parts[0]));
        }

        if (!empty($parts[1])) {
            $type = strtoupper(trim($parts[1]));

            switch ($type) {
                case 'VIDEO':
                case 'VID':
                    $result['source_type'] = 'Video';
                    break;

                case 'FLYER':
                case 'FLY':
                    $result['source_type'] = 'Flyer';
                    break;

                case 'IMAGE':
                case 'IMG':
                    $result['source_type'] = 'Image';
                    break;

                case 'AD':
                    $result['source_type'] = 'Ad';
                    break;

                case 'POST':
                    $result['source_type'] = 'Post';
                    break;

                default:
                    $result['source_type'] = ucfirst(strtolower($type));
                    break;
            }
        }
    }

    return $result;
}


/*
|--------------------------------------------------------------------------
| HELPER: DETECT SOURCE PLATFORM
|--------------------------------------------------------------------------
*/
function detectSourcePlatform(?string $sourceUrl): ?string
{
    if (!$sourceUrl) {
        return null;
    }

    $host = strtolower(
        (string)(parse_url($sourceUrl, PHP_URL_HOST) ?? '')
    );

    if (
        strpos($host, 'facebook.com') !== false ||
        strpos($host, 'fb.com') !== false
    ) {
        return 'Facebook';
    }

    if (strpos($host, 'instagram.com') !== false) {
        return 'Instagram';
    }

    return null;
}


/*
|--------------------------------------------------------------------------
| HELPER: DETERMINE MESSAGE SOURCE
|--------------------------------------------------------------------------
|
| - Normal Chat
| - Ad - Video
| - Ad - Flyer/Image
| - Ad - <source_type>
|
| A REF code alone is also treated as attributed/referral content. This is
| useful when the customer message contains [REF:...] but Meta referral data
| is not present in that specific payload.
|--------------------------------------------------------------------------
*/
function determineMessageSource(
    array $referral,
    ?string $mediaType,
    ?string $sourceType,
    ?string $referenceCode
): string {
    $hasReferral = !empty($referral) || !empty($referenceCode);

    if (!$hasReferral) {
        return 'Normal Chat';
    }

    $mediaType = strtolower(trim((string)$mediaType));

    if ($mediaType === 'video') {
        return 'Ad - Video';
    }

    if ($mediaType === 'image') {
        return 'Ad - Flyer/Image';
    }

    return 'Ad - ' . ($sourceType ?: 'Unknown');
}


/*
|--------------------------------------------------------------------------
| 1. META WEBHOOK VERIFICATION
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $mode      = (string)($_GET['hub_mode'] ?? '');
    $token     = (string)($_GET['hub_verify_token'] ?? '');
    $challenge = (string)($_GET['hub_challenge'] ?? '');

    if (
        $mode === 'subscribe' &&
        isset($verifyToken) &&
        hash_equals((string)$verifyToken, $token)
    ) {
        http_response_code(200);
        echo $challenge;
        exit;
    }

    http_response_code(403);
    echo 'Verification failed';
    exit;
}


/*
|--------------------------------------------------------------------------
| 2. ONLY POST ALLOWED
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: GET, POST');
    echo 'Method Not Allowed';
    exit;
}


/*
|--------------------------------------------------------------------------
| 3. READ RAW JSON
|--------------------------------------------------------------------------
*/
$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);


/*
|--------------------------------------------------------------------------
| 4. VALIDATE JSON
|--------------------------------------------------------------------------
*/
if (!is_array($data)) {
    http_response_code(400);
    echo 'Invalid JSON';
    exit;
}


/*
|--------------------------------------------------------------------------
| 5. LOG EVERY RAW WEBHOOK
|--------------------------------------------------------------------------
*/
writeWebhookLog('WHATSAPP WEBHOOK', $data);


/*
|--------------------------------------------------------------------------
| 6. CHECK WHATSAPP OBJECT
|--------------------------------------------------------------------------
*/
if (
    !isset($data['object']) ||
    $data['object'] !== 'whatsapp_business_account'
) {
    http_response_code(200);
    echo 'EVENT_RECEIVED';
    exit;
}


/*
|--------------------------------------------------------------------------
| 7. VALIDATE PDO
|--------------------------------------------------------------------------
*/
if (!isset($pdo) || !($pdo instanceof PDO)) {
    writeWebhookLog('WEBHOOK ERROR', [
        'error' => 'PDO connection ($pdo) not found in config.php'
    ]);

    http_response_code(500);
    echo 'Database connection unavailable';
    exit;
}


try {
    // Safe to run on each webhook request; CREATE TABLE IF NOT EXISTS is idempotent.
    ensureAutoReplyLogTable($pdo);

    /*
    |----------------------------------------------------------------------
    | 8. PROCESS ENTRIES
    |----------------------------------------------------------------------
    */
    foreach ($data['entry'] ?? [] as $entry) {

        foreach ($entry['changes'] ?? [] as $change) {

            if (($change['field'] ?? '') !== 'messages') {
                continue;
            }

            $value = $change['value'] ?? [];

            if (!is_array($value)) {
                continue;
            }

            /* -------------------------------------------------------------
               COMMON DATA
            ------------------------------------------------------------- */
            $webhookPhoneNumberId =
                $value['metadata']['phone_number_id']
                ?? ($phoneNumberId ?? null);


            /* -------------------------------------------------------------
               CUSTOMER NAME
            ------------------------------------------------------------- */
            $customerName = null;

            if (!empty($value['contacts'][0]['profile']['name'])) {
                $customerName =
                    cleanNullableString($value['contacts'][0]['profile']['name']);
            }


            /* =============================================================
               A) INCOMING MESSAGES
            ============================================================= */
            $messages = $value['messages'] ?? [];

            foreach ($messages as $message) {

                if (!is_array($message)) {
                    continue;
                }

                /* ---------------------------------------------------------
                   CUSTOMER PHONE
                --------------------------------------------------------- */
                $customerPhone =
                    cleanNullableString($message['from'] ?? null);


                /* ---------------------------------------------------------
                   MESSAGE ID
                --------------------------------------------------------- */
                $messageId =
                    cleanNullableString($message['id'] ?? null);


                /* ---------------------------------------------------------
                   MESSAGE TYPE
                --------------------------------------------------------- */
                $messageType =
                    cleanNullableString($message['type'] ?? 'unknown') ?? 'unknown';


                /* ---------------------------------------------------------
                   MESSAGE TEXT
                --------------------------------------------------------- */
                $messageText = null;

                if (
                    $messageType === 'text' &&
                    isset($message['text']['body'])
                ) {
                    $messageText =
                        cleanNullableString($message['text']['body']);
                }


                /* ---------------------------------------------------------
                   NON-TEXT MESSAGE LABELS
                --------------------------------------------------------- */
                if ($messageText === null) {
                    switch ($messageType) {
                        case 'image':
                            $messageText = '[Image]';
                            break;

                        case 'video':
                            $messageText = '[Video]';
                            break;

                        case 'audio':
                            $messageText = '[Audio]';
                            break;

                        case 'document':
                            $messageText = '[Document]';
                            break;

                        case 'sticker':
                            $messageText = '[Sticker]';
                            break;

                        case 'location':
                            $messageText = '[Location]';
                            break;

                        case 'contacts':
                            $messageText = '[Contact]';
                            break;

                        default:
                            $messageText = '[' . $messageType . ']';
                            break;
                    }
                }


                /* ---------------------------------------------------------
                   MESSAGE TIMESTAMP
                --------------------------------------------------------- */
                $timestamp =
                    (int)($message['timestamp'] ?? time());

                $messageDate =
                    date('Y-m-d H:i:s', $timestamp);


                /* ---------------------------------------------------------
                   REFERRAL DATA FROM META
                --------------------------------------------------------- */
                $referral =
                    isset($message['referral']) &&
                    is_array($message['referral'])
                        ? $message['referral']
                        : [];

                $sourceId =
                    cleanNullableString($referral['source_id'] ?? null);

                $sourceUrl =
                    cleanNullableString($referral['source_url'] ?? null);

                $metaSourceType =
                    cleanNullableString($referral['source_type'] ?? null);

                $headline =
                    cleanNullableString($referral['headline'] ?? null);

                $body =
                    cleanNullableString($referral['body'] ?? null);

                $mediaType =
                    cleanNullableString($referral['media_type'] ?? null);

                $imageUrl =
                    cleanNullableString($referral['image_url'] ?? null);

                $videoUrl =
                    cleanNullableString($referral['video_url'] ?? null);

                $thumbnailUrl =
                    cleanNullableString($referral['thumbnail_url'] ?? null);

                $ctwaClid =
                    cleanNullableString($referral['ctwa_clid'] ?? null);


                /* ---------------------------------------------------------
                   OWN REF CODE
                --------------------------------------------------------- */
                $referenceData =
                    extractReferenceData($messageText);

                $referenceCode =
                    $referenceData['reference_code'];

                $productCode =
                    $referenceData['product_code'];

                $sourceType =
                    $referenceData['source_type']
                    ?? $metaSourceType;


                /* ---------------------------------------------------------
                   DETECT PLATFORM
                --------------------------------------------------------- */
                $sourcePlatform =
                    detectSourcePlatform($sourceUrl);


                /* ---------------------------------------------------------
                   MESSAGE SOURCE
                --------------------------------------------------------- */
                $messageSource =
                    determineMessageSource(
                        $referral,
                        $mediaType,
                        $sourceType,
                        $referenceCode
                    );


                /* ---------------------------------------------------------
                   HAS REFERRAL
                --------------------------------------------------------- */
                $hasReferral =
                    (!empty($referral) || !empty($referenceCode)) ? 1 : 0;


                /* ---------------------------------------------------------
                   CONTENT TITLE
                --------------------------------------------------------- */
                $contentTitle =
                    cleanNullableString($headline);

                if (!$contentTitle && $body) {
                    $contentTitle =
                        cleanNullableString($body);
                }

                if (!$contentTitle && $referenceCode) {
                    $contentTitle = $referenceCode;
                }


                /* ---------------------------------------------------------
                   CAMPAIGN / AD / CREATIVE
                   These are intentionally NULL unless separately mapped.
                --------------------------------------------------------- */
                $campaignName = null;
                $adName       = null;
                $creativeName = null;


                /* =========================================================
                   SAVE EVERYTHING INTO ONE TABLE
                ========================================================= */
                if ($customerPhone && $messageId) {

                    $conversationSql = "
                        INSERT INTO whatsapp_conversation_messages (
                            whatsapp_message_id,
                            customer_phone,
                            customer_name,
                            direction,
                            message_type,
                            message_text,
                            message_source,
                            has_referral,

                            reference_code,
                            product_code,
                            source_platform,
                            campaign_name,
                            ad_name,
                            creative_name,
                            content_title,

                            source_id,
                            source_url,
                            source_type,
                            headline,
                            body,
                            media_type,
                            image_url,
                            video_url,
                            thumbnail_url,
                            ctwa_clid,

                            phone_number_id,
                            message_timestamp,
                            received_at,
                            raw_payload
                        )
                        VALUES (
                            :whatsapp_message_id,
                            :customer_phone,
                            :customer_name,
                            'incoming',
                            :message_type,
                            :message_text,
                            :message_source,
                            :has_referral,

                            :reference_code,
                            :product_code,
                            :source_platform,
                            :campaign_name,
                            :ad_name,
                            :creative_name,
                            :content_title,

                            :source_id,
                            :source_url,
                            :source_type,
                            :headline,
                            :body,
                            :media_type,
                            :image_url,
                            :video_url,
                            :thumbnail_url,
                            :ctwa_clid,

                            :phone_number_id,
                            :message_timestamp,
                            :received_at,
                            :raw_payload
                        )
                        ON DUPLICATE KEY UPDATE
                            customer_name =
                                COALESCE(VALUES(customer_name), customer_name),

                            message_text =
                                COALESCE(VALUES(message_text), message_text),

                            message_type =
                                COALESCE(VALUES(message_type), message_type),

                            message_source =
                                COALESCE(VALUES(message_source), message_source),

                            has_referral =
                                GREATEST(has_referral, VALUES(has_referral)),

                            reference_code =
                                COALESCE(VALUES(reference_code), reference_code),

                            product_code =
                                COALESCE(VALUES(product_code), product_code),

                            source_platform =
                                COALESCE(VALUES(source_platform), source_platform),

                            campaign_name =
                                COALESCE(VALUES(campaign_name), campaign_name),

                            ad_name =
                                COALESCE(VALUES(ad_name), ad_name),

                            creative_name =
                                COALESCE(VALUES(creative_name), creative_name),

                            content_title =
                                COALESCE(VALUES(content_title), content_title),

                            source_id =
                                COALESCE(VALUES(source_id), source_id),

                            source_url =
                                COALESCE(VALUES(source_url), source_url),

                            source_type =
                                COALESCE(VALUES(source_type), source_type),

                            headline =
                                COALESCE(VALUES(headline), headline),

                            body =
                                COALESCE(VALUES(body), body),

                            media_type =
                                COALESCE(VALUES(media_type), media_type),

                            image_url =
                                COALESCE(VALUES(image_url), image_url),

                            video_url =
                                COALESCE(VALUES(video_url), video_url),

                            thumbnail_url =
                                COALESCE(VALUES(thumbnail_url), thumbnail_url),

                            ctwa_clid =
                                COALESCE(VALUES(ctwa_clid), ctwa_clid),

                            phone_number_id =
                                COALESCE(VALUES(phone_number_id), phone_number_id),

                            received_at =
                                COALESCE(received_at, VALUES(received_at)),

                            updated_at =
                                CURRENT_TIMESTAMP
                    ";

                    $stmt = $pdo->prepare($conversationSql);

                    $stmt->execute([
                        ':whatsapp_message_id' => $messageId,
                        ':customer_phone'      => $customerPhone,
                        ':customer_name'       => $customerName,
                        ':message_type'        => $messageType,
                        ':message_text'       => $messageText,
                        ':message_source'     => $messageSource,
                        ':has_referral'       => $hasReferral,

                        ':reference_code'     => $referenceCode,
                        ':product_code'       => $productCode,
                        ':source_platform'    => $sourcePlatform,
                        ':campaign_name'      => $campaignName,
                        ':ad_name'            => $adName,
                        ':creative_name'      => $creativeName,
                        ':content_title'      => $contentTitle,

                        ':source_id'          => $sourceId,
                        ':source_url'         => $sourceUrl,
                        ':source_type'        => $sourceType,
                        ':headline'           => $headline,
                        ':body'               => $body,
                        ':media_type'         => $mediaType,
                        ':image_url'          => $imageUrl,
                        ':video_url'          => $videoUrl,
                        ':thumbnail_url'      => $thumbnailUrl,
                        ':ctwa_clid'          => $ctwaClid,

                        ':phone_number_id'    => $webhookPhoneNumberId,
                        ':message_timestamp' => $messageDate,
                        ':received_at'        => $messageDate,
                        ':raw_payload'       => $rawInput,
                    ]);
                }


                /* ---------------------------------------------------------
                   LOG INCOMING MESSAGE
                --------------------------------------------------------- */
                writeWebhookLog(
                    'INCOMING MESSAGE SAVED',
                    [
                        'customer_phone'   => $customerPhone,
                        'customer_name'    => $customerName,
                        'message_id'       => $messageId,
                        'message_type'     => $messageType,
                        'message_text'     => $messageText,
                        'message_source'   => $messageSource,
                        'has_referral'     => $hasReferral,
                        'reference_code'   => $referenceCode,
                        'product_code'     => $productCode,
                        'source_platform'  => $sourcePlatform,
                        'source_type'      => $sourceType,
                        'ctwa_clid'        => $ctwaClid,
                        'direction'        => 'incoming',
                    ]
                );

                /* ---------------------------------------------------------
                   AUTO REPLY FOR A NEW CONTACT
                   - Only the first incoming message from a contact triggers it.
                   - Duplicate webhook deliveries are blocked by the unique log.
                   - Reply is bilingual (English + Sinhala).
                --------------------------------------------------------- */
                if ($customerPhone && $messageId) {

                    $previousIncomingStmt = $pdo->prepare("
                        SELECT COUNT(*)
                        FROM whatsapp_conversation_messages
                        WHERE customer_phone = :phone
                          AND direction = 'incoming'
                          AND whatsapp_message_id <> :message_id
                    ");
                    $previousIncomingStmt->execute([
                        ':phone' => $customerPhone,
                        ':message_id' => $messageId,
                    ]);

                    $isNewContact = ((int)$previousIncomingStmt->fetchColumn() === 0);

                    if ($isNewContact) {

                        /* -------------------------------------------------
                           CLAIM THIS TRIGGER MESSAGE BEFORE SENDING.
                           INSERT IGNORE makes the operation idempotent when
                           Meta delivers the same webhook more than once.
                        ------------------------------------------------- */
                        $claimStmt = $pdo->prepare("
                            INSERT IGNORE INTO whatsapp_auto_reply_log (
                                trigger_message_id,
                                customer_phone,
                                status
                            )
                            VALUES (
                                :trigger_message_id,
                                :customer_phone,
                                'pending'
                            )
                        ");
                        $claimStmt->execute([
                            ':trigger_message_id' => $messageId,
                            ':customer_phone' => $customerPhone,
                        ]);

                        if ($claimStmt->rowCount() === 1) {

                            $autoReplyText =
                                "Dear Sir/Madam, 👋\n\n" .
                                "Thank you for contacting Ontech IT Solutions.\n" .
                                "Please send us your Company Name, a phone number for a normal call, and your preferred Date & Time for us to contact you.\n" .
                                "A quick call will help us explain the details clearly. Thank you!\n\n" .
                                "ගරු මහත්මයා/මහත්මිය, 👋\n\n" .
                                "Ontech IT Solutions වෙත සම්බන්ධ වීම ගැන ස්තුතියි.\n" .
                                "කරුණාකර ඔබගේ ආයතනයේ නම, සාමාන්‍ය call එකක් සඳහා භාවිත කළ හැකි දුරකථන අංකය සහ අපට ඔබව සම්බන්ධ කරගැනීමට පහසු දිනය හා වේලාව එවන්න.\n" .
                                "කෙටි call එකකින් වැඩි විස්තර පැහැදිලිව ලබාදිය හැක. ස්තුතියි!";

                            try {
                                $autoReplyResult = sendAutoReplyText(
                                    $pdo,
                                    $customerPhone,
                                    $autoReplyText,
                                    $customerName,
                                    $webhookPhoneNumberId
                                );

                                $successStmt = $pdo->prepare("
                                    UPDATE whatsapp_auto_reply_log
                                    SET status = 'sent',
                                        sent_message_id = :sent_message_id,
                                        error_message = NULL,
                                        updated_at = CURRENT_TIMESTAMP
                                    WHERE trigger_message_id = :trigger_message_id
                                ");
                                $successStmt->execute([
                                    ':sent_message_id' => $autoReplyResult['message_id'],
                                    ':trigger_message_id' => $messageId,
                                ]);

                                writeWebhookLog(
                                    'AUTO REPLY SENT',
                                    [
                                        'customer_phone' => $customerPhone,
                                        'customer_name' => $customerName,
                                        'language' => 'bilingual',
                                        'message_id' => $autoReplyResult['message_id'],
                                        'trigger_message_id' => $messageId,
                                    ]
                                );
                            } catch (Throwable $autoReplyError) {

                                $errorStmt = $pdo->prepare("
                                    UPDATE whatsapp_auto_reply_log
                                    SET status = 'failed',
                                        error_message = :error_message,
                                        updated_at = CURRENT_TIMESTAMP
                                    WHERE trigger_message_id = :trigger_message_id
                                ");
                                $errorStmt->execute([
                                    ':error_message' => $autoReplyError->getMessage(),
                                    ':trigger_message_id' => $messageId,
                                ]);

                                writeWebhookLog(
                                    'AUTO REPLY ERROR',
                                    [
                                        'customer_phone' => $customerPhone,
                                        'customer_name' => $customerName,
                                        'trigger_message_id' => $messageId,
                                        'error' => $autoReplyError->getMessage(),
                                    ]
                                );
                            }
                        }
                    }
                }
            }


            /* =============================================================
               B) OUTGOING MESSAGE STATUS
            ============================================================= */
            $statuses = $value['statuses'] ?? [];

            foreach ($statuses as $statusItem) {

                if (!is_array($statusItem)) {
                    continue;
                }

                $outgoingMessageId =
                    cleanNullableString($statusItem['id'] ?? null);

                $status =
                    cleanNullableString($statusItem['status'] ?? null);

                $recipientPhone =
                    cleanNullableString($statusItem['recipient_id'] ?? null);

                $statusTimestamp =
                    (int)($statusItem['timestamp'] ?? time());

                $statusDate =
                    date('Y-m-d H:i:s', $statusTimestamp);

                if (!$outgoingMessageId) {
                    continue;
                }


                /* ---------------------------------------------------------
                   UPDATE EXISTING OUTGOING MESSAGE
                --------------------------------------------------------- */
                $updateSql = "
                    UPDATE whatsapp_conversation_messages
                    SET
                        status = :status,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE whatsapp_message_id = :message_id
                ";

                $updateStmt = $pdo->prepare($updateSql);

                $updateStmt->execute([
                    ':status'     => $status,
                    ':message_id' => $outgoingMessageId,
                ]);


                /* ---------------------------------------------------------
                   IF NOT SAVED BEFORE, CREATE PLACEHOLDER
                --------------------------------------------------------- */
                if ($updateStmt->rowCount() === 0 && $recipientPhone) {

                    $insertOutgoingSql = "
                        INSERT INTO whatsapp_conversation_messages (
                            whatsapp_message_id,
                            customer_phone,
                            customer_name,
                            direction,
                            message_type,
                            message_text,
                            message_source,
                            has_referral,
                            status,
                            phone_number_id,
                            message_timestamp,
                            received_at,
                            raw_payload
                        )
                        VALUES (
                            :message_id,
                            :customer_phone,
                            NULL,
                            'outgoing',
                            'unknown',
                            NULL,
                            'Normal Chat',
                            0,
                            :status,
                            :phone_number_id,
                            :message_timestamp,
                            NULL,
                            :raw_payload
                        )
                        ON DUPLICATE KEY UPDATE
                            status = VALUES(status),
                            updated_at = CURRENT_TIMESTAMP
                    ";

                    $insertOutgoingStmt =
                        $pdo->prepare($insertOutgoingSql);

                    $insertOutgoingStmt->execute([
                        ':message_id'       => $outgoingMessageId,
                        ':customer_phone'   => $recipientPhone,
                        ':status'           => $status,
                        ':phone_number_id'  => $webhookPhoneNumberId,
                        ':message_timestamp'=> $statusDate,
                        ':raw_payload'      => $rawInput,
                    ]);
                }


                /* ---------------------------------------------------------
                   LOG OUTGOING STATUS
                --------------------------------------------------------- */
                writeWebhookLog(
                    'OUTGOING MESSAGE STATUS',
                    [
                        'message_id' => $outgoingMessageId,
                        'recipient'  => $recipientPhone,
                        'status'     => $status,
                        'direction'  => 'outgoing',
                        'timestamp'  => $statusDate,
                    ]
                );
            }
        }
    }

    /* ----------------------------------------------------------------------
       SUCCESS
    ---------------------------------------------------------------------- */
    http_response_code(200);
    echo 'EVENT_RECEIVED';

} catch (Throwable $e) {

    writeWebhookLog(
        'WEBHOOK DATABASE ERROR',
        [
            'error' => $e->getMessage(),
            'file'  => $e->getFile(),
            'line'  => $e->getLine(),
        ]
    );

    http_response_code(500);
    echo 'Webhook processing error';
}

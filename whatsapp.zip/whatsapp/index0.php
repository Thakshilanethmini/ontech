<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';


/* ========================================================================
   JSON API
   ======================================================================== */
function jsonOut($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}


function cleanVal(?string $v): ?string
{
    $v = trim((string)$v);
    return $v === '' ? null : $v;
}


function buildConversationFilters(array $p, array &$params): array
{
    $where = [];

    /* Search all messages + referral fields belonging to the conversation. */
    if (!empty($p['q'])) {
        $where[] = "(
            EXISTS (
                SELECT 1
                FROM whatsapp_conversation_messages s
                WHERE s.customer_phone = m.customer_phone
                  AND (
                      s.message_text LIKE :q1
                      OR s.customer_name LIKE :q2
                      OR s.customer_phone LIKE :q3
                      OR s.reference_code LIKE :q4
                      OR s.product_code LIKE :q5
                      OR s.content_title LIKE :q6
                      OR s.headline LIKE :q7
                      OR s.body LIKE :q8
                      OR s.ctwa_clid LIKE :q9
                  )
            )
        )";

        $like = '%' . $p['q'] . '%';

        for ($i = 1; $i <= 9; $i++) {
            $params[":q$i"] = $like;
        }
    }

    /* Message source anywhere in the conversation. */
    if (!empty($p['source'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.message_source = :source
        )";
        $params[':source'] = $p['source'];
    }

    /* Platform anywhere in referral messages of the conversation. */
    if (!empty($p['platform'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.source_platform = :platform
              AND s.has_referral = 1
        )";
        $params[':platform'] = $p['platform'];
    }

    if (!empty($p['source_type'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.source_type = :source_type
              AND s.has_referral = 1
        )";
        $params[':source_type'] = $p['source_type'];
    }

    if (!empty($p['product'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.product_code = :product
              AND s.has_referral = 1
        )";
        $params[':product'] = $p['product'];
    }

    if (!empty($p['reference'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.reference_code LIKE :reference
              AND s.has_referral = 1
        )";
        $params[':reference'] = '%' . $p['reference'] . '%';
    }

    if (($p['referral'] ?? '') === 'yes') {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.has_referral = 1
        )";
    } elseif (($p['referral'] ?? '') === 'no') {
        $where[] = "NOT EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.has_referral = 1
        )";
    }

    if (($p['ctwa'] ?? '') === 'yes') {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.ctwa_clid IS NOT NULL
              AND s.ctwa_clid <> ''
        )";
    }

    if (!empty($p['message_type'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND s.message_type = :message_type
        )";
        $params[':message_type'] = $p['message_type'];
    }

    if (!empty($p['date_from'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND DATE(s.message_timestamp) >= :date_from
        )";
        $params[':date_from'] = $p['date_from'];
    }

    if (!empty($p['date_to'])) {
        $where[] = "EXISTS (
            SELECT 1
            FROM whatsapp_conversation_messages s
            WHERE s.customer_phone = m.customer_phone
              AND DATE(s.message_timestamp) <= :date_to
        )";
        $params[':date_to'] = $p['date_to'];
    }

    return $where;
}


function buildLeadFilters(array $p, array &$params): array
{
    $where = [
        'has_referral = 1'
    ];

    if (!empty($p['q'])) {
        $where[] = "(
            customer_phone LIKE :q1
            OR customer_name LIKE :q2
            OR reference_code LIKE :q3
            OR product_code LIKE :q4
            OR content_title LIKE :q5
            OR headline LIKE :q6
            OR body LIKE :q7
            OR ctwa_clid LIKE :q8
        )";

        $like = '%' . $p['q'] . '%';
        for ($i = 1; $i <= 8; $i++) {
            $params[":q$i"] = $like;
        }
    }

    if (!empty($p['platform'])) {
        $where[] = 'source_platform = :platform';
        $params[':platform'] = $p['platform'];
    }

    if (!empty($p['source_type'])) {
        $where[] = 'source_type = :source_type';
        $params[':source_type'] = $p['source_type'];
    }

    if (!empty($p['product'])) {
        $where[] = 'product_code = :product';
        $params[':product'] = $p['product'];
    }

    if (!empty($p['reference'])) {
        $where[] = 'reference_code LIKE :reference';
        $params[':reference'] = '%' . $p['reference'] . '%';
    }

    if (($p['ctwa'] ?? '') === 'yes') {
        $where[] = "ctwa_clid IS NOT NULL AND ctwa_clid <> ''";
    }

    if (!empty($p['date_from'])) {
        $where[] = 'DATE(COALESCE(received_at, message_timestamp)) >= :date_from';
        $params[':date_from'] = $p['date_from'];
    }

    if (!empty($p['date_to'])) {
        $where[] = 'DATE(COALESCE(received_at, message_timestamp)) <= :date_to';
        $params[':date_to'] = $p['date_to'];
    }

    return $where;
}


$action = (string)($_GET['action'] ?? '');

if ($action !== '') {

    try {

        if (!isset($pdo) || !($pdo instanceof PDO)) {
            throw new RuntimeException(
                'PDO connection ($pdo) not found in config.php'
            );
        }

        $filters = [
            'q'            => cleanVal($_GET['q']            ?? null),
            'source'       => cleanVal($_GET['source']       ?? null),
            'platform'     => cleanVal($_GET['platform']     ?? null),
            'source_type'  => cleanVal($_GET['source_type']  ?? null),
            'product'      => cleanVal($_GET['product']      ?? null),
            'reference'    => cleanVal($_GET['reference']    ?? null),
            'referral'     => cleanVal($_GET['referral']     ?? null),
            'ctwa'         => cleanVal($_GET['ctwa']         ?? null),
            'message_type' => cleanVal($_GET['message_type'] ?? null),
            'date_from'    => cleanVal($_GET['date_from']    ?? null),
            'date_to'      => cleanVal($_GET['date_to']      ?? null),
            'sort'         => cleanVal($_GET['sort']         ?? null),
        ];

        switch ($action) {

            /* ============================================================== 
               STATS
            ============================================================== */
            case 'stats':

                jsonOut([
                    'conversations' => (int)$pdo->query(
                        "SELECT COUNT(DISTINCT customer_phone)
                         FROM whatsapp_conversation_messages
                         WHERE customer_phone IS NOT NULL
                           AND customer_phone <> ''"
                    )->fetchColumn(),

                    'messages' => (int)$pdo->query(
                        "SELECT COUNT(*)
                         FROM whatsapp_conversation_messages"
                    )->fetchColumn(),

                    'leads' => (int)$pdo->query(
                        "SELECT COUNT(*)
                         FROM whatsapp_conversation_messages
                         WHERE has_referral = 1"
                    )->fetchColumn(),

                    'today' => (int)$pdo->query(
                        "SELECT COUNT(*)
                         FROM whatsapp_conversation_messages
                         WHERE DATE(message_timestamp) = CURDATE()"
                    )->fetchColumn(),
                ]);


            /* ============================================================== 
               FILTER OPTIONS
            ============================================================== */
            case 'filter_options':

                $opt = [
                    'sources' => $pdo->query(
                        "SELECT DISTINCT message_source
                         FROM whatsapp_conversation_messages
                         WHERE message_source IS NOT NULL
                           AND message_source <> ''
                         ORDER BY message_source"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'platforms' => $pdo->query(
                        "SELECT DISTINCT source_platform
                         FROM whatsapp_conversation_messages
                         WHERE has_referral = 1
                           AND source_platform IS NOT NULL
                           AND source_platform <> ''
                         ORDER BY source_platform"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'source_types' => $pdo->query(
                        "SELECT DISTINCT source_type
                         FROM whatsapp_conversation_messages
                         WHERE has_referral = 1
                           AND source_type IS NOT NULL
                           AND source_type <> ''
                         ORDER BY source_type"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'products' => $pdo->query(
                        "SELECT DISTINCT product_code
                         FROM whatsapp_conversation_messages
                         WHERE has_referral = 1
                           AND product_code IS NOT NULL
                           AND product_code <> ''
                         ORDER BY product_code"
                    )->fetchAll(PDO::FETCH_COLUMN),

                    'message_types' => $pdo->query(
                        "SELECT DISTINCT message_type
                         FROM whatsapp_conversation_messages
                         WHERE message_type IS NOT NULL
                           AND message_type <> ''
                         ORDER BY message_type"
                    )->fetchAll(PDO::FETCH_COLUMN),
                ];

                jsonOut(['data' => $opt]);


            /* ============================================================== 
               CONVERSATION LIST
            ============================================================== */
            case 'conversations':

                $limit = min(
                    500,
                    max(10, (int)($_GET['limit'] ?? 300))
                );

                $params = [];
                $where = buildConversationFilters($filters, $params);

                switch ($filters['sort']) {
                    case 'oldest':
                        $order = 'm.id ASC';
                        break;

                    case 'name':
                        $order = 'COALESCE(m.customer_name, m.customer_phone) ASC';
                        break;

                    case 'messages':
                        $order = 'total_messages DESC';
                        break;

                    default:
                        $order = 'm.id DESC';
                        break;
                }

                /*
                 * m = latest message for each customer.
                 * lr = latest referral-bearing message for the same customer.
                 * Both come from the SAME table.
                 */
                $sql = "
                    SELECT
                        m.id,
                        m.customer_phone,
                        m.customer_name,
                        m.message_text,
                        m.message_type,
                        m.message_source,
                        m.direction,
                        m.status,
                        m.message_timestamp,

                        (
                            SELECT COUNT(*)
                            FROM whatsapp_conversation_messages c2
                            WHERE c2.customer_phone = m.customer_phone
                        ) AS total_messages,

                        lr.reference_code,
                        lr.product_code,
                        lr.source_platform,
                        lr.source_type,
                        lr.content_title,
                        lr.ctwa_clid,
                        lr.id AS referral_message_id

                    FROM whatsapp_conversation_messages m

                    INNER JOIN (
                        SELECT customer_phone, MAX(id) AS max_id
                        FROM whatsapp_conversation_messages
                        GROUP BY customer_phone
                    ) latest
                        ON latest.max_id = m.id

                    LEFT JOIN (
                        SELECT
                            customer_phone,
                            MAX(id) AS max_ref_id
                        FROM whatsapp_conversation_messages
                        WHERE has_referral = 1
                        GROUP BY customer_phone
                    ) latest_ref
                        ON latest_ref.customer_phone = m.customer_phone

                    LEFT JOIN whatsapp_conversation_messages lr
                        ON lr.id = latest_ref.max_ref_id
                ";

                if ($where) {
                    $sql .= ' WHERE ' . implode(' AND ', $where);
                }

                $sql .= " ORDER BY $order LIMIT $limit";

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                jsonOut([
                    'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
                ]);


            /* ============================================================== 
               MESSAGES OF ONE CONVERSATION
            ============================================================== */
            case 'messages':

                $phone = trim((string)($_GET['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $stmt = $pdo->prepare(
                    "SELECT
                        c.id,
                        c.whatsapp_message_id,
                        c.customer_phone,
                        c.customer_name,
                        c.direction,
                        c.message_type,
                        c.message_text,
                        c.message_source,
                        c.status,
                        c.phone_number_id,
                        c.message_timestamp,
                        c.raw_payload,

                        c.has_referral,
                        c.reference_code,
                        c.product_code,
                        c.source_type,
                        c.source_platform,
                        c.content_title,
                        c.headline,
                        c.body AS ad_body,
                        c.media_type AS ref_media_type,
                        c.image_url,
                        c.video_url,
                        c.thumbnail_url,
                        c.source_id,
                        c.source_url,
                        c.ctwa_clid,
                        c.campaign_name,
                        c.ad_name,
                        c.creative_name

                    FROM whatsapp_conversation_messages c

                    WHERE c.customer_phone = :phone

                    ORDER BY c.message_timestamp ASC, c.id ASC
                    LIMIT 500"
                );

                $stmt->execute([':phone' => $phone]);

                jsonOut([
                    'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
                ]);


            /* ============================================================== 
               LATEST REFERRAL OF A CONVERSATION
            ============================================================== */
            case 'referral':

                $phone = trim((string)($_GET['phone'] ?? ''));

                if ($phone === '') {
                    jsonOut(['error' => 'phone is required'], 400);
                }

                $stmt = $pdo->prepare(
                    "SELECT *
                     FROM whatsapp_conversation_messages
                     WHERE customer_phone = :phone
                       AND has_referral = 1
                     ORDER BY id DESC
                     LIMIT 1"
                );

                $stmt->execute([':phone' => $phone]);

                jsonOut([
                    'data' => $stmt->fetch(PDO::FETCH_ASSOC) ?: null
                ]);


            /* ============================================================== 
               LEADS TABLE
            ============================================================== */
            case 'leads':

                $limit = min(
                    500,
                    max(10, (int)($_GET['limit'] ?? 300))
                );

                $params = [];
                $where = buildLeadFilters($filters, $params);

                switch ($filters['sort']) {
                    case 'oldest':
                        $order = 'id ASC';
                        break;

                    case 'name':
                        $order = 'COALESCE(customer_name, customer_phone) ASC';
                        break;

                    default:
                        $order = 'id DESC';
                        break;
                }

                $sql = "
                    SELECT *
                    FROM whatsapp_conversation_messages
                ";

                if ($where) {
                    $sql .= ' WHERE ' . implode(' AND ', $where);
                }

                $sql .= " ORDER BY $order LIMIT $limit";

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                jsonOut([
                    'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
                ]);


            default:
                jsonOut(['error' => 'Unknown action'], 404);
        }

    } catch (Throwable $e) {
        jsonOut(['error' => $e->getMessage()], 500);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WhatsApp Inbox</title>

<style>
:root{
    --bg:#eef2f6;
    --panel:#ffffff;
    --border:#e2e8f0;
    --text:#0f172a;
    --muted:#64748b;
    --green:#25d366;
    --green-dark:#128c7e;
    --green-soft:#dcf8c6;
    --blue:#2563eb;
    --amber:#d97706;
    --purple:#7c3aed;
    --red:#dc2626;
    --shadow:0 1px 2px rgba(15,23,42,.06),0 8px 24px -12px rgba(15,23,42,.18);
    --radius:14px;
}

*{box-sizing:border-box;}
html,body{height:100%;}

body{
    margin:0;
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
    background:var(--bg);
    color:var(--text);
    font-size:14px;
    -webkit-font-smoothing:antialiased;
}

button,input,select{font-family:inherit;font-size:inherit;}

.topbar{
    display:flex;
    align-items:center;
    gap:16px;
    flex-wrap:wrap;
    padding:12px 20px;
    background:var(--panel);
    border-bottom:1px solid var(--border);
    position:sticky;
    top:0;
    z-index:20;
}

.brand{
    display:flex;
    align-items:center;
    gap:10px;
    font-weight:700;
    font-size:16px;
    white-space:nowrap;
}

.brand .dot{
    width:32px;
    height:32px;
    border-radius:10px;
    background:linear-gradient(135deg,var(--green),var(--green-dark));
    display:grid;
    place-items:center;
    color:#fff;
    font-size:16px;
}

.tabs{
    display:flex;
    gap:4px;
    background:#f1f5f9;
    padding:4px;
    border-radius:10px;
}

.tab{
    border:0;
    background:transparent;
    color:var(--muted);
    padding:7px 16px;
    border-radius:7px;
    cursor:pointer;
    font-weight:600;
    transition:.15s;
}

.tab:hover{color:var(--text);}
.tab.active{background:#fff;color:var(--text);box-shadow:0 1px 3px rgba(15,23,42,.1);}

.stats{display:flex;gap:8px;margin-left:auto;flex-wrap:wrap;}

.stat{
    background:#f8fafc;
    border:1px solid var(--border);
    border-radius:10px;
    padding:6px 12px;
    line-height:1.2;
    min-width:78px;
}

.stat b{display:block;font-size:16px;}
.stat span{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;}

.toolbar{display:flex;gap:8px;align-items:center;}

.auto-btn{
    border:1px solid var(--border);
    background:#fff;
    border-radius:10px;
    padding:7px 12px;
    cursor:pointer;
    font-weight:600;
    color:var(--muted);
    display:flex;
    align-items:center;
    gap:7px;
    transition:.15s;
}

.auto-btn.on{color:var(--green-dark);border-color:#a7f3d0;background:#ecfdf5;}
.auto-btn .pulse{width:8px;height:8px;border-radius:50%;background:#cbd5e1;}
.auto-btn.on .pulse{background:var(--green);animation:pulse 1.6s infinite;}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.25}}

.wrap{padding:16px;height:calc(100vh - 63px);}

.grid{
    display:grid;
    grid-template-columns:340px minmax(0,1fr) 350px;
    gap:16px;
    height:100%;
}

.panel{
    background:var(--panel);
    border:1px solid var(--border);
    border-radius:var(--radius);
    box-shadow:var(--shadow);
    display:flex;
    flex-direction:column;
    overflow:hidden;
    min-height:0;
}

.panel-head{
    padding:12px 14px;
    border-bottom:1px solid var(--border);
    display:flex;
    align-items:center;
    gap:10px;
    flex-shrink:0;
}

.panel-head h2{
    margin:0;
    font-size:13px;
    text-transform:uppercase;
    letter-spacing:.6px;
    color:var(--muted);
}

.panel-body{overflow-y:auto;flex:1;min-height:0;}
.panel-body::-webkit-scrollbar{width:8px;}
.panel-body::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:8px;}
.panel-body::-webkit-scrollbar-track{background:transparent;}

.filters{
    padding:10px 12px;
    border-bottom:1px solid var(--border);
    display:flex;
    flex-direction:column;
    gap:8px;
    flex-shrink:0;
    background:#fbfcfd;
}

.filter-row{display:flex;gap:8px;}
.filter-row > *{flex:1;min-width:0;}

.input,.select{
    width:100%;
    padding:8px 10px;
    border:1px solid var(--border);
    border-radius:9px;
    background:#fff;
    outline:none;
    transition:.15s;
    font-size:13px;
}

.input:focus,.select:focus{
    border-color:var(--green);
    box-shadow:0 0 0 3px rgba(37,211,102,.15);
}

.input[type="date"]{padding:7px 10px;}
.select{cursor:pointer;}

.filter-toggle{
    display:flex;
    align-items:center;
    gap:7px;
    border:1px dashed #cbd5e1;
    background:#fff;
    color:var(--muted);
    border-radius:9px;
    padding:7px 10px;
    cursor:pointer;
    font-weight:600;
    font-size:12px;
    transition:.15s;
    justify-content:center;
}

.filter-toggle:hover{border-color:var(--green);color:var(--green-dark);}
.filter-toggle.active{border-style:solid;border-color:var(--green);background:#ecfdf5;color:var(--green-dark);}

.filter-toggle .cnt{
    background:var(--green);
    color:#fff;
    font-size:10px;
    padding:1px 6px;
    border-radius:10px;
    font-weight:700;
    min-width:16px;
    text-align:center;
}

.adv-filters{
    display:flex;
    flex-direction:column;
    gap:8px;
    padding-top:8px;
    border-top:1px dashed var(--border);
    animation:slideDown .18s ease-out;
}

@keyframes slideDown{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}

.adv-label{
    font-size:10.5px;
    color:var(--muted);
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.5px;
    margin-bottom:-3px;
}

.chips{display:flex;flex-wrap:wrap;gap:5px;padding-top:4px;}

.chip{
    display:inline-flex;
    align-items:center;
    gap:5px;
    background:#e0f2fe;
    color:#0369a1;
    font-size:11px;
    padding:3px 8px;
    border-radius:20px;
    font-weight:600;
}

.chip button{
    border:0;
    background:transparent;
    color:inherit;
    cursor:pointer;
    font-weight:900;
    padding:0;
    line-height:1;
    font-size:13px;
}

.chip.clear-all{background:#fee2e2;color:#b91c1c;cursor:pointer;}

.conv{
    display:flex;
    gap:11px;
    padding:12px 14px;
    border-bottom:1px solid #f1f5f9;
    cursor:pointer;
    transition:.12s;
}

.conv:hover{background:#f8fafc;}
.conv.active{background:#ecfdf5;box-shadow:inset 3px 0 0 var(--green);}

.avatar{
    width:42px;
    height:42px;
    border-radius:50%;
    flex-shrink:0;
    display:grid;
    place-items:center;
    font-weight:700;
    color:#fff;
    font-size:15px;
    background:linear-gradient(135deg,#94a3b8,#64748b);
}

.avatar.a1{background:linear-gradient(135deg,#34d399,#059669);}
.avatar.a2{background:linear-gradient(135deg,#60a5fa,#2563eb);}
.avatar.a3{background:linear-gradient(135deg,#fbbf24,#d97706);}
.avatar.a4{background:linear-gradient(135deg,#a78bfa,#7c3aed);}
.avatar.a5{background:linear-gradient(135deg,#f472b6,#db2777);}

.conv-main{flex:1;min-width:0;}
.conv-top{display:flex;justify-content:space-between;gap:8px;align-items:baseline;}
.conv-name{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.conv-time{font-size:11px;color:var(--muted);white-space:nowrap;flex-shrink:0;}
.conv-preview{font-size:12.5px;color:var(--muted);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.conv-badges{display:flex;gap:6px;margin-top:7px;flex-wrap:wrap;align-items:center;}

.badge{font-size:10.5px;font-weight:700;padding:2.5px 8px;border-radius:20px;letter-spacing:.3px;white-space:nowrap;}
.badge.gray{background:#f1f5f9;color:#475569;}
.badge.green{background:#dcfce7;color:#15803d;}
.badge.blue{background:#dbeafe;color:#1d4ed8;}
.badge.amber{background:#fef3c7;color:#b45309;}
.badge.purple{background:#ede9fe;color:#6d28d9;}
.badge.red{background:#fee2e2;color:#b91c1c;}
.badge.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10px;}

.count-pill{font-size:10.5px;background:#f1f5f9;color:#64748b;padding:2px 7px;border-radius:20px;font-weight:600;}

.chat-head{
    padding:12px 18px;
    border-bottom:1px solid var(--border);
    display:flex;
    align-items:center;
    gap:12px;
    flex-shrink:0;
    background:#fff;
}

.chat-head .name{font-weight:700;font-size:15px;}
.chat-head .sub{font-size:12px;color:var(--muted);margin-top:1px;}

.thread{
    flex:1;
    overflow-y:auto;
    min-height:0;
    padding:22px 24px;
    background:radial-gradient(circle at 1px 1px,#e2e8f0 1px,transparent 0) 0 0/22px 22px,#f7f9fb;
    display:flex;
    flex-direction:column;
    gap:12px;
}

.msg{display:flex;max-width:100%;}
.msg.incoming{justify-content:flex-start;}
.msg.outgoing{justify-content:flex-end;}

.bubble{
    max-width:min(560px,78%);
    border-radius:14px;
    padding:9px 12px 7px;
    box-shadow:0 1px 1px rgba(15,23,42,.08);
    word-wrap:break-word;
    overflow-wrap:anywhere;
}

.msg.incoming .bubble{background:#fff;border-top-left-radius:4px;}
.msg.outgoing .bubble{background:var(--green-soft);border-top-right-radius:4px;}
.bubble .txt{font-size:14px;line-height:1.45;white-space:pre-wrap;}
.bubble .meta{display:flex;justify-content:flex-end;gap:6px;align-items:center;font-size:10.5px;color:#64748b;margin-top:4px;}
.tick{font-size:11px;}
.tick.read{color:var(--blue);}

.ad-card{
    margin-top:9px;
    border:1px solid #cbd5e1;
    border-radius:11px;
    overflow:hidden;
    background:#f8fafc;
    max-width:330px;
}

.ad-card .ad-top{
    padding:7px 11px;
    font-size:10.5px;
    font-weight:700;
    letter-spacing:.6px;
    text-transform:uppercase;
    color:#475569;
    background:#e2e8f0;
    display:flex;
    align-items:center;
    gap:6px;
}

.ad-card .ad-img{width:100%;display:block;max-height:190px;object-fit:cover;background:#e2e8f0;}
.ad-card .ad-body{padding:10px 12px;font-size:12.5px;color:#334155;line-height:1.5;}
.ad-card .ad-title{font-weight:700;color:var(--text);margin-bottom:3px;}

.ad-card .ref-chip{
    display:inline-block;
    margin-top:7px;
    font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
    font-size:11px;
    background:#0f172a;
    color:#a7f3d0;
    padding:3px 9px;
    border-radius:6px;
    letter-spacing:.4px;
}

.section{padding:14px 16px;border-bottom:1px solid #f1f5f9;}
.section:last-child{border-bottom:0;}
.section h3{margin:0 0 10px;font-size:11px;text-transform:uppercase;letter-spacing:.7px;color:var(--muted);font-weight:700;}

.kv{display:flex;justify-content:space-between;gap:12px;padding:6px 0;font-size:12.5px;}
.kv .k{color:var(--muted);flex-shrink:0;}
.kv .v{font-weight:600;text-align:right;word-break:break-word;}
.kv .v.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;font-weight:500;}
.kv .v a{color:var(--blue);text-decoration:none;}
.kv .v a:hover{text-decoration:underline;}

.empty{padding:44px 24px;text-align:center;color:var(--muted);font-size:13px;}
.empty .big{font-size:34px;margin-bottom:10px;opacity:.35;}

details.raw{margin-top:8px;}
details.raw summary{cursor:pointer;font-size:11.5px;color:var(--muted);font-weight:600;list-style:none;}
details.raw summary::-webkit-details-marker{display:none;}
details.raw summary::before{content:"▸ ";}
details.raw[open] summary::before{content:"▾ ";}

pre.rawbox{
    background:#0f172a;
    color:#a7f3d0;
    padding:12px;
    border-radius:10px;
    font-size:11px;
    overflow-x:auto;
    margin-top:8px;
    max-height:280px;
    font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
    line-height:1.5;
}

.leads-wrap{padding:0;height:100%;overflow:auto;}
table.leads{width:100%;border-collapse:collapse;font-size:12.5px;}

table.leads th{
    position:sticky;
    top:0;
    background:#f8fafc;
    text-align:left;
    padding:11px 14px;
    font-size:11px;
    text-transform:uppercase;
    letter-spacing:.5px;
    color:var(--muted);
    border-bottom:1px solid var(--border);
    z-index:2;
    white-space:nowrap;
}

table.leads td{padding:10px 14px;border-bottom:1px solid #f1f5f9;vertical-align:top;}
table.leads tr:hover td{background:#f8fafc;}

.leads-filters{
    padding:12px 16px;
    background:#fbfcfd;
    border-bottom:1px solid var(--border);
    display:flex;
    flex-direction:column;
    gap:8px;
    position:sticky;
    top:0;
    z-index:3;
}

.leads-filter-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px;}
.hidden{display:none !important;}
.spinner{display:inline-block;width:14px;height:14px;border:2px solid #cbd5e1;border-top-color:var(--green);border-radius:50%;animation:spin .7s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}

@media (max-width:1180px){
    .grid{grid-template-columns:290px minmax(0,1fr);}
    .panel.details{display:none;}
}

@media (max-width:820px){
    .wrap{height:auto;padding:10px;}
    .grid{grid-template-columns:1fr;height:auto;}
    .panel{height:auto;max-height:none;}
    .panel-body{max-height:340px;}
    .thread{max-height:60vh;}
    .stats{width:100%;margin-left:0;}
}
</style>
</head>
<body>

<div class="topbar">
    <div class="brand">
        <div class="dot">💬</div>
        <span>WhatsApp Inbox</span>
    </div>

    <div class="tabs">
        <button class="tab active" data-view="inbox">Inbox</button>
        <button class="tab" data-view="leads">Leads</button>
    </div>

    <div class="stats">
        <div class="stat"><b id="s-conv">–</b><span>Chats</span></div>
        <div class="stat"><b id="s-msg">–</b><span>Messages</span></div>
        <div class="stat"><b id="s-leads">–</b><span>Leads</span></div>
        <div class="stat"><b id="s-today">–</b><span>Today</span></div>
    </div>

    <div class="toolbar">
        <button class="auto-btn on" id="autoBtn">
            <span class="pulse"></span> Live
        </button>
    </div>
</div>

<div class="wrap">

<div class="grid" id="inboxView">

    <div class="panel">
        <div class="filters">
            <input class="input" id="searchInput" type="search" placeholder="Search name, phone, message, ref…">

            <div class="filter-row">
                <select class="select" id="sourceFilter">
                    <option value="">All sources</option>
                </select>
                <select class="select" id="platformFilter">
                    <option value="">All platforms</option>
                </select>
            </div>

            <button class="filter-toggle" id="toggleAdv">
                ⚙️ More filters <span class="cnt hidden" id="advCount">0</span>
            </button>

            <div class="adv-filters hidden" id="advFilters">
                <div class="filter-row">
                    <select class="select" id="sourceTypeFilter">
                        <option value="">Any type</option>
                    </select>
                    <select class="select" id="productFilter">
                        <option value="">Any product</option>
                    </select>
                </div>

                <input class="input" id="referenceFilter" placeholder="Reference code (contains)">

                <div class="filter-row">
                    <select class="select" id="referralFilter">
                        <option value="">All chats</option>
                        <option value="yes">Only with referral</option>
                        <option value="no">Only without referral</option>
                    </select>
                    <select class="select" id="ctwaFilter">
                        <option value="">Any CLID</option>
                        <option value="yes">Has CTWA CLID</option>
                    </select>
                </div>

                <div class="filter-row">
                    <select class="select" id="messageTypeFilter">
                        <option value="">Any msg type</option>
                    </select>
                    <select class="select" id="sortFilter">
                        <option value="latest">Latest first</option>
                        <option value="oldest">Oldest first</option>
                        <option value="name">Name A–Z</option>
                        <option value="messages">Most messages</option>
                    </select>
                </div>

                <div class="adv-label">Date range</div>

                <div class="filter-row">
                    <input class="input" type="date" id="dateFrom" placeholder="From">
                    <input class="input" type="date" id="dateTo" placeholder="To">
                </div>

                <div class="chips">
                    <button class="chip" data-range="today">Today</button>
                    <button class="chip" data-range="7">Last 7 days</button>
                    <button class="chip" data-range="30">Last 30 days</button>
                    <button class="chip" data-range="month">This month</button>
                </div>
            </div>

            <div class="chips" id="filterChips"></div>
        </div>

        <div class="panel-head">
            <h2>Conversations</h2>
            <span class="count-pill" id="convCount" style="margin-left:auto">0</span>
        </div>

        <div class="panel-body" id="convList">
            <div class="empty"><div class="big">⏳</div>Loading…</div>
        </div>
    </div>

    <div class="panel">
        <div class="chat-head" id="chatHead">
            <div class="avatar" id="chatAvatar">–</div>
            <div>
                <div class="name" id="chatName">Select a conversation</div>
                <div class="sub" id="chatSub">Pick a chat from the list to view messages</div>
            </div>
        </div>

        <div class="thread" id="thread">
            <div class="empty" style="margin:auto">
                <div class="big">💬</div>No conversation selected
            </div>
        </div>
    </div>

    <div class="panel details">
        <div class="panel-head"><h2>Lead / Referral Details</h2></div>
        <div class="panel-body" id="detailsPanel">
            <div class="empty"><div class="big">📋</div>No lead data</div>
        </div>
    </div>
</div>

<div class="panel hidden" id="leadsView" style="height:100%">

    <div class="leads-filters">
        <div class="filter-row">
            <input class="input" id="leadSearch" placeholder="Search leads…" style="max-width:340px">
            <select class="select" id="leadSort" style="max-width:200px">
                <option value="latest">Latest first</option>
                <option value="oldest">Oldest first</option>
                <option value="name">Name A–Z</option>
            </select>
        </div>

        <div class="leads-filter-grid">
            <select class="select" id="leadPlatform">
                <option value="">All platforms</option>
            </select>
            <select class="select" id="leadSourceType">
                <option value="">Any source type</option>
            </select>
            <select class="select" id="leadProduct">
                <option value="">Any product</option>
            </select>
            <input class="input" id="leadReference" placeholder="Reference code">
            <select class="select" id="leadCtwa">
                <option value="">Any CLID</option>
                <option value="yes">Has CTWA CLID</option>
            </select>
            <input class="input" type="date" id="leadDateFrom">
            <input class="input" type="date" id="leadDateTo">
        </div>

        <div class="chips" id="leadChips"></div>
    </div>

    <div class="panel-head">
        <h2>Captured Leads</h2>
        <span class="count-pill" id="leadCount" style="margin-left:auto">0</span>
    </div>

    <div class="panel-body leads-wrap" id="leadsBody">
        <div class="empty"><div class="big">📥</div>Loading…</div>
    </div>
</div>

</div>

<script>
/* =========================================================================
   HELPERS
   ========================================================================= */
const $ = (id) => document.getElementById(id);
const $$ = (sel) => document.querySelectorAll(sel);

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => (
    {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]
));

function safeUrl(value) {
    try {
        const url = new URL(String(value || ''), window.location.origin);
        if (url.protocol === 'https:' || url.protocol === 'http:') {
            return url.href;
        }
    } catch (e) {}
    return null;
}

function api(action, params = {}) {
    const url = new URL(window.location.href);
    url.search = '';
    url.searchParams.set('action', action);

    Object.entries(params).forEach(([k, v]) => {
        if (v !== '' && v !== null && v !== undefined) {
            url.searchParams.set(k, v);
        }
    });

    return fetch(url.toString(), {
        headers: { 'Accept':'application/json' }
    }).then(async r => {
        const text = await r.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error(text || ('HTTP ' + r.status));
        }
        if (!r.ok && !data.error) {
            throw new Error('HTTP ' + r.status);
        }
        return data;
    });
}

function fmtDateTime(s) {
    if (!s) return '—';

    const d = new Date(String(s).replace(' ', 'T'));
    if (isNaN(d)) return String(s);

    const now = new Date();
    const same = d.toDateString() === now.toDateString();

    if (same) {
        return d.toLocaleTimeString([], {
            hour:'2-digit',
            minute:'2-digit'
        });
    }

    return d.toLocaleDateString([], {
        day:'2-digit',
        month:'short'
    }) + ' ' + d.toLocaleTimeString([], {
        hour:'2-digit',
        minute:'2-digit'
    });
}

function fmtFull(s) {
    if (!s) return '—';

    const d = new Date(String(s).replace(' ', 'T'));
    return isNaN(d) ? String(s) : d.toLocaleString();
}

function initials(name, phone) {
    if (name) {
        return name
            .trim()
            .split(/\s+/)
            .slice(0,2)
            .map(w => w[0])
            .join('')
            .toUpperCase();
    }

    return String(phone || '?').slice(-2);
}

function colorClass(key) {
    let h = 0;
    for (const ch of String(key || '')) {
        h = (h * 31 + ch.charCodeAt(0)) % 5;
    }
    return 'a' + (h + 1);
}

function sourceBadge(source) {
    const s = String(source || 'Unknown');
    let cls = 'gray';

    if (s === 'Normal Chat') cls = 'gray';
    else if (/video/i.test(s)) cls = 'purple';
    else if (/flyer|image/i.test(s)) cls = 'amber';
    else if (/^Ad/i.test(s)) cls = 'blue';
    else cls = 'green';

    return `<span class="badge ${cls}">${esc(s)}</span>`;
}

function tickMark(status) {
    const s = String(status || '').toLowerCase();

    if (!s) return '';
    if (s === 'read') return '<span class="tick read">✓✓</span>';
    if (s === 'delivered') return '<span class="tick">✓✓</span>';
    if (s === 'sent') return '<span class="tick">✓</span>';
    if (s === 'failed') return '<span class="tick" style="color:#dc2626">✕</span>';

    return `<span class="tick">${esc(s)}</span>`;
}


/* =========================================================================
   STATE
   ========================================================================= */
const state = {
    phone: null,
    auto: true,
    timer: null,
    view: 'inbox',

    filters: {
        q: '',
        source: '',
        platform: '',
        source_type: '',
        product: '',
        reference: '',
        referral: '',
        ctwa: '',
        message_type: '',
        date_from: '',
        date_to: '',
        sort: 'latest',
    },

    leadFilters: {
        q: '',
        platform: '',
        source_type: '',
        product: '',
        reference: '',
        ctwa: '',
        date_from: '',
        date_to: '',
        sort: 'latest',
    },
};


/* =========================================================================
   FILTER OPTIONS
   ========================================================================= */
async function loadFilterOptions() {
    try {
        const res = await api('filter_options');
        if (!res.data) return;

        const o = res.data;

        fillSelect('sourceFilter',      o.sources,       'All sources');
        fillSelect('platformFilter',    o.platforms,     'All platforms');
        fillSelect('sourceTypeFilter',  o.source_types,  'Any type');
        fillSelect('productFilter',     o.products,      'Any product');
        fillSelect('messageTypeFilter', o.message_types, 'Any msg type');

        fillSelect('leadPlatform',   o.platforms,     'All platforms');
        fillSelect('leadSourceType', o.source_types,  'Any source type');
        fillSelect('leadProduct',    o.products,      'Any product');
    } catch (e) {
        console.error('filter_options:', e);
    }
}

function fillSelect(id, values, placeholder) {
    const el = $(id);
    if (!el) return;

    const keep = el.value;

    el.innerHTML =
        `<option value="">${esc(placeholder)}</option>` +
        (values || [])
            .map(v => `<option value="${esc(v)}">${esc(v)}</option>`)
            .join('');

    if (keep) el.value = keep;
}


/* =========================================================================
   STATS
   ========================================================================= */
async function loadStats() {
    try {
        const s = await api('stats');
        if (s.error) return;

        $('s-conv').textContent  = s.conversations ?? 0;
        $('s-msg').textContent   = s.messages ?? 0;
        $('s-leads').textContent = s.leads ?? 0;
        $('s-today').textContent = s.today ?? 0;
    } catch (e) {
        console.error('stats:', e);
    }
}


/* =========================================================================
   INBOX FILTERS UI
   ========================================================================= */
const filterInputMap = {
    searchInput:        'q',
    sourceFilter:       'source',
    platformFilter:     'platform',
    sourceTypeFilter:   'source_type',
    productFilter:      'product',
    referenceFilter:    'reference',
    referralFilter:     'referral',
    ctwaFilter:         'ctwa',
    messageTypeFilter:  'message_type',
    dateFrom:           'date_from',
    dateTo:             'date_to',
    sortFilter:         'sort',
};

function bindInboxFilters() {
    let timer = null;

    const apply = (debounce = true) => {
        clearTimeout(timer);

        const run = () => {
            loadConversations();
            renderFilterChips();
            updateAdvCount();
        };

        debounce ? timer = setTimeout(run, 250) : run();
    };

    Object.entries(filterInputMap).forEach(([id, key]) => {
        const el = $(id);
        if (!el) return;

        const evt =
            (el.tagName === 'INPUT' && el.type !== 'date')
                ? 'input'
                : 'change';

        el.addEventListener(evt, () => {
            state.filters[key] = el.value;
            apply(evt === 'input');
        });
    });

    $('toggleAdv').addEventListener('click', () => {
        $('advFilters').classList.toggle('hidden');
        $('toggleAdv').classList.toggle('active');
    });

    $$('.chip[data-range]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const r = btn.dataset.range;
            const from = new Date();
            const to   = new Date();

            if (r === 'today') {
                // Same day.
            } else if (r === '7') {
                from.setDate(from.getDate() - 6);
            } else if (r === '30') {
                from.setDate(from.getDate() - 29);
            } else if (r === 'month') {
                from.setDate(1);
            }

            const iso = d => {
                const local = new Date(
                    d.getTime() - d.getTimezoneOffset() * 60000
                );
                return local.toISOString().slice(0,10);
            };

            $('dateFrom').value = iso(from);
            $('dateTo').value   = iso(to);

            state.filters.date_from = iso(from);
            state.filters.date_to   = iso(to);

            loadConversations();
            renderFilterChips();
            updateAdvCount();
        });
    });

    $('filterChips').addEventListener('click', (e) => {
        if (e.target.closest('.chip.clear-all')) {
            clearAllInboxFilters();
        } else if (e.target.dataset.clear) {
            const key = e.target.dataset.clear;
            state.filters[key] = '';

            const id = Object.keys(filterInputMap)
                .find(k => filterInputMap[k] === key);

            if (id && $(id)) {
                $(id).value = '';
            }

            loadConversations();
            renderFilterChips();
            updateAdvCount();
        }
    });
}

function clearAllInboxFilters() {
    Object.keys(state.filters).forEach(k => {
        state.filters[k] = k === 'sort' ? 'latest' : '';
    });

    $('searchInput').value = '';
    $('sourceFilter').value = '';
    $('platformFilter').value = '';
    $('sourceTypeFilter').value = '';
    $('productFilter').value = '';
    $('referenceFilter').value = '';
    $('referralFilter').value = '';
    $('ctwaFilter').value = '';
    $('messageTypeFilter').value = '';
    $('dateFrom').value = '';
    $('dateTo').value = '';
    $('sortFilter').value = 'latest';

    loadConversations();
    renderFilterChips();
    updateAdvCount();
}

const filterLabels = {
    q: 'Search',
    source: 'Source',
    platform: 'Platform',
    source_type: 'Type',
    product: 'Product',
    reference: 'Ref',
    referral: 'Referral',
    ctwa: 'CTWA',
    message_type: 'Msg type',
    date_from: 'From',
    date_to: 'To',
};

function renderFilterChips() {
    const chips = [];

    Object.entries(state.filters).forEach(([k, v]) => {
        if (!v || k === 'sort') return;

        const label = filterLabels[k] || k;
        const val =
            k === 'referral'
                ? (v === 'yes' ? 'With referral' : 'No referral')
                : k === 'ctwa'
                    ? 'Has CLID'
                    : v;

        chips.push(
            `<span class="chip">${esc(label)}: ${esc(val)}
                <button data-clear="${esc(k)}" title="Remove">×</button>
             </span>`
        );
    });

    if (chips.length > 1) {
        chips.push(`<span class="chip clear-all">Clear all ×</span>`);
    }

    $('filterChips').innerHTML = chips.join('');
}

function countActiveInboxFilters() {
    let n = 0;

    [
        'source_type',
        'product',
        'reference',
        'referral',
        'ctwa',
        'message_type',
        'date_from',
        'date_to'
    ].forEach(k => {
        if (state.filters[k]) n++;
    });

    return n;
}

function updateAdvCount() {
    const n = countActiveInboxFilters();
    const badge = $('advCount');

    if (n > 0) {
        badge.textContent = n;
        badge.classList.remove('hidden');
        $('toggleAdv').classList.add('active');
        $('advFilters').classList.remove('hidden');
    } else {
        badge.classList.add('hidden');
    }
}


/* =========================================================================
   CONVERSATIONS
   ========================================================================= */
async function loadConversations() {
    try {
        const res = await api('conversations', state.filters);

        if (res.error) {
            $('convList').innerHTML =
                `<div class="empty"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        $('convCount').textContent = rows.length;

        if (!rows.length) {
            $('convList').innerHTML =
                '<div class="empty"><div class="big">🔍</div>No conversations match filters</div>';
            return;
        }

        $('convList').innerHTML = rows.map(r => {
            const name = r.customer_name || r.customer_phone || 'Unknown';
            const active =
                r.customer_phone === state.phone ? ' active' : '';

            const preview =
                r.direction === 'outgoing'
                    ? 'You: ' + (r.message_text || '')
                    : (r.message_text || '');

            const badges = [sourceBadge(r.message_source)];

            if (r.source_platform) {
                badges.push(
                    `<span class="badge blue">${esc(r.source_platform)}</span>`
                );
            }

            if (r.reference_code) {
                badges.push(
                    `<span class="badge green mono">${esc(r.reference_code)}</span>`
                );
            }

            return `
                <div class="conv${active}" data-phone="${esc(r.customer_phone)}">
                    <div class="avatar ${colorClass(r.customer_phone)}">
                        ${esc(initials(r.customer_name, r.customer_phone))}
                    </div>

                    <div class="conv-main">
                        <div class="conv-top">
                            <div class="conv-name">${esc(name)}</div>
                            <div class="conv-time">
                                ${esc(fmtDateTime(r.message_timestamp))}
                            </div>
                        </div>

                        <div class="conv-preview">
                            ${esc(preview).slice(0, 90)}
                        </div>

                        <div class="conv-badges">
                            ${badges.join('')}
                            <span class="count-pill">
                                ${esc(r.total_messages)} msgs
                            </span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        $$('.conv').forEach(el => {
            el.addEventListener('click', () => {
                selectConversation(el.dataset.phone);
            });
        });

    } catch (e) {
        $('convList').innerHTML =
            `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}


/* =========================================================================
   SELECT CONVERSATION
   ========================================================================= */
async function selectConversation(phone) {
    state.phone = phone;

    $$('.conv').forEach(el => {
        el.classList.toggle('active', el.dataset.phone === phone);
    });

    await Promise.all([
        loadMessages(phone),
        loadDetails(phone)
    ]);
}


/* =========================================================================
   REFERRAL CARD
   ========================================================================= */
function referralCard(m) {
    if (!Number(m.has_referral) && !m.reference_code && !m.source_id && !m.ctwa_clid) {
        return '';
    }

    const title =
        m.content_title ||
        m.headline ||
        m.ad_body ||
        m.reference_code ||
        'Ad referral';

    const img = m.image_url || m.thumbnail_url;
    const imgUrl = safeUrl(img);

    return `
        <div class="ad-card">
            <div class="ad-top">📣 Ad Referral</div>
            ${imgUrl ? `
                <img class="ad-img"
                     src="${esc(imgUrl)}"
                     alt=""
                     loading="lazy"
                     onerror="this.style.display='none'">
            ` : ''}

            <div class="ad-body">
                <div class="ad-title">
                    ${esc(String(title).slice(0, 120))}
                </div>

                ${m.ad_body && m.ad_body !== title
                    ? `<div>${esc(String(m.ad_body).slice(0, 180))}</div>`
                    : ''}

                ${m.ref_media_type
                    ? `<div style="margin-top:6px;color:#64748b">Media: ${esc(m.ref_media_type)}</div>`
                    : ''}

                ${m.reference_code
                    ? `<div class="ref-chip">${esc(m.reference_code)}</div>`
                    : ''}
            </div>
        </div>
    `;
}


/* =========================================================================
   MESSAGES
   ========================================================================= */
async function loadMessages(phone) {
    const thread = $('thread');

    thread.innerHTML =
        '<div class="empty" style="margin:auto"><span class="spinner"></span></div>';

    try {
        const res = await api('messages', { phone });

        if (res.error) {
            thread.innerHTML =
                `<div class="empty" style="margin:auto"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        const head = rows[0] || {};

        $('chatAvatar').textContent =
            initials(head.customer_name, phone);

        $('chatAvatar').className =
            'avatar ' + colorClass(phone);

        $('chatName').textContent =
            head.customer_name || phone;

        $('chatSub').textContent =
            phone + ' · ' + rows.length + ' messages';

        if (!rows.length) {
            thread.innerHTML =
                '<div class="empty" style="margin:auto"><div class="big">💬</div>No messages</div>';
            return;
        }

        thread.innerHTML = rows.map(m => {
            const dir =
                m.direction === 'outgoing'
                    ? 'outgoing'
                    : 'incoming';

            return `
                <div class="msg ${dir}">
                    <div class="bubble">
                        <div class="txt">${esc(m.message_text || '')}</div>

                        ${referralCard(m)}

                        <div class="meta">
                            <span>${esc(fmtDateTime(m.message_timestamp))}</span>
                            ${dir === 'outgoing' ? tickMark(m.status) : ''}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        thread.scrollTop = thread.scrollHeight;

    } catch (e) {
        thread.innerHTML =
            `<div class="empty" style="margin:auto"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}


/* =========================================================================
   DETAILS
   ========================================================================= */
function kv(k, v, mono = false, link = false) {
    if (v === null || v === undefined || v === '') return '';

    if (link) {
        const url = safeUrl(v);

        if (!url) {
            return `<div class="kv"><span class="k">${esc(k)}</span>
                    <span class="v ${mono ? 'mono' : ''}">${esc(v)}</span></div>`;
        }

        return `<div class="kv">
                    <span class="k">${esc(k)}</span>
                    <span class="v ${mono ? 'mono' : ''}">
                        <a href="${esc(url)}" target="_blank" rel="noopener noreferrer">
                            ${esc(String(v).slice(0, 46))}${String(v).length > 46 ? '…' : ''}
                        </a>
                    </span>
                </div>`;
    }

    return `<div class="kv">
                <span class="k">${esc(k)}</span>
                <span class="v${mono ? ' mono' : ''}">${esc(v)}</span>
            </div>`;
}

async function loadDetails(phone) {
    const panel = $('detailsPanel');

    panel.innerHTML =
        '<div class="empty"><span class="spinner"></span></div>';

    try {
        const res = await api('referral', { phone });
        const r = res.data;

        if (!r) {
            panel.innerHTML =
                '<div class="empty"><div class="big">📋</div>No referral data for this chat</div>';
            return;
        }

        const raw = (() => {
            try {
                return JSON.stringify(
                    JSON.parse(r.raw_payload || '{}'),
                    null,
                    2
                );
            } catch {
                return r.raw_payload || '';
            }
        })();

        panel.innerHTML = `
            <div class="section">
                <h3>Contact</h3>
                ${kv('Name', r.customer_name)}
                ${kv('Phone', r.customer_phone, true)}
                ${kv('Message time', fmtFull(r.message_timestamp))}
                ${kv('Received', fmtFull(r.received_at))}
            </div>

            <div class="section">
                <h3>Attribution</h3>
                ${kv('Reference', r.reference_code, true)}
                ${kv('Product', r.product_code)}
                ${kv('Source type', r.source_type)}
                ${kv('Platform', r.source_platform)}
                ${kv('Content title', r.content_title)}
            </div>

            <div class="section">
                <h3>Campaign</h3>
                ${kv('Campaign', r.campaign_name)}
                ${kv('Ad', r.ad_name)}
                ${kv('Creative', r.creative_name)}
                ${kv('Source ID', r.source_id, true)}
                ${kv('Source URL', r.source_url, false, true)}
            </div>

            <div class="section">
                <h3>Creative Content</h3>
                ${kv('Headline', r.headline)}
                ${kv('Body', r.body)}
                ${kv('Media type', r.media_type)}
                ${kv('Image', r.image_url, false, true)}
                ${kv('Video', r.video_url, false, true)}
                ${kv('Thumbnail', r.thumbnail_url, false, true)}
            </div>

            <div class="section">
                <h3>Click Tracking</h3>
                ${kv('CTWA CLID', r.ctwa_clid, true)}
                ${kv('Phone Number ID', r.phone_number_id, true)}
            </div>

            <div class="section">
                <details class="raw">
                    <summary>Raw webhook payload</summary>
                    <pre class="rawbox">${esc(raw)}</pre>
                </details>
            </div>
        `;

    } catch (e) {
        panel.innerHTML =
            `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}


/* =========================================================================
   LEADS FILTERS + TABLE
   ========================================================================= */
const leadInputMap = {
    leadSearch:     'q',
    leadPlatform:   'platform',
    leadSourceType: 'source_type',
    leadProduct:    'product',
    leadReference:  'reference',
    leadCtwa:       'ctwa',
    leadDateFrom:   'date_from',
    leadDateTo:     'date_to',
    leadSort:       'sort',
};

function bindLeadFilters() {
    let timer = null;

    Object.entries(leadInputMap).forEach(([id, key]) => {
        const el = $(id);
        if (!el) return;

        const evt =
            (el.tagName === 'INPUT' && el.type !== 'date')
                ? 'input'
                : 'change';

        el.addEventListener(evt, () => {
            state.leadFilters[key] = el.value;

            clearTimeout(timer);

            timer = setTimeout(() => {
                loadLeads();
                renderLeadChips();
            }, evt === 'input' ? 250 : 0);
        });
    });

    $('leadChips').addEventListener('click', (e) => {
        if (e.target.closest('.chip.clear-all')) {
            clearAllLeadFilters();
        } else if (e.target.dataset.lclear) {
            const key = e.target.dataset.lclear;
            state.leadFilters[key] = '';

            const id = Object.keys(leadInputMap)
                .find(k => leadInputMap[k] === key);

            if (id && $(id)) {
                $(id).value = '';
            }

            loadLeads();
            renderLeadChips();
        }
    });
}

function clearAllLeadFilters() {
    Object.keys(state.leadFilters).forEach(k => {
        state.leadFilters[k] = k === 'sort' ? 'latest' : '';
    });

    Object.entries(leadInputMap).forEach(([id, key]) => {
        if ($(id)) {
            $(id).value = state.leadFilters[key] ?? '';
        }
    });

    loadLeads();
    renderLeadChips();
}

function renderLeadChips() {
    const labels = {
        q: 'Search',
        platform: 'Platform',
        source_type: 'Type',
        product: 'Product',
        reference: 'Ref',
        ctwa: 'CTWA',
        date_from: 'From',
        date_to: 'To',
    };

    const chips = [];

    Object.entries(state.leadFilters).forEach(([k, v]) => {
        if (!v || k === 'sort') return;

        const label = labels[k] || k;
        const val = k === 'ctwa' ? 'Has CLID' : v;

        chips.push(
            `<span class="chip">${esc(label)}: ${esc(val)}
                <button data-lclear="${esc(k)}" title="Remove">×</button>
             </span>`
        );
    });

    if (chips.length > 1) {
        chips.push(`<span class="chip clear-all">Clear all ×</span>`);
    }

    $('leadChips').innerHTML = chips.join('');
}

async function loadLeads() {
    const body = $('leadsBody');
    body.innerHTML =
        '<div class="empty"><span class="spinner"></span></div>';

    try {
        const res = await api('leads', state.leadFilters);

        if (res.error) {
            body.innerHTML =
                `<div class="empty"><div class="big">⚠️</div>${esc(res.error)}</div>`;
            return;
        }

        const rows = res.data || [];
        $('leadCount').textContent = rows.length;

        if (!rows.length) {
            body.innerHTML =
                '<div class="empty"><div class="big">🔍</div>No leads match filters</div>';
            return;
        }

        body.innerHTML = `
            <table class="leads">
                <thead>
                    <tr>
                        <th>Received</th>
                        <th>Customer</th>
                        <th>Reference</th>
                        <th>Product</th>
                        <th>Source</th>
                        <th>Platform</th>
                        <th>Content</th>
                        <th>CTWA CLID</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(r => `
                        <tr>
                            <td style="white-space:nowrap">
                                ${esc(fmtDateTime(r.received_at || r.message_timestamp))}
                            </td>

                            <td>
                                <div style="font-weight:600">
                                    ${esc(r.customer_name || '—')}
                                </div>
                                <div style="color:#64748b;font-size:11.5px">
                                    ${esc(r.customer_phone || '')}
                                </div>
                            </td>

                            <td>
                                <code style="font-size:11.5px">
                                    ${esc(r.reference_code || '—')}
                                </code>
                            </td>

                            <td>${esc(r.product_code || '—')}</td>
                            <td>${esc(r.source_type || '—')}</td>
                            <td>${esc(r.source_platform || '—')}</td>

                            <td style="max-width:260px">
                                ${esc(String(r.content_title || r.headline || '—').slice(0, 70))}
                            </td>

                            <td>
                                <code style="font-size:10.5px;color:#64748b">
                                    ${esc(String(r.ctwa_clid || '—').slice(0, 18))}
                                </code>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;

    } catch (e) {
        body.innerHTML =
            `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    }
}


/* =========================================================================
   VIEW SWITCH
   ========================================================================= */
$$('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        $$('.tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        state.view = tab.dataset.view;

        $('inboxView').classList.toggle(
            'hidden',
            state.view !== 'inbox'
        );

        $('leadsView').classList.toggle(
            'hidden',
            state.view !== 'leads'
        );

        if (state.view === 'leads') {
            loadLeads();
        }
    });
});


/* =========================================================================
   AUTO REFRESH
   ========================================================================= */
$('autoBtn').addEventListener('click', () => {
    state.auto = !state.auto;
    $('autoBtn').classList.toggle('on', state.auto);
    setupAutoRefresh();
});

function setupAutoRefresh() {
    clearInterval(state.timer);

    if (!state.auto) return;

    state.timer = setInterval(() => {
        loadStats();

        if (state.view === 'inbox') {
            loadConversations();

            if (state.phone) {
                loadMessages(state.phone);
            }
        } else {
            loadLeads();
        }
    }, 8000);
}


/* =========================================================================
   BOOT
   ========================================================================= */
async function boot() {
    bindInboxFilters();
    bindLeadFilters();

    await loadStats();
    await loadFilterOptions();
    await loadConversations();

    renderFilterChips();
    renderLeadChips();
    setupAutoRefresh();
}

boot();
</script>

</body>
</html>

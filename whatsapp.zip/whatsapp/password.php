<?php

$message = '';
$hash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

   if ($password === '') {
    $message = 'Password is required.';
} elseif ($password !== $confirm) {
    $message = 'Passwords do not match.';
} else {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $message = 'Password hash generated successfully.';
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Password Hash</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #111;
            color: #fff;
            padding: 40px 20px;
        }

        .box {
            max-width: 500px;
            margin: auto;
            background: #1d1d1d;
            padding: 30px;
            border-radius: 12px;
        }

        h2 {
            margin-top: 0;
        }

        input, button, textarea {
            width: 100%;
            box-sizing: border-box;
            padding: 12px;
            margin-top: 10px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: 1px solid #555;
        }

        button {
            background: #ffd700;
            border: none;
            color: #111;
            font-weight: bold;
            cursor: pointer;
        }

        textarea {
            min-height: 100px;
            background: #000;
            color: #0f0;
        }

        .success {
            color: #00ff88;
        }

        .error {
            color: #ff6666;
        }

        .warning {
            color: #ffd700;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="box">

    <h2>Create Password</h2>

    <?php if ($message): ?>
        <p class="<?= $hash ? 'success' : 'error' ?>">
            <?= htmlspecialchars($message) ?>
        </p>
    <?php endif; ?>

    <form method="POST">

        <label>New Password</label>
        <input
            type="password"
            name="password"
            required
            autocomplete="new-password"
        >

        <label>Confirm Password</label>
        <input
            type="password"
            name="confirm_password"
            required
            autocomplete="new-password"
        >

        <button type="submit">Generate Password Hash</button>

    </form>

    <?php if ($hash): ?>

        <p class="success">Copy this hash to your config.php:</p>

        <textarea readonly><?= htmlspecialchars($hash) ?></textarea>

        <p class="warning">
            After copying the hash, delete or disable this page.
        </p>

    <?php endif; ?>

</div>

</body>
</html>
<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/*
|--------------------------------------------------------------------------
| ONTECH WHATSAPP CLOUD API WEBHOOK
|--------------------------------------------------------------------------
| Single-table version.
|
| IMPORTANT:
| - Incoming messages are saved ONLY to:
|     whatsapp_conversation_messages
| - Referral / CTWA data is stored in the same row.
| - whatsapp_referrals is NOT used.
| - Access token is NOT required for receiving webhook POSTs. It is needed
|   when your server sends messages through Graph API.
|--------------------------------------------------------------------------
*/

/* ========================================================================== 
   CONFIG CHECKS
   ========================================================================== */

$logFile = __DIR__ . '/webhook_log.txt';

/* Optional: app secret. Leave null if you are not validating signatures yet.
   If you add $appSecret to config.php, this webhook will verify
   X-Hub-Signature-256 automatically. */
$appSecret = isset($appSecret) ? trim((string)$appSecret) : '';

/* ========================================================================== 
   HELPERS
   ========================================================================== */

function writeWebhookLog(string $title, $data = null): void
{
    global $logFile;

    $payload = $data;

    if (is_string($payload)) {
        $encoded = $payload;
    } else {
        $encoded = json_encode(
            $payload,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        if ($encoded === false) {
            $encoded = '[json_encode failed: ' . json_last_error_msg() . ']';
        }
    }

    $content =
        "\n" .
        '[' . date('Y-m-d H:i:s') . "]\n" .
        $title . "\n" .
        $encoded . "\n" .
        "==============================\n";

    @file_put_contents($logFile, $content, FILE_APPEND | LOCK_EX);
    @error_log('ONTECH WHATSAPP WEBHOOK | ' . $title . ' | ' . $encoded);
}

function cleanNullableString($value): ?string
{
    if ($value === null) {
        return null;
    }

    $value = trim((string)$value);

    return $value === '' ? null : $value;
}

function getHeadersSafe(): array
{
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        return is_array($headers) ? $headers : [];
    }

    $headers = [];

    foreach ($_SERVER as $name => $value) {
        if (str_starts_with($name, 'HTTP_')) {
            $key = str_replace('_', '-', strtolower(substr($name, 5)));
            $headers[$key] = $value;
        }
    }

    return $headers;
}

function headerValue(array $headers, string $wanted): string
{
    foreach ($headers as $key => $value) {
        if (strcasecmp((string)$key, $wanted) === 0) {
            return trim((string)$value);
        }
    }

    return '';
}

function extractReferenceData(?string $messageText): array
{
    $result = [
        'reference_code' => null,
        'product_code'   => null,
        'source_type'    => null,
    ];

    if (!$messageText) {
        return $result;
    }

    if (preg_match('/\[REF\s*:\s*([A-Z0-9_-]+)\]/i', $messageText, $matches)) {
        $referenceCode = strtoupper(trim($matches[1]));
        $result['reference_code'] = $referenceCode;

        $parts = explode('-', $referenceCode);

        if (!empty($parts[0])) {
            $result['product_code'] = strtoupper(trim($parts[0]));
        }

        if (!empty($parts[1])) {
            $type = strtoupper(trim($parts[1]));

            $map = [
                'VIDEO' => 'Video',
                'VID'   => 'Video',
                'FLYER' => 'Flyer',
                'FLY'   => 'Flyer',
                'IMAGE' => 'Image',
                'IMG'   => 'Image',
                'AD'    => 'Ad',
                'POST'  => 'Post',
            ];

            $result['source_type'] = $map[$type] ?? ucfirst(strtolower($type));
        }
    }

    return $result;
}

function detectSourcePlatform(?string $sourceUrl): ?string
{
    if (!$sourceUrl) {
        return null;
    }

    $host = strtolower((string)(parse_url($sourceUrl, PHP_URL_HOST) ?? ''));

    if (
        str_contains($host, 'facebook.com') ||
        str_contains($host, 'fb.com') ||
        str_contains($host, 'fb.me')
    ) {
        return 'Facebook';
    }

    if (str_contains($host, 'instagram.com') || str_contains($host, 'instagr.am')) {
        return 'Instagram';
    }

    return null;
}

function determineMessageSource(
    array $referral,
    ?string $mediaType,
    ?string $sourceType,
    ?string $referenceCode
): string {
    $hasReferral = !empty($referral) || !empty($referenceCode);

    if (!$hasReferral) {
        return 'Normal Chat';
    }

    $mediaType = strtolower(trim((string)$mediaType));

    if ($mediaType === 'video') {
        return 'Ad - Video';
    }

    if ($mediaType === 'image') {
        return 'Ad - Flyer/Image';
    }

    return 'Ad - ' . ($sourceType ?: 'Unknown');
}

function extractMessageText(array $message): ?string
{
    $type = strtolower((string)($message['type'] ?? 'unknown'));

    switch ($type) {
        case 'text':
            return cleanNullableString($message['text']['body'] ?? null);

        case 'button':
            return cleanNullableString(
                $message['button']['text']
                ?? $message['button']['payload']
                ?? null
            );

        case 'interactive':
            $buttonText = $message['interactive']['button_reply']['title'] ?? null;
            $buttonId   = $message['interactive']['button_reply']['id'] ?? null;

            if ($buttonText) {
                return 'Button: ' . trim((string)$buttonText)
                    . ($buttonId ? ' [' . trim((string)$buttonId) . ']' : '');
            }

            $listText = $message['interactive']['list_reply']['title'] ?? null;
            $listId   = $message['interactive']['list_reply']['id'] ?? null;

            if ($listText) {
                return 'List: ' . trim((string)$listText)
                    . ($listId ? ' [' . trim((string)$listId) . ']' : '');
            }

            return '[Interactive]';

        case 'image':
            $caption = cleanNullableString($message['image']['caption'] ?? null);
            return $caption ? '[Image] ' . $caption : '[Image]';

        case 'video':
            $caption = cleanNullableString($message['video']['caption'] ?? null);
            return $caption ? '[Video] ' . $caption : '[Video]';

        case 'audio':
            return '[Audio]';

        case 'document':
            $filename = cleanNullableString($message['document']['filename'] ?? null);
            return $filename ? '[Document] ' . $filename : '[Document]';

        case 'sticker':
            return '[Sticker]';

        case 'location':
            $lat = $message['location']['latitude'] ?? null;
            $lng = $message['location']['longitude'] ?? null;
            return ($lat !== null && $lng !== null)
                ? '[Location] ' . $lat . ', ' . $lng
                : '[Location]';

        case 'contacts':
            return '[Contact]';

        case 'reaction':
            return '[Reaction] ' . (string)($message['reaction']['emoji'] ?? '');

        case 'order':
            return '[Order]';

        default:
            return '[' . $type . ']';
    }
}

/* ========================================================================== 
   METHOD / REQUEST LOGGING
   ========================================================================== */

$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'UNKNOWN'));
$headers = getHeadersSafe();

/* Read raw body ONCE. */
$rawInput = (string)(file_get_contents('php://input') ?: '');

/* Always log incoming traffic first. This is the first thing to check. */
writeWebhookLog('REQUEST RECEIVED', [
    'method'       => $method,
    'request_uri'  => $_SERVER['REQUEST_URI'] ?? '',
    'remote_addr'  => $_SERVER['REMOTE_ADDR'] ?? '',
    'content_type' => $_SERVER['CONTENT_TYPE'] ?? '',
    'body_length'  => strlen($rawInput),
]);

/* ========================================================================== 
   1. META WEBHOOK VERIFICATION
   ========================================================================== */

if ($method === 'GET') {

    /* Optional safe health check. */
    if (isset($_GET['health']) && (string)$_GET['health'] === '1') {
        header('Content-Type: application/json; charset=utf-8');

        $result = [
            'ok'                 => true,
            'webhook_file'      => __FILE__,
            'php_version'       => PHP_VERSION,
            'pdo_loaded'        => isset($pdo) && $pdo instanceof PDO,
            'table'             => 'whatsapp_conversation_messages',
            'time'               => date('Y-m-d H:i:s'),
        ];

        try {
            if (!isset($pdo) || !($pdo instanceof PDO)) {
                throw new RuntimeException('PDO connection missing');
            }

            $pdo->query('SELECT 1')->fetchColumn();
            $result['database'] = 'OK';

            $check = $pdo->query(
                "SELECT COUNT(*) FROM whatsapp_conversation_messages"
            );
            $result['message_rows'] = (int)$check->fetchColumn();

        } catch (Throwable $e) {
            $result['database'] = 'ERROR';
            $result['database_error'] = $e->getMessage();
        }

        echo json_encode(
            $result,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT
        );
        exit;
    }

    $mode      = (string)($_GET['hub_mode'] ?? $_GET['hub.mode'] ?? '');
    $token     = (string)($_GET['hub_verify_token'] ?? $_GET['hub.verify_token'] ?? '');
    $challenge = (string)($_GET['hub_challenge'] ?? $_GET['hub.challenge'] ?? '');

    writeWebhookLog('VERIFICATION REQUEST', [
        'mode'       => $mode,
        'token_sent' => $token !== '',
        'challenge'  => $challenge !== '',
    ]);

    if (
        $mode === 'subscribe' &&
        isset($verifyToken) &&
        hash_equals((string)$verifyToken, $token)
    ) {
        http_response_code(200);
        header('Content-Type: text/plain; charset=utf-8');
        echo $challenge;
        exit;
    }

    writeWebhookLog('VERIFICATION FAILED', [
        'mode' => $mode,
    ]);

    http_response_code(403);
    echo 'Verification failed';
    exit;
}

/* ========================================================================== 
   2. ONLY POST ALLOWED AFTER VERIFICATION
   ========================================================================== */

if ($method !== 'POST') {
    http_response_code(405);
    header('Allow: GET, POST');
    echo 'Method Not Allowed';
    exit;
}

/* ========================================================================== 
   3. OPTIONAL SIGNATURE VALIDATION
   ========================================================================== */

if ($appSecret !== '') {
    $signature = headerValue($headers, 'X-Hub-Signature-256');

    if ($signature === '') {
        writeWebhookLog('SIGNATURE MISSING');
        http_response_code(401);
        echo 'Missing signature';
        exit;
    }

    $expected = 'sha256=' . hash_hmac('sha256', $rawInput, $appSecret);

    if (!hash_equals($expected, $signature)) {
        writeWebhookLog('SIGNATURE INVALID');
        http_response_code(401);
        echo 'Invalid signature';
        exit;
    }
}

/* ========================================================================== 
   4. JSON PARSE
   ========================================================================== */

if ($rawInput === '') {
    writeWebhookLog('POST BODY EMPTY');
    http_response_code(400);
    echo 'Empty body';
    exit;
}

try {
    $data = json_decode($rawInput, true, 512, JSON_THROW_ON_ERROR);
} catch (Throwable $e) {
    writeWebhookLog('INVALID JSON', [
        'error' => $e->getMessage(),
        'body'  => $rawInput,
    ]);

    http_response_code(400);
    echo 'Invalid JSON';
    exit;
}

if (!is_array($data)) {
    writeWebhookLog('JSON NOT ARRAY');
    http_response_code(400);
    echo 'Invalid JSON structure';
    exit;
}

writeWebhookLog('RAW POST RECEIVED', $data);

/* ========================================================================== 
   5. OBJECT CHECK
   ========================================================================== */

if (($data['object'] ?? '') !== 'whatsapp_business_account') {
    writeWebhookLog('IGNORED NON-WHATSAPP OBJECT', [
        'object' => $data['object'] ?? null,
    ]);

    http_response_code(200);
    echo 'EVENT_RECEIVED';
    exit;
}

/* ========================================================================== 
   6. DATABASE CHECK
   ========================================================================== */

if (!isset($pdo) || !($pdo instanceof PDO)) {
    writeWebhookLog('DATABASE CONNECTION MISSING');
    http_response_code(500);
    echo 'Database connection unavailable';
    exit;
}

/* ========================================================================== 
   7. PROCESS WEBHOOK
   ========================================================================== */

try {

    $entryCount = 0;
    $changeCount = 0;
    $incomingSaved = 0;
    $statusEvents = 0;

    foreach (($data['entry'] ?? []) as $entry) {

        if (!is_array($entry)) {
            continue;
        }

        $entryCount++;

        foreach (($entry['changes'] ?? []) as $change) {

            if (!is_array($change)) {
                continue;
            }

            $changeCount++;

            $field = (string)($change['field'] ?? '');

            /* Log unknown fields instead of silently discarding them. */
            if ($field !== 'messages') {
                writeWebhookLog('IGNORED CHANGE FIELD', [
                    'field' => $field,
                ]);
                continue;
            }

            $value = $change['value'] ?? [];

            if (!is_array($value)) {
                continue;
            }

            $webhookPhoneNumberId = cleanNullableString(
                $value['metadata']['phone_number_id']
                ?? ($phoneNumberId ?? null)
            );

            $displayPhoneNumber = cleanNullableString(
                $value['metadata']['display_phone_number'] ?? null
            );

            writeWebhookLog('MESSAGES CHANGE RECEIVED', [
                'phone_number_id'     => $webhookPhoneNumberId,
                'display_phone_number'=> $displayPhoneNumber,
                'messages_count'      => count($value['messages'] ?? []),
                'statuses_count'      => count($value['statuses'] ?? []),
            ]);

            /* =============================================================
               CUSTOMER PROFILE NAME
               ============================================================= */
            $customerName = cleanNullableString(
                $value['contacts'][0]['profile']['name'] ?? null
            );

            /* =============================================================
               A) INCOMING MESSAGES
               ============================================================= */
            foreach (($value['messages'] ?? []) as $message) {

                if (!is_array($message)) {
                    continue;
                }

                $customerPhone = cleanNullableString($message['from'] ?? null);
                $messageId     = cleanNullableString($message['id'] ?? null);
                $messageType   = cleanNullableString($message['type'] ?? 'unknown') ?? 'unknown';

                if (!$customerPhone || !$messageId) {
                    writeWebhookLog('MESSAGE SKIPPED - MISSING PHONE OR ID', [
                        'customer_phone' => $customerPhone,
                        'message_id'     => $messageId,
                        'message_type'   => $messageType,
                    ]);
                    continue;
                }

                $messageText = extractMessageText($message);

                $timestamp = (int)($message['timestamp'] ?? time());
                $messageDate = date('Y-m-d H:i:s', $timestamp);

                /* ---------------------------------------------------------
                   REFERRAL DATA
                --------------------------------------------------------- */
                $referral = (
                    isset($message['referral']) &&
                    is_array($message['referral'])
                ) ? $message['referral'] : [];

                $sourceId     = cleanNullableString($referral['source_id'] ?? null);
                $sourceUrl    = cleanNullableString($referral['source_url'] ?? null);
                $metaSourceType = cleanNullableString($referral['source_type'] ?? null);
                $headline     = cleanNullableString($referral['headline'] ?? null);
                $body         = cleanNullableString($referral['body'] ?? null);
                $mediaType    = cleanNullableString($referral['media_type'] ?? null);
                $imageUrl     = cleanNullableString($referral['image_url'] ?? null);
                $videoUrl     = cleanNullableString($referral['video_url'] ?? null);
                $thumbnailUrl = cleanNullableString($referral['thumbnail_url'] ?? null);
                $ctwaClid     = cleanNullableString($referral['ctwa_clid'] ?? null);

                /* ---------------------------------------------------------
                   OWN REF CODE
                --------------------------------------------------------- */
                $referenceData = extractReferenceData($messageText);

                $referenceCode = $referenceData['reference_code'];
                $productCode   = $referenceData['product_code'];
                $sourceType    = $referenceData['source_type'] ?? $metaSourceType;

                /* ---------------------------------------------------------
                   PLATFORM
                --------------------------------------------------------- */
                $sourcePlatform = detectSourcePlatform($sourceUrl);

                /* ---------------------------------------------------------
                   SOURCE
                --------------------------------------------------------- */
                $messageSource = determineMessageSource(
                    $referral,
                    $mediaType,
                    $sourceType,
                    $referenceCode
                );

                $hasReferral = (
                    !empty($referral) ||
                    !empty($referenceCode)
                ) ? 1 : 0;

                /* ---------------------------------------------------------
                   CONTENT TITLE
                --------------------------------------------------------- */
                $contentTitle = $headline;

                if (!$contentTitle && $body) {
                    $contentTitle = $body;
                }

                if (!$contentTitle && $referenceCode) {
                    $contentTitle = $referenceCode;
                }

                /* ---------------------------------------------------------
                   Campaign / ad / creative cannot be safely guessed from
                   the standard referral payload, so keep NULL here unless
                   you later map them from your own REF data.
                --------------------------------------------------------- */
                $campaignName = null;
                $adName       = null;
                $creativeName = null;

                /* =========================================================
                   SINGLE-TABLE INSERT
                ========================================================= */
                $sql = "
                    INSERT INTO whatsapp_conversation_messages (
                        whatsapp_message_id,
                        customer_phone,
                        customer_name,
                        direction,
                        message_type,
                        message_text,
                        message_source,
                        has_referral,

                        reference_code,
                        product_code,
                        source_platform,
                        campaign_name,
                        ad_name,
                        creative_name,
                        content_title,

                        source_id,
                        source_url,
                        source_type,
                        headline,
                        body,
                        media_type,
                        image_url,
                        video_url,
                        thumbnail_url,
                        ctwa_clid,

                        status,
                        phone_number_id,
                        message_timestamp,
                        received_at,
                        raw_payload
                    )
                    VALUES (
                        :whatsapp_message_id,
                        :customer_phone,
                        :customer_name,
                        'incoming',
                        :message_type,
                        :message_text,
                        :message_source,
                        :has_referral,

                        :reference_code,
                        :product_code,
                        :source_platform,
                        :campaign_name,
                        :ad_name,
                        :creative_name,
                        :content_title,

                        :source_id,
                        :source_url,
                        :source_type,
                        :headline,
                        :body,
                        :media_type,
                        :image_url,
                        :video_url,
                        :thumbnail_url,
                        :ctwa_clid,

                        'received',
                        :phone_number_id,
                        :message_timestamp,
                        :received_at,
                        :raw_payload
                    )
                    ON DUPLICATE KEY UPDATE
                        customer_name = COALESCE(VALUES(customer_name), customer_name),
                        message_text = COALESCE(VALUES(message_text), message_text),
                        message_type = COALESCE(VALUES(message_type), message_type),
                        message_source = COALESCE(VALUES(message_source), message_source),
                        has_referral = GREATEST(has_referral, VALUES(has_referral)),

                        reference_code = COALESCE(VALUES(reference_code), reference_code),
                        product_code = COALESCE(VALUES(product_code), product_code),
                        source_platform = COALESCE(VALUES(source_platform), source_platform),
                        campaign_name = COALESCE(VALUES(campaign_name), campaign_name),
                        ad_name = COALESCE(VALUES(ad_name), ad_name),
                        creative_name = COALESCE(VALUES(creative_name), creative_name),
                        content_title = COALESCE(VALUES(content_title), content_title),

                        source_id = COALESCE(VALUES(source_id), source_id),
                        source_url = COALESCE(VALUES(source_url), source_url),
                        source_type = COALESCE(VALUES(source_type), source_type),
                        headline = COALESCE(VALUES(headline), headline),
                        body = COALESCE(VALUES(body), body),
                        media_type = COALESCE(VALUES(media_type), media_type),
                        image_url = COALESCE(VALUES(image_url), image_url),
                        video_url = COALESCE(VALUES(video_url), video_url),
                        thumbnail_url = COALESCE(VALUES(thumbnail_url), thumbnail_url),
                        ctwa_clid = COALESCE(VALUES(ctwa_clid), ctwa_clid),

                        phone_number_id = COALESCE(VALUES(phone_number_id), phone_number_id),
                        updated_at = CURRENT_TIMESTAMP
                ";

                $stmt = $pdo->prepare($sql);

                $stmt->execute([
                    ':whatsapp_message_id' => $messageId,
                    ':customer_phone'      => $customerPhone,
                    ':customer_name'       => $customerName,
                    ':message_type'        => $messageType,
                    ':message_text'       => $messageText,
                    ':message_source'      => $messageSource,
                    ':has_referral'        => $hasReferral,

                    ':reference_code'      => $referenceCode,
                    ':product_code'       => $productCode,
                    ':source_platform'    => $sourcePlatform,
                    ':campaign_name'      => $campaignName,
                    ':ad_name'            => $adName,
                    ':creative_name'      => $creativeName,
                    ':content_title'      => $contentTitle,

                    ':source_id'           => $sourceId,
                    ':source_url'          => $sourceUrl,
                    ':source_type'         => $sourceType,
                    ':headline'            => $headline,
                    ':body'                => $body,
                    ':media_type'          => $mediaType,
                    ':image_url'           => $imageUrl,
                    ':video_url'           => $videoUrl,
                    ':thumbnail_url'       => $thumbnailUrl,
                    ':ctwa_clid'           => $ctwaClid,

                    ':phone_number_id'     => $webhookPhoneNumberId,
                    ':message_timestamp'   => $messageDate,
                    ':received_at'         => date('Y-m-d H:i:s'),
                    ':raw_payload'         => $rawInput,
                ]);

                $incomingSaved++;

                writeWebhookLog('INCOMING MESSAGE SAVED', [
                    'customer_phone'  => $customerPhone,
                    'customer_name'   => $customerName,
                    'message_id'      => $messageId,
                    'message_type'    => $messageType,
                    'message_text'    => $messageText,
                    'message_source'  => $messageSource,
                    'has_referral'    => $hasReferral,
                    'reference_code'  => $referenceCode,
                    'product_code'    => $productCode,
                    'source_platform' => $sourcePlatform,
                    'source_type'     => $sourceType,
                    'ctwa_clid'       => $ctwaClid,
                ]);
            }

            /* =============================================================
               B) OUTGOING MESSAGE STATUS
               ============================================================= */
            foreach (($value['statuses'] ?? []) as $statusItem) {

                if (!is_array($statusItem)) {
                    continue;
                }

                $statusEvents++;

                $outgoingMessageId = cleanNullableString($statusItem['id'] ?? null);
                $status = cleanNullableString($statusItem['status'] ?? null);
                $recipientPhone = cleanNullableString($statusItem['recipient_id'] ?? null);
                $statusTimestamp = (int)($statusItem['timestamp'] ?? time());
                $statusDate = date('Y-m-d H:i:s', $statusTimestamp);

                if (!$outgoingMessageId) {
                    continue;
                }

                $updateSql = "
                    UPDATE whatsapp_conversation_messages
                    SET
                        status = :status,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE whatsapp_message_id = :message_id
                ";

                $updateStmt = $pdo->prepare($updateSql);
                $updateStmt->execute([
                    ':status' => $status,
                    ':message_id' => $outgoingMessageId,
                ]);

                /* If the outgoing message wasn't stored before, create a
                   lightweight placeholder so the status is not lost. */
                if ($updateStmt->rowCount() === 0 && $recipientPhone) {

                    $insertOutgoingSql = "
                        INSERT INTO whatsapp_conversation_messages (
                            whatsapp_message_id,
                            customer_phone,
                            customer_name,
                            direction,
                            message_type,
                            message_text,
                            message_source,
                            has_referral,
                            status,
                            phone_number_id,
                            message_timestamp,
                            received_at,
                            raw_payload
                        )
                        VALUES (
                            :message_id,
                            :customer_phone,
                            NULL,
                            'outgoing',
                            'unknown',
                            NULL,
                            'Normal Chat',
                            0,
                            :status,
                            :phone_number_id,
                            :message_timestamp,
                            NULL,
                            :raw_payload
                        )
                        ON DUPLICATE KEY UPDATE
                            status = VALUES(status),
                            updated_at = CURRENT_TIMESTAMP
                    ";

                    $insertOutgoingStmt = $pdo->prepare($insertOutgoingSql);

                    $insertOutgoingStmt->execute([
                        ':message_id'        => $outgoingMessageId,
                        ':customer_phone'    => $recipientPhone,
                        ':status'            => $status,
                        ':phone_number_id'   => $webhookPhoneNumberId,
                        ':message_timestamp'=> $statusDate,
                        ':raw_payload'      => $rawInput,
                    ]);
                }

                writeWebhookLog('OUTGOING STATUS PROCESSED', [
                    'message_id' => $outgoingMessageId,
                    'recipient'  => $recipientPhone,
                    'status'     => $status,
                    'timestamp'  => $statusDate,
                ]);
            }
        }
    }

    writeWebhookLog('WEBHOOK PROCESSING COMPLETE', [
        'entries'         => $entryCount,
        'changes'         => $changeCount,
        'incoming_saved'  => $incomingSaved,
        'status_events'   => $statusEvents,
    ]);

    /* Meta expects successful delivery acknowledgement. */
    http_response_code(200);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'EVENT_RECEIVED';

} catch (Throwable $e) {

    writeWebhookLog('WEBHOOK PROCESSING ERROR', [
        'error' => $e->getMessage(),
        'file'  => $e->getFile(),
        'line'  => $e->getLine(),
        'trace' => $e->getTraceAsString(),
    ]);

    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Webhook processing error';
}
